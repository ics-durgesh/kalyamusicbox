#!/usr/bin/env python3
"""
mp3gui.py — Kalya MusicBox Ver 1.0: MP3 Manager & Music Player (the window for mp3tool.py).
Developed by Durgesh Kalya · FindingPlace.org · https://findingplace.org

Starts a small private web server on this Mac (reachable only from this Mac, protected by a
one-time key) and opens the window in your web browser. Close the Terminal window, or click
Quit in the window, to stop it.

    ~/mp3venv/bin/python mp3gui.py [--root /Volumes/MUSIC-DK]
"""

import argparse
import csv
import hashlib
import json
import mimetypes
import os
import secrets
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mp3tool as T  # noqa: E402

APP_NAME = "Kalya MusicBox"
APP_VERSION = T.APP_VERSION
# The Kalya MusicBox logo (app icon), embedded so the window works offline.
ICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512" role="img" aria-label="Kalya MusicBox">
  <title>Kalya MusicBox</title>
  <defs>
    <linearGradient id="kmbBg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#2E9A7C"/><stop offset="1" stop-color="#0D4337"/>
    </linearGradient>
    <radialGradient id="kmbGlow" cx="0.22" cy="0.12" r="0.75">
      <stop offset="0" stop-color="#ffffff" stop-opacity="0.22"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/>
    </radialGradient>
    <filter id="kmbShadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="10" stdDeviation="12" flood-color="#06261f" flood-opacity="0.35"/>
    </filter>
  </defs>
  <rect width="512" height="512" rx="116" fill="url(#kmbBg)"/>
  <rect width="512" height="512" rx="116" fill="url(#kmbGlow)"/>
  <g transform="translate(0,-14)" filter="url(#kmbShadow)">
    <polygon points="208,150 388,112 388,166 208,204" fill="#FBF6EC"/>
    <rect x="208" y="170" width="36" height="200" fill="#FBF6EC"/>
    <rect x="352" y="140" width="36" height="198" fill="#FBF6EC"/>
    <rect x="136" y="318" width="108" height="108" rx="24" fill="#FBF6EC" transform="rotate(-12 190 372)"/>
    <rect x="280" y="286" width="108" height="108" rx="24" fill="#F5B841" transform="rotate(-12 334 340)"/>
  </g>
</svg>"""
ICON_URI = "data:image/svg+xml;base64," + __import__("base64").b64encode(ICON_SVG.encode()).decode()
TOKEN = secrets.token_urlsafe(18)
IS_MAC = sys.platform == "darwin"

AUDIO_MIME = {".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".aac": "audio/aac", ".flac": "audio/flac",
              ".ogg": "audio/ogg", ".opus": "audio/ogg", ".wav": "audio/wav", ".aiff": "audio/aiff",
              ".aif": "audio/aiff", ".wma": "audio/x-ms-wma"}


CONF_DIR = os.path.expanduser("~/.mp3manager")
LIB_FILE = os.path.join(CONF_DIR, "library.json")
SETTINGS_FILE = os.path.join(CONF_DIR, "settings.json")
RUN_FILE = os.path.join(CONF_DIR, "running.json")
LOG_FILE = os.path.join(CONF_DIR, "kalya-musicbox.log")
# True when started from the installed app (installed by "Install Kalya MusicBox.command")
INSTALLED = "/Application Support/KalyaMusicBox/" in os.path.realpath(__file__)
IDLE_MINUTES = 20   # the background app quits itself after this long with no window open


def load_settings():
    try:
        with open(SETTINGS_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def save_settings(**kw):
    data = load_settings()
    data.update(kw)
    os.makedirs(CONF_DIR, exist_ok=True)
    with open(SETTINGS_FILE, "w") as f:
        json.dump(data, f, indent=1)
# formats web browsers can play (WMA can't be played in a browser)
PLAYABLE = {".mp3", ".m4a", ".aac", ".flac", ".wav", ".ogg", ".opus"}


class State:
    def __init__(self, root):
        self.lock = threading.Lock()
        self.root = root
        self.job = None          # dict describing the running / last job
        self.job_seq = 0
        self.plans = {}          # plan name -> plan
        self.server = None
        self.last_seen = time.time()
        self.sources = []        # player: music folders
        self.tracks = []         # player: songs found in those folders
        self.track_by_id = {}
        self.scanned_at = None
        self.convert_plan = None     # converter: last checked plan
        self.open_ok = set()         # folders/files outside the drive that the window may open in Finder

    @property
    def paths(self):
        return T.Paths(self.root)


S = None


# --------------------------------------------------------------------------------------------
# Background jobs (scans and moves can take many minutes on a large drive)
# --------------------------------------------------------------------------------------------
def start_job(kind, fn):
    with S.lock:
        if S.job and S.job["running"]:
            raise T.ToolError("Please wait: '%s' is still running." % S.job["label"])
        S.job_seq += 1
        job = {"id": S.job_seq, "kind": kind, "label": "Starting...", "i": 0, "total": 0,
               "running": True, "error": None, "result": None}
        S.job = job

    def prog(label, i, total):
        job["label"], job["i"], job["total"] = label, i, total

    def runner():
        try:
            job["result"] = fn(prog)
        except T.ToolError as e:
            job["error"] = str(e)
        except Exception as e:  # show unexpected problems instead of hanging
            traceback.print_exc()
            job["error"] = "Unexpected problem: %s" % e
        finally:
            job["running"] = False

    threading.Thread(target=runner, daemon=True).start()
    return job["id"]


def job_public(job):
    if not job:
        return None
    return {k: job[k] for k in ("id", "kind", "label", "i", "total", "running", "error")}


# --------------------------------------------------------------------------------------------
# Actions
# --------------------------------------------------------------------------------------------
def status():
    p = S.paths
    picard = None
    if IS_MAC:
        for a in ("/Applications/MusicBrainz Picard.app",
                  os.path.expanduser("~/Applications/MusicBrainz Picard.app")):
            if os.path.exists(a):
                picard = a
    return {
        "root": p.root, "drive_ok": os.path.isdir(p.root), "project_ok": os.path.isdir(p.reports),
        "mutagen_ok": T.mutagen is not None, "is_mac": IS_MAC, "picard": picard,
        "python": sys.executable, "job": job_public(S.job),
        "launcher": T.LAUNCHER if IS_MAC and not INSTALLED else None,
        "installed": INSTALLED,
        "ffmpeg": T.find_ffmpeg(),
    }


def act_scan(body):
    kind = body.get("kind")
    p = S.paths
    if kind == "dupes":
        fn = lambda prog: T.find_dupes(p, prog)
    elif kind == "recordings":
        across = bool(body.get("across_albums"))
        fn = lambda prog: T.find_recordings(p, across, prog)
    else:
        raise T.ToolError("Unknown scan")

    def run(prog):
        plan = fn(prog)
        prog("Writing report", 1, 1)
        plan["report"] = p.rel(T.write_plan_report(p, plan, "preview"))
        S.plans[plan["name"]] = plan
        return plan
    return {"job": start_job(kind, run)}


def act_apply(body):
    plan = S.plans.get(body.get("plan"))
    if not plan:
        raise T.ToolError("This scan is no longer available. Please scan again.")
    if plan["root"] != S.paths.root:
        raise T.ToolError("The drive was changed after this scan. Please scan again.")
    moves = T.plan_moves(plan, body.get("decisions") or {})
    if not moves:
        raise T.ToolError("Nothing is selected to move.")
    p = S.paths

    def run(prog):
        res = T.apply_moves(p, plan, moves, prog)
        S.plans.pop(plan["name"], None)
        return {"kind": plan["kind"], "moved": res["moved"], "skipped": res["skipped"],
                "freed": res["freed"], "manifest": p.rel(res["manifest"]),
                "review_dir": p.rel(res["review_dir"]),
                "skipped_rows": [r for r in res["rows"] if r["status"] != "moved"][:200]}
    return {"job": start_job("apply", run)}


def act_undo(body):
    p = S.paths
    manifest = body.get("manifest")
    return {"job": start_job("undo", lambda prog: T.undo_run(p, manifest, prog))}


def act_catalog(body):
    p = S.paths

    def run(prog):
        res = T.build_catalog(p, prog)
        res["csv"] = p.rel(res["csv"])
        return res
    return {"job": start_job("catalog", run)}


def latest_catalog():
    p = S.paths
    if not os.path.isdir(p.reports):
        return {"rows": None}
    cands = sorted(f for f in os.listdir(p.reports) if f.startswith("catalog_") and f.endswith(".csv"))
    if not cands:
        return {"rows": None}
    path = os.path.join(p.reports, cands[-1])
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    stats = {
        "songs": len(rows),
        "albums": len(set((r["artist"], r["album"]) for r in rows if r["album"])),
        "artists": len(set(r["artist"] for r in rows if r["artist"])),
        "no_cover": sum(1 for r in rows if r["has_cover"] == "no"),
        "attention": sum(1 for r in rows if r["needs_attention"]),
        "with_id": sum(1 for r in rows if r.get("has_musicbrainz_id") == "yes"),
    }
    return {"rows": rows, "stats": stats, "csv": p.rel(path)}


def act_open(body):
    """Show a file or folder in Finder, open a report, or open Picard."""
    if not IS_MAC:
        raise T.ToolError("Opening Finder only works on a Mac.")
    what = body.get("what")
    if what == "picard":
        subprocess.Popen(["open", "-a", "MusicBrainz Picard"])
        return {"ok": True}
    p = S.paths
    if body.get("abs"):
        full = os.path.abspath(body.get("path") or "")
        if full not in S.open_ok:
            raise T.ToolError("That location can't be opened from here.")
        subprocess.Popen(["open", "-R", full] if what == "reveal" else ["open", full])
        return {"ok": True}
    full = p.abs(body.get("path") or "")
    if not os.path.exists(full):
        if what == "folder":
            os.makedirs(full, exist_ok=True)
        else:
            raise T.ToolError("Not found: %s" % body.get("path"))
    if what == "reveal":
        subprocess.Popen(["open", "-R", full])
    else:
        subprocess.Popen(["open", full])
    return {"ok": True}


def act_root(body):
    root = (body.get("root") or "").strip().rstrip("/")
    if not root:
        raise T.ToolError("Please enter the drive's path, e.g. /Volumes/MUSIC-DK")
    with S.lock:
        if S.job and S.job["running"]:
            raise T.ToolError("Please wait until the current task finishes.")
        S.root = root
        S.plans.clear()
    save_settings(root=root)
    return status()


def act_setup(body):
    res = T.setup_project(S.paths, make_launcher=not INSTALLED)
    return {"launcher": res["launcher"], "status": status()}


def act_quit(body):
    threading.Thread(target=lambda: (S.server.shutdown()), daemon=True).start()
    return {"ok": True}


POST_ACTIONS = {"scan": act_scan, "apply": act_apply, "undo": act_undo, "catalog": act_catalog,
                "open": act_open, "root": act_root, "setup": act_setup, "quit": act_quit}


# --------------------------------------------------------------------------------------------
# Player: music folders, song list and tag cache (kept in ~/.mp3manager/library.json)
# --------------------------------------------------------------------------------------------
def _set_tracks(tracks):
    S.tracks = tracks
    S.track_by_id = {t["id"]: t for t in tracks}


def load_library():
    try:
        with open(LIB_FILE) as f:
            data = json.load(f)
    except Exception:
        return
    S.sources = [x for x in data.get("sources", []) if isinstance(x, str)]
    _set_tracks([t for t in data.get("tracks", []) if isinstance(t, dict) and "id" in t and "path" in t])
    S.scanned_at = data.get("scanned_at")


def save_library():
    os.makedirs(CONF_DIR, exist_ok=True)
    tmp = LIB_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump({"sources": S.sources, "tracks": S.tracks, "scanned_at": S.scanned_at}, f)
    os.replace(tmp, LIB_FILE)


def _player_files(src):
    """Playable songs under a folder. Skips the duplicate review area and project reports/tools."""
    for dirpath, dirnames, filenames in os.walk(src):
        base = os.path.basename(dirpath)
        keep = []
        for d in dirnames:
            if d in T.SKIP_DIRS or d.startswith(".") or d == T.REVIEW:
                continue
            if base == T.PROJECT and d != "Library":
                continue
            keep.append(d)
        dirnames[:] = sorted(keep, key=str.lower)
        for f in sorted(filenames, key=str.lower):
            if not f.startswith(".") and os.path.splitext(f)[1].lower() in PLAYABLE:
                yield os.path.join(dirpath, f)


def _track_no(v):
    try:
        return int(str(v).split("/")[0])
    except ValueError:
        return 0


def scan_player(prog):
    old = {t["path"]: t for t in S.tracks}
    found, seen, missing = [], set(), []
    prog("Looking for songs", 0, 0)
    for src in S.sources:
        if not os.path.isdir(src):
            missing.append(src)
            continue
        for f in _player_files(src):
            real = os.path.realpath(f)
            if real not in seen:          # folders that overlap don't list a song twice
                seen.add(real)
                found.append((src, f))
    tracks = []
    for i, (src, f) in enumerate(found, 1):
        prog("Reading song tags", i, len(found))
        try:
            st = os.stat(f)
        except OSError:
            continue
        o = old.get(f)
        if o and o.get("size") == st.st_size and o.get("mtime") == int(st.st_mtime):
            t = dict(o)
        else:
            inf = T.read_info(f)
            t = {"path": f, "size": st.st_size, "mtime": int(st.st_mtime),
                 "title": inf["title"], "artist": inf["artist"], "album": inf["album"],
                 "albumartist": inf["albumartist"], "track": _track_no(inf["tracknumber"]),
                 "seconds": inf["seconds"], "cover": bool(inf["has_cover"])}
        t["id"] = hashlib.md5(f.encode("utf-8", "surrogateescape")).hexdigest()[:16]
        t["where"] = os.path.relpath(f, os.path.dirname(src.rstrip("/")) or "/")
        tracks.append(t)
    tracks.sort(key=lambda t: (not (t["albumartist"] or t["artist"]),   # untagged songs last
                               (t["albumartist"] or t["artist"]).lower(), t["album"].lower(), t["track"],
                               (t["title"] or os.path.basename(t["path"])).lower()))
    _set_tracks(tracks)
    S.scanned_at = time.strftime("%a %d %b %Y, %H:%M")
    save_library()
    return {"count": len(tracks), "missing": missing}


def player_info(with_tracks=True):
    out = {"sources": [{"path": x, "ok": os.path.isdir(x)} for x in S.sources], "scanned_at": S.scanned_at,
           "count": len(S.tracks)}
    if with_tracks:
        out["tracks"] = [{k: t.get(k) for k in ("id", "title", "artist", "album", "track", "seconds", "cover", "where")}
                         for t in S.tracks]
    return out


def act_player_sources(body):
    srcs = []
    for x in body.get("sources") or []:
        x = os.path.abspath(os.path.expanduser(str(x).strip()))
        if x and x not in srcs:
            srcs.append(x)
    S.sources = srcs
    save_library()
    return player_info(with_tracks=False)


def act_player_scan(body):
    if not S.sources:
        raise T.ToolError("Add at least one music folder first.")
    return {"job": start_job("player", scan_player)}


def list_dirs(path):
    home = os.path.expanduser("~")
    if not path:
        path = "/Volumes" if os.path.isdir("/Volumes") else home
    path = os.path.abspath(os.path.expanduser(path))
    if not os.path.isdir(path):
        raise T.ToolError("Folder not found: %s" % path)
    try:
        names = os.listdir(path)
    except OSError as e:
        raise T.ToolError("Can't open %s (%s). If macOS asked for permission, allow Terminal access." % (path, e.strerror))
    dirs = sorted((n for n in names if not n.startswith(".") and n not in T.SKIP_DIRS
                   and os.path.isdir(os.path.join(path, n))), key=str.lower)
    shortcuts = [{"label": "Drives", "path": "/Volumes"}] if os.path.isdir("/Volumes") else []
    shortcuts += [{"label": "Home", "path": home}]
    if os.path.isdir(os.path.join(home, "Music")):
        shortcuts.append({"label": "Music", "path": os.path.join(home, "Music")})
    if os.path.isdir(S.root):
        shortcuts.append({"label": os.path.basename(S.root) or S.root, "path": S.root})
    parent = os.path.dirname(path) if path != os.path.dirname(path) else None
    return {"path": path, "parent": parent, "dirs": dirs, "shortcuts": shortcuts}


POST_ACTIONS.update({"player_sources": act_player_sources, "player_scan": act_player_scan})


# --------------------------------------------------------------------------------------------
# Convert to MP3
# --------------------------------------------------------------------------------------------
def convert_info():
    return {"formats": [{"key": k, "label": l, "exts": e, "lossless": ll} for k, l, e, ll in T.CONVERT_FORMATS],
            "defaults": T.DEFAULT_CONVERT,
            "qualities": [{"key": k, "label": v[2]} for k, v in T.QUALITY_PRESETS.items()],
            "ffmpeg": T.find_ffmpeg()}


def act_convert_plan(body):
    src = (body.get("src") or "").strip()
    dst = (body.get("dst") or "").strip() or None
    if not src:
        raise T.ToolError("Choose the folder with the files to convert.")
    if body.get("same_folder"):
        dst = None
    elif not dst:
        raise T.ToolError("Choose where to save the MP3s, or pick 'Next to the originals'.")
    if dst and os.path.abspath(dst) == os.path.abspath(src):
        dst = None
    formats = body.get("formats") or []

    def run(prog):
        plan = T.plan_convert(src, dst, formats, bool(body.get("recurse", True)), bool(body.get("overwrite")), prog)
        S.convert_plan = plan
        return {"src": plan["src"], "dst": plan["dst"], "todo": plan["todo"], "exists": plan["exists"],
                "by_format": plan["by_format"],
                "todo_bytes": sum(i["size"] for i in plan["items"] if i["status"] == "todo"),
                "sample": [{"src": os.path.relpath(i["src"], plan["src"]), "out": i["out"], "status": i["status"]}
                           for i in plan["items"][:300]]}
    return {"job": start_job("convert_check", run)}


def act_convert_run(body):
    plan = S.convert_plan
    if not plan:
        raise T.ToolError("Click 'Check files' first.")
    quality = body.get("quality") or "320"
    keep_art = bool(body.get("keep_art", True))

    def run(prog):
        res = T.run_convert(plan, quality, keep_art, prog)
        S.convert_plan = None
        S.open_ok.add(os.path.abspath(res["dst"]))
        if res["log"]:
            S.open_ok.add(os.path.abspath(res["log"]))
        res["failed"] = res["failed"][:200]
        return res
    return {"job": start_job("convert", run)}


POST_ACTIONS.update({"convert_plan": act_convert_plan, "convert_run": act_convert_run})


# --------------------------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "MP3Manager"

    def log_message(self, *a):
        pass

    def _seen(self):
        S.last_seen = time.time()

    def _host_ok(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ("127.0.0.1", "localhost")

    def _send(self, code, body, ctype="application/json", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _authorized(self, q):
        tok = self.headers.get("X-Token") or (q.get("t") or [""])[0]
        return secrets.compare_digest(tok, TOKEN)

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, {"error": "forbidden"})
        self._seen()
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/":
            if not self._authorized(q):
                return self._send(403, "Please open Kalya MusicBox with the link shown in Terminal.", "text/plain")
            return self._send(200, PAGE.replace("__TOKEN__", TOKEN).replace("__ICON__", ICON_URI), "text/html; charset=utf-8")
        if u.path == "/icon.svg":
            return self._send(200, ICON_SVG, "image/svg+xml", {"Cache-Control": "max-age=86400"})
        if not self._authorized(q):
            return self._send(403, {"error": "forbidden"})
        try:
            if u.path == "/api/ping":
                return self._send(200, {"ok": True, "app": APP_NAME})
            if u.path == "/api/status":
                return self._send(200, status())
            if u.path == "/api/job":
                job = S.job
                if not job or str(job["id"]) != (q.get("id") or [""])[0]:
                    return self._send(404, {"error": "no such job"})
                return self._send(200, {"job": job_public(job), "result": job["result"]})
            if u.path == "/api/runs":
                return self._send(200, {"runs": T.list_runs(S.paths)})
            if u.path == "/api/catalog":
                return self._send(200, latest_catalog())
            if u.path == "/api/player":
                return self._send(200, player_info())
            if u.path == "/api/convert_info":
                return self._send(200, convert_info())
            if u.path == "/api/dirs":
                return self._send(200, list_dirs((q.get("path") or [""])[0]))
            if u.path in ("/media/track", "/media/trackcover"):
                t = S.track_by_id.get((q.get("id") or [""])[0])
                if not t:
                    return self._send(404, {"error": "song not found; try Rescan"})
                if u.path == "/media/track":
                    return self._audio(t["path"])
                c = T.read_cover(t["path"]) if os.path.isfile(t["path"]) else None
                if not c or not c[0]:
                    return self._send(404, {"error": "no cover"})
                return self._send(200, c[0], c[1], {"Cache-Control": "max-age=3600"})
            if u.path == "/media/audio":
                return self._audio(S.paths.abs((q.get("p") or [""])[0]))
            if u.path == "/media/cover":
                full = S.paths.abs((q.get("p") or [""])[0])
                c = T.read_cover(full) if os.path.isfile(full) else None
                if not c or not c[0]:
                    return self._send(404, {"error": "no cover"})
                return self._send(200, c[0], c[1], {"Cache-Control": "max-age=3600"})
        except T.ToolError as e:
            return self._send(400, {"error": str(e)})
        return self._send(404, {"error": "not found"})

    do_HEAD = do_GET

    def _audio(self, full):
        if not os.path.isfile(full):
            return self._send(404, {"error": "file not found"})
        size = os.path.getsize(full)
        ctype = AUDIO_MIME.get(os.path.splitext(full)[1].lower()) or mimetypes.guess_type(full)[0] or "application/octet-stream"
        start, end = 0, size - 1
        rng = self.headers.get("Range")
        code = 200
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].split(",")[0].partition("-")
            try:
                if a:
                    start = int(a)
                    end = int(b) if b else size - 1
                else:
                    start = size - int(b)
                end = min(end, size - 1)
                code = 206
            except ValueError:
                start, end = 0, size - 1
            if start > end or start >= size:
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % size)
                self.end_headers()
                return
        length = end - start + 1
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        if code == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with open(full, "rb") as f:
                f.seek(start)
                left = length
                while left > 0:
                    chunk = f.read(min(65536, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_POST(self):
        if not self._host_ok():
            return self._send(403, {"error": "forbidden"})
        self._seen()
        u = urlparse(self.path)
        if not self._authorized(parse_qs(u.query)):
            return self._send(403, {"error": "forbidden"})
        name = u.path.rsplit("/", 1)[-1]
        fn = POST_ACTIONS.get(name) if u.path.startswith("/api/") else None
        if not fn:
            return self._send(404, {"error": "not found"})
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}")
            return self._send(200, fn(body))
        except T.ToolError as e:
            return self._send(400, {"error": str(e)})
        except Exception as e:
            traceback.print_exc()
            return self._send(500, {"error": "Unexpected problem: %s" % e})


def _running_instance():
    """URL of a Kalya MusicBox that is already running for this user, if any.
    (Uses a plain local connection, not urllib, so no macOS proxy frameworks are loaded before forking.)"""
    import http.client
    try:
        with open(RUN_FILE) as f:
            info = json.load(f)
        u = urlparse(info["url"])
        conn = http.client.HTTPConnection("127.0.0.1", u.port, timeout=1.5)
        conn.request("GET", "/api/ping?" + u.query, headers={"Host": "127.0.0.1"})
        r = conn.getresponse()
        ok = r.status == 200 and json.loads(r.read() or b"{}").get("ok")
        conn.close()
        if ok:
            return info["url"]
    except Exception:
        pass
    return None


def _detach():
    """Run on in the background and let the launching process exit straight away.
    macOS considers an app 'open' while its launching process runs; exiting promptly lets the
    Kalya MusicBox icon be opened again at any time (it then just reopens the window)."""
    if os.fork() > 0:
        return False          # original process: finish now
    os.setsid()
    if os.fork() > 0:
        os._exit(0)
    devnull = os.open(os.devnull, os.O_RDWR)
    os.dup2(devnull, 0)
    return True


def run(root=None, port=8765, open_browser=True, background=False):
    global S
    existing = _running_instance()
    if existing:
        print("%s is already running; opening its window." % APP_NAME)
        if open_browser:
            webbrowser.open(existing)
        return
    os.makedirs(CONF_DIR, exist_ok=True)
    if background and hasattr(os, "fork") and not _detach():
        return
    if background:   # started from the app icon: no Terminal, so keep a log instead
        log = open(LOG_FILE, "a", buffering=1)
        sys.stdout = sys.stderr = log
        print("\n--- %s" % time.strftime("%Y-%m-%d %H:%M:%S"))
    root = root or load_settings().get("root") or T.DEFAULT_ROOT
    S = State(os.path.abspath(os.path.expanduser(root)))
    load_library()
    server = None
    for prt in (port, 0):
        try:
            server = ThreadingHTTPServer(("127.0.0.1", prt), Handler)
            break
        except OSError:
            continue
    S.server = server
    url = "http://127.0.0.1:%d/?t=%s" % (server.server_address[1], TOKEN)
    try:
        with open(RUN_FILE, "w") as f:
            json.dump({"url": url, "pid": os.getpid()}, f)
        os.chmod(RUN_FILE, 0o600)
    except OSError:
        pass
    if background:
        def watchdog():
            while True:
                time.sleep(60)
                busy = S.job and S.job["running"]
                if not busy and time.time() - S.last_seen > IDLE_MINUTES * 60:
                    print("No window open for %d minutes; stopping." % IDLE_MINUTES)
                    S.server.shutdown()
                    return
        threading.Thread(target=watchdog, daemon=True).start()
    print("%s Ver %s · %s · Developed by Durgesh Kalya · FindingPlace.org" % (APP_NAME, APP_VERSION, T.APP_TAGLINE))
    print("%s is running." % APP_NAME)
    print("If the window didn't open, paste this into your browser:\n  %s" % url)
    if background:
        print("Running in the background. It stops when you click Quit in the window, "
              "or after %d minutes with no window open." % IDLE_MINUTES)
    else:
        print("To stop it, click Quit in the window or close this Terminal window.")
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:   # stopped by the installer/uninstaller (or logout): shut down cleanly
        import signal
        signal.signal(signal.SIGTERM, lambda *_: threading.Thread(target=server.shutdown, daemon=True).start())
    except (ValueError, OSError):
        pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    try:
        with open(RUN_FILE) as f:
            if json.load(f).get("pid") == os.getpid():
                os.remove(RUN_FILE)
    except Exception:
        pass
    try:
        print("\n%s stopped." % APP_NAME)
    except (BrokenPipeError, OSError):
        pass


# --------------------------------------------------------------------------------------------
# The window (HTML, CSS and JavaScript in one page; works offline)
# --------------------------------------------------------------------------------------------
PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Kalya MusicBox</title>
<link rel="icon" type="image/svg+xml" href="__ICON__">
<link rel="apple-touch-icon" href="__ICON__">
<style>
:root {
  --bg: #f4f3ef; --panel: #ffffff; --panel-2: #f9f8f5; --line: #e4e1d9; --line-2: #d4d0c6;
  --ink: #1d1c19; --ink-2: #57544d; --ink-3: #8a867c;
  --accent: #1f6f5c; --accent-ink: #ffffff; --accent-soft: #e2f0eb;
  --keep: #1f6f5c; --keep-soft: #e6f2ed; --move: #a35a12; --move-soft: #fbf0e3;
  --warn: #9c3d2e; --warn-soft: #f8e7e3; --note: #6a5a17; --note-soft: #f6efd4;
  --shadow: 0 1px 2px rgba(30,25,15,.06), 0 4px 16px rgba(30,25,15,.05);
  --radius: 12px; --mono: ui-monospace, "SF Mono", Menlo, monospace;
  color-scheme: light;
}
@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) {
    --bg: #161614; --panel: #1f1f1c; --panel-2: #252521; --line: #33322d; --line-2: #45433c;
    --ink: #f0eee8; --ink-2: #b9b5aa; --ink-3: #8a867c;
    --accent: #5cc0a2; --accent-ink: #0d1f19; --accent-soft: #1d3029;
    --keep: #6cc9ac; --keep-soft: #1c2e27; --move: #e7a35a; --move-soft: #33271a;
    --warn: #ec8f7c; --warn-soft: #3a221d; --note: #e3cd73; --note-soft: #33301d;
    --shadow: 0 1px 2px rgba(0,0,0,.3); color-scheme: dark;
  }
}
* { box-sizing: border-box; }
html, body { margin: 0; background: var(--bg); color: var(--ink);
  font: 14px/1.45 -apple-system, BlinkMacSystemFont, "SF Pro Text", "Helvetica Neue", Arial, sans-serif; }
button { font: inherit; }
.app { display: grid; grid-template-columns: 236px minmax(0, 1fr); min-height: 100vh; }
aside { border-right: 1px solid var(--line); padding: 18px 14px; position: sticky; top: 0; height: 100vh;
  display: flex; flex-direction: column; gap: 4px; background: var(--panel-2); }
.brand { display: flex; align-items: center; gap: 10px; padding: 4px 8px 16px; }
.brand-mark { width: 30px; height: 30px; border-radius: 9px; background: var(--accent); display: grid; place-items: center; }
.brand-mark svg { width: 18px; height: 18px; fill: var(--accent-ink); }
.brand b { font-size: 15px; letter-spacing: -.01em; }
.brand .ver { font-size: 10.5px; color: var(--ink-3); margin-top: 1px; white-space: nowrap; letter-spacing: -.005em; }
.brand b { font-size: 16px; }
.brand { gap: 10px; padding-right: 0; }
.brand .logo { width: 38px; height: 38px; display: block; flex: none; filter: drop-shadow(0 1px 2px rgba(0,0,0,.15)); }
.brand .mb, .about .mb { color: var(--accent); }
.about { max-width: 640px; }
.about .badge { display: inline-flex; align-items: center; gap: 12px; margin-bottom: 20px; }
.about .badge { gap: 18px; }
.about .badge .logo { width: 88px; height: 88px; filter: drop-shadow(0 4px 10px rgba(0,0,0,.18)); }
.about .badge b { font-size: 26px; display: block; letter-spacing: -.02em; line-height: 1.15; }
.about h2 { font-size: 18px; margin: 0 0 4px; letter-spacing: -.01em; }
.about .by { color: var(--ink-3); font-size: 13px; margin: 0 0 16px; }
.about p { margin: 0 0 14px; color: var(--ink-2); }
.about .motto { color: var(--ink); font-weight: 600; margin: 0 0 4px; }
.about a { color: var(--accent); font-weight: 600; }
.nav-btn { display: flex; align-items: center; gap: 10px; width: 100%; text-align: left; border: 0; background: none;
  color: var(--ink-2); padding: 9px 10px; border-radius: 9px; cursor: pointer; }
.nav-btn:hover { background: var(--line); color: var(--ink); }
.nav-btn.on { background: var(--panel); color: var(--ink); box-shadow: var(--shadow); font-weight: 600; }
.step-no { width: 22px; height: 22px; border-radius: 50%; border: 1.5px solid var(--line-2); display: grid; place-items: center;
  font-size: 11px; font-weight: 700; color: var(--ink-3); flex: none; }
.nav-btn.on .step-no { border-color: var(--accent); color: var(--accent); }
.nav-sep { height: 1px; background: var(--line); margin: 10px 6px; }
.nav-label { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: var(--ink-3); padding: 14px 10px 6px; }
.side-foot { margin-top: auto; font-size: 12px; color: var(--ink-3); padding: 14px 0 0; }
.side-foot > div, .side-foot > .btn { margin-left: 10px; }
aside .drive { margin: 10px 0 0; }
aside { overflow-y: auto; }
.drive { border: 1px solid var(--line); background: var(--panel); border-radius: 10px; padding: 10px; margin-bottom: 8px; }
.drive .lbl { font-size: 11px; text-transform: uppercase; letter-spacing: .06em; color: var(--ink-3); }
.drive .val { font-family: var(--mono); font-size: 12px; word-break: break-all; margin: 3px 0 6px; }
.dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; background: var(--ink-3); }
.dot.ok { background: var(--keep); } .dot.bad { background: var(--warn); }
main { padding: 28px 36px 120px; max-width: 1100px; width: 100%; min-width: 0; }
h1 { font-size: 24px; letter-spacing: -.02em; margin: 0 0 6px; }
.lede { color: var(--ink-2); margin: 0 0 18px; max-width: 68ch; }
.card { background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); box-shadow: var(--shadow); }
.pad { padding: 16px 18px; }
.btn { border: 1px solid var(--line-2); background: var(--panel); color: var(--ink); padding: 8px 14px; border-radius: 9px;
  cursor: pointer; font-weight: 500; display: inline-flex; align-items: center; gap: 7px; }
.btn:hover { border-color: var(--ink-3); }
.btn.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-ink); }
.btn.primary:hover { filter: brightness(1.06); }
.btn.danger { color: var(--warn); }
.btn.small { padding: 4px 10px; font-size: 12.5px; border-radius: 7px; }
.btn:disabled { opacity: .45; cursor: default; }
.btn svg { width: 14px; height: 14px; fill: currentColor; }
.row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
.safety { display: flex; gap: 10px; align-items: flex-start; background: var(--accent-soft); border-radius: 10px; padding: 10px 14px;
  color: var(--ink); font-size: 13px; margin-bottom: 18px; }
.safety svg { width: 16px; height: 16px; fill: var(--accent); flex: none; margin-top: 2px; }
.banner { border-radius: 10px; padding: 12px 14px; margin-bottom: 16px; font-size: 13.5px; }
.banner.warn { background: var(--warn-soft); color: var(--ink); border: 1px solid color-mix(in srgb, var(--warn) 30%, transparent); }
.banner.note { background: var(--note-soft); }
.banner code, .mono { font-family: var(--mono); font-size: 12px; }
code.cmd { display: block; background: var(--panel-2); border: 1px solid var(--line); padding: 8px 10px; border-radius: 8px;
  margin: 8px 0; white-space: pre-wrap; word-break: break-all; }
.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin: 18px 0; }
.stat { padding: 14px 16px; }
.stat .n { font-size: 24px; font-weight: 650; letter-spacing: -.02em; font-variant-numeric: tabular-nums; }
.stat .l { color: var(--ink-2); font-size: 12.5px; }
.toolbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin: 4px 0 14px; }
.chip { border: 1px solid var(--line-2); background: var(--panel); border-radius: 999px; padding: 5px 12px; cursor: pointer;
  font-size: 12.5px; color: var(--ink-2); }
.chip.on { background: var(--ink); color: var(--bg); border-color: var(--ink); }
.chip .c { opacity: .7; margin-left: 4px; font-variant-numeric: tabular-nums; }
.search { flex: 1; min-width: 180px; border: 1px solid var(--line-2); background: var(--panel); color: var(--ink);
  border-radius: 9px; padding: 7px 11px; font: inherit; }
.group { margin-bottom: 12px; overflow: hidden; }
.group.excluded { opacity: .55; }
.ghead { display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-bottom: 1px solid var(--line); background: var(--panel-2); }
.ghead .gt { font-weight: 600; flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ghead .gn { color: var(--ink-3); font-size: 12px; font-variant-numeric: tabular-nums; }
.toggle { display: inline-flex; gap: 6px; align-items: center; font-size: 12.5px; color: var(--ink-2); cursor: pointer; user-select: none; }
.mrow { display: grid; grid-template-columns: 34px 44px 1fr auto; gap: 12px; align-items: center; padding: 10px 14px;
  border-bottom: 1px solid var(--line); }
.mrow:last-child { border-bottom: 0; }
.mrow.keep { background: var(--keep-soft); }
.mrow.left { background: transparent; }
.play { width: 32px; height: 32px; border-radius: 50%; border: 1px solid var(--line-2); background: var(--panel); cursor: pointer;
  display: grid; place-items: center; color: var(--ink); }
.play svg { width: 13px; height: 13px; fill: currentColor; }
.play.on { background: var(--accent); border-color: var(--accent); color: var(--accent-ink); }
.play:disabled { opacity: .35; cursor: default; }
.thumb { width: 44px; height: 44px; border-radius: 6px; background: var(--line); object-fit: cover; display: block; }
.thumb.none { display: grid; place-items: center; color: var(--ink-3); font-size: 10px; text-align: center; line-height: 1.1; }
.minfo { min-width: 0; }
.mt { font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ms { color: var(--ink-2); font-size: 12.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.mp { font-family: var(--mono); font-size: 11.5px; color: var(--ink-3); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  direction: rtl; text-align: left; }
.tags { display: flex; gap: 5px; flex-wrap: wrap; margin-top: 4px; }
.tag { font-size: 11px; padding: 1px 7px; border-radius: 5px; background: var(--panel-2); border: 1px solid var(--line); color: var(--ink-2);
  font-variant-numeric: tabular-nums; }
.tag.k { background: var(--keep); border-color: var(--keep); color: var(--accent-ink); font-weight: 600; }
.tag.m { background: var(--move-soft); border-color: transparent; color: var(--move); font-weight: 600; }
.tag.n { background: var(--note-soft); border-color: transparent; color: var(--note); }
.mact { display: flex; flex-direction: column; gap: 6px; align-items: flex-end; }
.seg { display: inline-flex; border: 1px solid var(--line-2); border-radius: 8px; overflow: hidden; }
.seg button { border: 0; background: var(--panel); color: var(--ink-2); padding: 4px 10px; font-size: 12px; cursor: pointer; }
.seg button + button { border-left: 1px solid var(--line-2); }
.seg button.on.k { background: var(--keep); color: var(--accent-ink); font-weight: 600; }
.seg button.on.m { background: var(--move-soft); color: var(--move); font-weight: 600; }
.seg button.on.l { background: var(--panel-2); color: var(--ink); font-weight: 600; }
.linkish { border: 0; background: none; color: var(--ink-3); font-size: 12px; cursor: pointer; padding: 0; text-decoration: underline; }
.linkish:hover { color: var(--ink); }
.more { display: flex; justify-content: center; margin: 14px 0; }
.actionbar { position: fixed; left: 236px; right: 0; bottom: 0; padding: 12px 36px; background: color-mix(in srgb, var(--panel) 92%, transparent);
  backdrop-filter: blur(10px); border-top: 1px solid var(--line); display: flex; align-items: center; gap: 14px; z-index: 5; }
.actionbar .sum { flex: 1; color: var(--ink-2); }
.actionbar .sum b { color: var(--ink); }
.progress { margin: 18px 0; padding: 16px 18px; }
.bar { height: 8px; border-radius: 99px; background: var(--line); overflow: hidden; margin-top: 10px; }
.bar > i { display: block; height: 100%; background: var(--accent); width: 0; transition: width .3s; }
.bar.indet > i { width: 30%; animation: slide 1.2s infinite ease-in-out; }
@keyframes slide { 0% { margin-left: -30%; } 100% { margin-left: 100%; } }
.empty { text-align: center; padding: 40px 20px; color: var(--ink-2); }
.empty b { display: block; color: var(--ink); font-size: 16px; margin-bottom: 4px; }
.modal-bg { position: fixed; inset: 0; background: rgba(15,12,8,.42); display: grid; place-items: center; z-index: 20; padding: 16px; }
.modal { max-width: 520px; width: 100%; padding: 22px; }
.modal h2 { margin: 0 0 8px; font-size: 18px; }
.modal p { color: var(--ink-2); margin: 0 0 12px; }
.modal .row { justify-content: flex-end; margin-top: 18px; }
.toast { position: fixed; right: 20px; bottom: 80px; background: var(--ink); color: var(--bg); padding: 10px 14px; border-radius: 10px;
  z-index: 30; max-width: 420px; box-shadow: var(--shadow); }
.toast.err { background: var(--warn); color: #fff; }
.steps { counter-reset: s; list-style: none; padding: 0; margin: 0; }
.steps li { counter-increment: s; position: relative; padding: 0 0 16px 40px; }
.steps li::before { content: counter(s); position: absolute; left: 0; top: 0; width: 26px; height: 26px; border-radius: 50%;
  background: var(--accent-soft); color: var(--accent); font-weight: 700; display: grid; place-items: center; font-size: 13px; }
.steps b { display: block; }
.check { list-style: none; padding: 0; margin: 6px 0 0; }
.check li { padding: 3px 0 3px 22px; position: relative; color: var(--ink-2); }
.check li::before { content: ""; position: absolute; left: 2px; top: 8px; width: 10px; height: 6px; border-left: 2px solid var(--accent);
  border-bottom: 2px solid var(--accent); transform: rotate(-45deg); }
table { width: 100%; border-collapse: collapse; }
th { text-align: left; font-size: 11.5px; text-transform: uppercase; letter-spacing: .05em; color: var(--ink-3); font-weight: 600;
  padding: 10px 10px; border-bottom: 1px solid var(--line); cursor: pointer; white-space: nowrap; user-select: none; position: sticky; top: 0; background: var(--panel); }
td { padding: 8px 10px; border-bottom: 1px solid var(--line); vertical-align: middle; }
td.num { font-variant-numeric: tabular-nums; color: var(--ink-2); white-space: nowrap; }
td .thumb { width: 34px; height: 34px; border-radius: 5px; }
tr.attn td:first-child { box-shadow: inset 3px 0 var(--move); }
.albums { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 16px; }
.album { cursor: default; }
.album .cov { aspect-ratio: 1; width: 100%; border-radius: 10px; object-fit: cover; background: var(--line); display: block; box-shadow: var(--shadow); }
.album .cov.none { display: grid; place-items: center; color: var(--ink-3); font-size: 12px; text-align: center; padding: 10px; }
.album .at { font-weight: 600; margin-top: 8px; font-size: 13px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.album .aa { color: var(--ink-2); font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.runs .run { display: grid; grid-template-columns: 1fr auto; gap: 12px; padding: 14px 16px; border-bottom: 1px solid var(--line); align-items: center; }
.runs .run:last-child { border-bottom: 0; }
.muted { color: var(--ink-3); }
.result { padding: 18px; margin: 18px 0; border-left: 4px solid var(--keep); }
.hidden { display: none !important; }
input[type=range] { accent-color: var(--accent); }
.player-top { display: grid; grid-template-columns: 168px minmax(0, 1fr); gap: 24px; padding: 20px; align-items: center; margin-bottom: 16px; }
.np-cover { width: 168px; height: 168px; border-radius: 12px; object-fit: cover; background: var(--line); box-shadow: var(--shadow); display: block; }
.np-cover.none { display: grid; place-items: center; color: var(--ink-3); }
.np-cover.none svg { width: 54px; height: 54px; fill: var(--line-2); }
.np-title { font-size: 21px; font-weight: 650; letter-spacing: -.015em; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.np-sub { color: var(--ink-2); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.seekrow { display: flex; align-items: center; gap: 10px; margin: 14px 0 12px; font-variant-numeric: tabular-nums; font-size: 12px; color: var(--ink-3); }
.seekrow input { flex: 1; min-width: 0; }
.ctrls { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.cbtn { position: relative; width: 38px; height: 38px; border-radius: 50%; border: 1px solid var(--line-2); background: var(--panel);
  color: var(--ink); display: grid; place-items: center; cursor: pointer; flex: none; }
.cbtn:hover { border-color: var(--ink-3); }
.cbtn svg { width: 15px; height: 15px; fill: currentColor; }
.cbtn.big { width: 52px; height: 52px; background: var(--accent); border-color: var(--accent); color: var(--accent-ink); }
.cbtn.big svg { width: 20px; height: 20px; }
.cbtn.on { color: var(--accent); border-color: var(--accent); background: var(--accent-soft); }
.cbtn .one { position: absolute; right: 3px; top: 2px; font-size: 9px; font-weight: 800; }
.sliders { display: flex; gap: 20px; margin-left: auto; align-items: center; flex-wrap: wrap; font-size: 12.5px; color: var(--ink-2); }
.sliders label { display: flex; align-items: center; gap: 8px; }
.sliders input { width: 110px; }
.sliders b { color: var(--ink); font-weight: 600; min-width: 34px; display: inline-block; font-variant-numeric: tabular-nums; }
.mini { border: 1px solid var(--line); background: var(--panel); border-radius: 10px; padding: 10px; margin-bottom: 10px; }
.mini { margin: 6px 0 4px; }
.mini-title { display: block; width: 100%; text-align: left; border: 0; background: none; padding: 0; cursor: pointer; color: var(--ink); font: inherit; }
.mini-title .mt { display: block; font-size: 13px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.mini-title .ms { display: block; font-size: 12px; color: var(--ink-2); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.mini-title:hover .mt { color: var(--accent); }
.mini .mbar { height: 3px; background: var(--line); border-radius: 3px; margin: 8px 0; overflow: hidden; }
.mini .mbar i { display: block; height: 100%; background: var(--accent); width: 0; }
.mini .cbtn { width: 30px; height: 30px; } .mini .cbtn svg { width: 11px; height: 11px; }
.mini .cbtn.big { width: 34px; height: 34px; } .mini .cbtn.big svg { width: 13px; height: 13px; }
tr.now td { background: var(--accent-soft); }
tr.now .mt { color: var(--accent); }
tbody tr[data-row] { cursor: default; }
tbody tr[data-row]:hover td { background: var(--panel-2); }
tbody tr.now[data-row]:hover td { background: var(--accent-soft); }
.srcs .src { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid var(--line); }
.srcs .src:last-child { border-bottom: 0; }
.srcs .src .mono { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dirlist { max-height: 320px; overflow: auto; border: 1px solid var(--line); border-radius: 8px; margin: 10px 0 0; }
.dirlist button { display: flex; width: 100%; text-align: left; border: 0; border-bottom: 1px solid var(--line); background: var(--panel);
  color: var(--ink); padding: 8px 12px; cursor: pointer; gap: 8px; align-items: center; }
.dirlist button:last-child { border-bottom: 0; }
.dirlist button:hover { background: var(--panel-2); }
.dirlist svg { width: 14px; height: 14px; fill: var(--ink-3); flex: none; }
.modal.wide { max-width: 600px; }
.cv-card { margin-bottom: 14px; }
.cv-card h3 { margin: 0 0 12px; font-size: 14.5px; display: flex; align-items: center; gap: 8px; }
.cv-card h3 .n { width: 22px; height: 22px; border-radius: 50%; background: var(--accent-soft); color: var(--accent); display: grid; place-items: center; font-size: 12px; }
.cv-row { display: grid; grid-template-columns: 150px minmax(0, 1fr) auto; gap: 12px; align-items: center; padding: 8px 0; }
.cv-row + .cv-row { border-top: 1px solid var(--line); }
.cv-row .lbl { color: var(--ink-2); font-size: 13px; }
.cv-path { font-family: var(--mono); font-size: 12.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; direction: rtl; text-align: left; }
.cv-path.none { font-family: inherit; color: var(--ink-3); direction: ltr; }
.fmt-grid { display: flex; flex-wrap: wrap; gap: 8px; }
.fmt { display: inline-flex; align-items: center; gap: 7px; border: 1px solid var(--line-2); border-radius: 9px; padding: 7px 12px; cursor: pointer; user-select: none; background: var(--panel); }
.fmt.on { border-color: var(--accent); background: var(--accent-soft); }
.fmt small { color: var(--ink-3); font-size: 11px; }
.radio { display: flex; gap: 8px; align-items: center; cursor: pointer; }
select.sel { border: 1px solid var(--line-2); background: var(--panel); color: var(--ink); border-radius: 9px; padding: 7px 10px; font: inherit; }
.opts { display: flex; gap: 18px; flex-wrap: wrap; margin-top: 12px; }
.cv-table td, .cv-table th { padding: 8px 12px; }
@media (max-width: 820px) { .cv-row { grid-template-columns: minmax(0, 1fr); gap: 6px; } }
.eq { display: inline-flex; gap: 2px; align-items: flex-end; height: 12px; }
.eq i { width: 3px; background: var(--accent); animation: eq 0.9s infinite ease-in-out; }
.eq i:nth-child(2) { animation-delay: .2s; } .eq i:nth-child(3) { animation-delay: .4s; }
.eq.paused i { animation: none; height: 4px; }
.play.on .eq i { background: var(--accent-ink); }
@keyframes eq { 0%, 100% { height: 3px; } 50% { height: 12px; } }
@media (max-width: 820px) {
  .app { grid-template-columns: minmax(0, 1fr); }
  aside { position: static; height: auto; border-right: 0; border-bottom: 1px solid var(--line); }
  main { padding: 20px 16px 140px; }
  .actionbar { left: 0; padding: 12px 16px; }
  .mrow { grid-template-columns: 34px 1fr; }
  .mrow .thumb-cell { display: none; }
  .mrow .mact { grid-column: 1 / -1; flex-direction: row; justify-content: flex-start; }
  .player-top { grid-template-columns: minmax(0, 1fr); }
  .np-cover { width: 120px; height: 120px; }
  .sliders { margin-left: 0; }
  td.hide-sm, th.hide-sm { display: none; }
}
</style>
</head>
<body>
<div class="app">
  <aside>
    <div class="brand"><img class="logo" src="__ICON__" alt=""><div><b>Kalya <span class="mb">MusicBox</span></b><div class="ver">MP3 Manager &amp; Music Player</div></div></div>
    <div class="nav-label">Player</div>
    <button class="nav-btn" data-page="player"><span class="step-no">♪</span>Player</button>
    <div class="mini hidden" id="mini"></div>
    <div class="nav-label">Utilities</div>
    <button class="nav-btn" data-page="convert"><span class="step-no">⇄</span>Convert to MP3</button>
    <button class="nav-btn" data-page="dupes"><span class="step-no">1</span>Find duplicates</button>
    <button class="nav-btn" data-page="picard"><span class="step-no">2</span>Tag with Picard</button>
    <button class="nav-btn" data-page="recordings"><span class="step-no">3</span>Same recording</button>
    <button class="nav-btn" data-page="catalog"><span class="step-no">4</span>Build catalog</button>
    <button class="nav-btn" data-page="history"><span class="step-no">↺</span>History &amp; undo</button>
    <div class="drive">
      <div class="lbl">Music drive for utilities</div>
      <div class="val" id="drivePath">…</div>
      <div class="row" style="justify-content:space-between"><span id="driveState" class="muted" style="font-size:12px"></span>
        <button class="linkish" id="changeDrive">Change</button></div>
    </div>
    <div class="side-foot">
      <button class="nav-btn" data-page="about"><span class="step-no">i</span>About</button>
      <div style="margin:8px 0 10px">Kalya MusicBox Ver 1.0<br>Developed by Durgesh Kalya</div>
      <button class="btn small" id="quitBtn">Quit Kalya MusicBox</button>
    </div>
  </aside>
  <main id="main"></main>
</div>
<div class="actionbar hidden" id="actionbar"></div>
<audio id="player" preload="none"></audio>

<script>
"use strict";
const TOKEN = "__TOKEN__";
const ICON = {
  play: '<svg viewBox="0 0 16 16"><path d="M4 2.5v11l9-5.5z"/></svg>',
  pause: '<svg viewBox="0 0 16 16"><path d="M4 2h3v12H4zM9 2h3v12H9z"/></svg>',
  folder: '<svg viewBox="0 0 16 16"><path d="M1 3.5A1.5 1.5 0 0 1 2.5 2h3.6l1.5 1.5h5.9A1.5 1.5 0 0 1 15 5v7.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 1 12.5z"/></svg>',
  prev: '<svg viewBox="0 0 16 16"><path d="M3 2h2v12H3zM14 2.5v11L6 8z"/></svg>',
  next: '<svg viewBox="0 0 16 16"><path d="M11 2h2v12h-2zM2 2.5v11L10 8z"/></svg>',
  shuffle: '<svg viewBox="0 0 16 16"><path d="M11.5 1.5 15 4.25 11.5 7V5.25H10L5.25 11H1v-1.5h3.55l4.75-5.75h2.2zM1 4.5h4.25l1.6 1.95-.97 1.18L4.55 6H1zm8.07 4.37L10 10.25h1.5V8.5L15 11.25 11.5 14v-1.75H9.3l-1.2-1.45z"/></svg>',
  repeat: '<svg viewBox="0 0 16 16"><path d="M4 4h7V2l3 3-3 3V6H5v3H3V5a1 1 0 0 1 1-1zm8 3h2v4a1 1 0 0 1-1 1H6v2l-3-3 3-3v2h6z"/></svg>',
  note: '<svg viewBox="0 0 24 24"><path d="M9 3v11.6A3.5 3.5 0 1 0 11 18V8h6V3H9z"/></svg>',
  popout: '<svg viewBox="0 0 16 16"><path d="M9 1h6v6h-2V4.4L8.7 8.7 7.3 7.3 11.6 3H9zM2 3h5v2H3v8h8V9h2v5a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/></svg>',
  plus: '<svg viewBox="0 0 16 16"><path d="M7 2h2v5h5v2H9v5H7V9H2V7h5z"/></svg>',
  shield: '<svg viewBox="0 0 16 16"><path d="M8 1 2 3.5v4C2 11 4.6 14 8 15c3.4-1 6-4 6-7.5v-4zm-1 10L4.3 8.3l1-1L7 9l3.7-3.7 1 1z"/></svg>',
};
const st = {
  status: null, page: "player",
  plan: { dupes: null, recordings: null },
  dec: { dupes: {}, recordings: {} },
  filter: { dupes: "all", recordings: "all" },
  query: { dupes: "", recordings: "" },
  shown: { dupes: 40, recordings: 40 },
  result: { dupes: null, recordings: null },
  across: false,
  catalog: null, catView: "albums", catQuery: "", catAttn: false, catSort: ["artist", 1], catShown: 200,
  runs: null, job: null, playing: null,
  pl: { tracks: null, sources: [], scanned_at: null, query: "", sort: ["artist", 1], shown: 300 },
  cv: null,
};

// ---------- helpers ----------
const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtSize = (b) => b >= 1073741824 ? (b / 1073741824).toFixed(1) + " GB" : b >= 1048576 ? (b / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(b / 1024)) + " KB";
const fmtTime = (s) => { s = +s || 0; return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
const plural = (n, w) => n + " " + w + (n === 1 ? "" : "s");
const media = (kind, p) => "/media/" + kind + "?t=" + encodeURIComponent(TOKEN) + "&p=" + encodeURIComponent(p);
const canPlay = (p) => !/\.(wma|aiff?)$/i.test(p);

async function api(path, body) {
  const opt = body === undefined ? { headers: { "X-Token": TOKEN } }
    : { method: "POST", headers: { "X-Token": TOKEN, "Content-Type": "application/json" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  let data = {};
  try { data = await r.json(); } catch (e) {}
  if (!r.ok) throw new Error(data.error || ("Request failed (" + r.status + ")"));
  return data;
}
function toast(msg, err) {
  const t = document.createElement("div");
  t.className = "toast" + (err ? " err" : "");
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), err ? 7000 : 3500);
}
function confirmBox(title, html, okLabel, danger) {
  return new Promise((res) => {
    const bg = document.createElement("div");
    bg.className = "modal-bg";
    bg.innerHTML = '<div class="modal card"><h2>' + esc(title) + "</h2>" + html +
      '<div class="row"><button class="btn" data-a="0">Cancel</button><button class="btn ' + (danger ? "danger" : "primary") + '" data-a="1">' + esc(okLabel) + "</button></div></div>";
    bg.addEventListener("click", (e) => {
      const a = e.target.getAttribute("data-a");
      if (a !== null || e.target === bg) { bg.remove(); res(a === "1"); }
    });
    document.body.appendChild(bg);
    $('[data-a="1"]', bg).focus();
  });
}
async function openThing(what, path) {
  try { await api("/api/open", { what, path }); } catch (e) { toast(e.message, true); }
}

// ---------- jobs ----------
async function runJob(startPath, body, onDone) {
  let j;
  try { j = await api(startPath, body); } catch (e) { toast(e.message, true); return; }
  st.job = { id: j.job, label: "Starting…", i: 0, total: 0, running: true };
  render();
  await pollJob(j.job, onDone);
}
async function pollJob(id, onDone) {
  for (;;) {
    let d;
    try { d = await api("/api/job?id=" + id); } catch (e) { toast(e.message, true); st.job = null; render(); return; }
    st.job = d.job;
    if (!d.job.running) {
      st.job = null;
      if (d.job.error) { toast(d.job.error, true); render(); return; }
      if (onDone) onDone(d.result);
      render();
      return;
    }
    renderProgressOnly();
    await new Promise((r) => setTimeout(r, 450));
  }
}
function progressHtml() {
  const j = st.job;
  if (!j) return "";
  const pct = j.total ? Math.floor((j.i * 100) / j.total) : 0;
  return '<div class="card progress" id="progress"><div class="row" style="justify-content:space-between"><b id="pLabel">' + esc(j.label) +
    '</b><span class="muted" id="pCount">' + (j.total ? j.i.toLocaleString() + " of " + j.total.toLocaleString() + " · " + pct + "%" : "") +
    '</span></div><div class="bar ' + (j.total ? "" : "indet") + '" id="pBar"><i style="width:' + pct + '%"></i></div>' +
    '<div class="muted" style="margin-top:8px;font-size:12.5px">You can leave this window open; large drives can take a while. The first scan reads every file; later scans are much faster.</div></div>';
}
function renderProgressOnly() {
  const el = $("#progress");
  if (!el) { render(); return; }
  const j = st.job, pct = j.total ? Math.floor((j.i * 100) / j.total) : 0;
  $("#pLabel").textContent = j.label;
  $("#pCount").textContent = j.total ? j.i.toLocaleString() + " of " + j.total.toLocaleString() + " · " + pct + "%" : "";
  $("#pBar").className = "bar " + (j.total ? "" : "indet");
  $("#pBar i").style.width = pct + "%";
}

// ---------- status & setup ----------
async function refreshStatus() {
  try { st.status = await api("/api/status"); } catch (e) { toast(e.message, true); return; }
  const s = st.status;
  $("#drivePath").textContent = s.root;
  $("#driveState").innerHTML = s.drive_ok ? '<span class="dot ok"></span>Connected' : '<span class="dot bad"></span>Not found';
  if (s.job && s.job.running && !st.job) { st.job = s.job; render(); pollJob(s.job.id, null); }
}
function setupBanner() {
  const s = st.status;
  if (!s) return "";
  if (!s.drive_ok) return '<div class="banner warn"><b>The music drive isn\'t connected.</b> Plug in ' + esc(s.root) +
    ' or click <i>Change</i> in the sidebar to choose your music drive or folder.</div>';
  if (!s.mutagen_ok) return '<div class="banner warn"><b>One more install is needed to read song tags.</b>' + (s.installed ? "" : " In Terminal, run:") +
    (s.installed ? " Run <i>Install Kalya MusicBox</i> again to repair it.</div>" :
    '<code class="cmd">python3 -m venv ~/mp3venv &amp;&amp; ~/mp3venv/bin/pip install mutagen</code>then start Kalya MusicBox with <code>~/mp3venv/bin/python</code>.</div>');
  if (!s.project_ok) return '<div class="banner note"><div class="row" style="justify-content:space-between"><div><b>Set up MP3_Project on this drive.</b><br>' +
    'Creates the Library, review and reports folders' + (s.is_mac && !s.installed ? ", and a <i>Kalya MusicBox</i> launcher on your Desktop" : "") +
    '.</div><button class="btn primary" id="setupBtn">Set up</button></div></div>';
  return "";
}
async function doSetup() {
  try {
    const r = await api("/api/setup", {});
    st.status = r.status;
    toast("MP3_Project is ready." + (r.launcher ? " A launcher was added to your Desktop." : ""));
    render();
  } catch (e) { toast(e.message, true); }
}

// ---------- duplicate review (steps 1 and 3) ----------
function decisionFor(kind, g) {
  const d = st.dec[kind][g.id] || (st.dec[kind][g.id] = { keep: g.keep, skip: {}, exclude: false });
  return d;
}
function memberState(kind, g, m) {
  const d = decisionFor(kind, g);
  if (m.path === d.keep) return "keep";
  if (d.exclude || d.skip[m.path]) return "leave";
  return "move";
}
function matchLabel(kind, g, m, keepM) {
  if (kind === "dupes") return m.fh && keepM.fh === m.fh ? "identical file" : "same audio, different tags";
  return g.label;
}
function albumDiffers(g) {
  const albums = new Set(g.members.map((m) => (m.album || "").toLowerCase()));
  return albums.size > 1;
}
function groupTitle(g) {
  const k = g.members.find((m) => m.suggested_keep) || g.members[0];
  const t = k.title || k.path.split("/").pop();
  return t + (k.artist ? " — " + k.artist : "");
}
function filteredGroups(kind) {
  const plan = st.plan[kind];
  if (!plan) return [];
  const f = st.filter[kind], q = st.query[kind].trim().toLowerCase();
  return plan.groups.filter((g) => {
    const d = decisionFor(kind, g);
    if (f === "identical" && !g.members.some((m) => !m.suggested_keep && m.match === "identical file")) return false;
    if (f === "tags" && !g.members.some((m) => !m.suggested_keep && m.match === "same audio, different tags")) return false;
    if (f === "album" && !albumDiffers(g)) return false;
    if (f === "skipped" && !d.exclude && !Object.keys(d.skip).length && d.keep === g.keep) return false;
    if (q && !g.members.some((m) => (m.title + " " + m.artist + " " + m.album + " " + m.path).toLowerCase().includes(q))) return false;
    return true;
  });
}
function totals(kind) {
  const plan = st.plan[kind];
  let n = 0, b = 0;
  if (!plan) return { n, b };
  for (const g of plan.groups) for (const m of g.members) if (memberState(kind, g, m) === "move") { n++; b += m.size; }
  return { n, b };
}
function memberRow(kind, g, m) {
  const d = decisionFor(kind, g);
  const state = memberState(kind, g, m);
  const keepM = g.members.find((x) => x.path === d.keep);
  const tags = [];
  if (state === "keep") tags.push('<span class="tag k">Keep</span>');
  else if (state === "move") tags.push('<span class="tag m">Move to review</span>');
  else tags.push('<span class="tag">Leave in place</span>');
  if (m.bitrate_kbps) tags.push('<span class="tag">' + m.bitrate_kbps + " kbps</span>");
  if (m.seconds) tags.push('<span class="tag">' + fmtTime(m.seconds) + "</span>");
  tags.push('<span class="tag">' + fmtSize(m.size) + "</span>");
  tags.push('<span class="tag">' + (m.has_cover ? "cover art" : "no cover") + "</span>");
  if (state !== "keep") {
    tags.push('<span class="tag">' + esc(matchLabel(kind, g, m, keepM)) + "</span>");
    if ((m.album || "").toLowerCase() !== (keepM.album || "").toLowerCase()) tags.push('<span class="tag n">album differs</span>');
  }
  let why = "";
  if (state !== "keep") why = d.keep === g.keep ? m.why.replace(/\s+NOTE:.*$/, "") : "you chose which copy to keep";
  const playing = st.playing === m.path;
  const thumb = m.has_cover ? '<img class="thumb" loading="lazy" src="' + media("cover", m.path) + '" alt="">' : '<div class="thumb none">no<br>cover</div>';
  return '<div class="mrow ' + state + '">' +
    '<button class="play' + (playing ? " on" : "") + '" data-play="' + esc(m.path) + '" title="Listen"' + (canPlay(m.path) ? "" : " disabled") + ">" + (playing ? ICON.pause : ICON.play) + "</button>" +
    '<div class="thumb-cell">' + thumb + "</div>" +
    '<div class="minfo"><div class="mt">' + esc(m.title || m.path.split("/").pop()) + '</div><div class="ms">' + esc([m.artist, m.album].filter(Boolean).join(" · ") || "No artist or album tags") +
    '</div><div class="mp" title="' + esc(m.path) + '">&lrm;' + esc(m.path) + "&lrm;</div>" + '<div class="tags">' + tags.join("") + "</div>" +
    (why ? '<div class="muted" style="font-size:12px;margin-top:3px">' + esc(why) + "</div>" : "") + "</div>" +
    '<div class="mact"><div class="seg">' +
    '<button class="k' + (state === "keep" ? " on" : "") + '" data-keep="' + esc(m.path) + '" data-g="' + g.id + '">Keep</button>' +
    (state === "keep" ? "" : '<button class="m' + (state === "move" ? " on" : "") + '" data-move="' + esc(m.path) + '" data-g="' + g.id + '"' + (d.exclude ? " disabled" : "") + ">Move</button>" +
      '<button class="l' + (state === "leave" ? " on" : "") + '" data-leave="' + esc(m.path) + '" data-g="' + g.id + '"' + (d.exclude ? " disabled" : "") + ">Leave</button>") +
    '</div><button class="linkish" data-reveal="' + esc(m.path) + '">Show in Finder</button></div></div>';
}
function groupCard(kind, g) {
  const d = decisionFor(kind, g);
  return '<div class="card group' + (d.exclude ? " excluded" : "") + '"><div class="ghead"><span class="gt">' + esc(groupTitle(g)) +
    '</span><span class="gn">Group ' + g.id + " · " + g.members.length + " copies</span>" +
    '<label class="toggle"><input type="checkbox" data-exclude="' + g.id + '"' + (d.exclude ? " checked" : "") + "> Skip this group</label></div>" +
    g.members.map((m) => memberRow(kind, g, m)).join("") + "</div>";
}
function reviewPage(kind) {
  const plan = st.plan[kind], res = st.result[kind];
  const isD = kind === "dupes";
  let h = "<h1>" + (isD ? "Find duplicates" : "Same recording") + "</h1>";
  h += '<p class="lede">' + (isD
    ? "Finds copies of the same song by comparing the actual audio, not file names. Catches exact copies and copies that were renamed or retagged. Songs that only share a name are never matched."
    : "After tagging with Picard, every identified song has a MusicBrainz recording ID. Copies with the same ID are the same recording, even if they were ripped at different bitrates. The highest-quality copy is suggested to keep.") + "</p>";
  h += '<div class="safety">' + ICON.shield + "<div>Nothing is deleted. Copies you choose are <b>moved</b> to <span class=mono>MP3_Project/_Duplicates_Review</span>, each one is checked again just before it moves, and every run can be put back from <i>History &amp; undo</i>.</div></div>";
  h += setupBanner();
  if (!isD) h += '<div class="row" style="margin-bottom:14px"><label class="toggle"><input type="checkbox" id="across"' + (st.across ? " checked" : "") +
    '> Also match the same song on <b>&nbsp;different albums&nbsp;</b> (e.g. album + greatest-hits copy)</label></div>';
  const ready = st.status && st.status.drive_ok && st.status.mutagen_ok && st.status.project_ok;
  h += '<div class="row"><button class="btn primary" id="scanBtn"' + (ready && !st.job ? "" : " disabled") + ">" + (plan ? "Scan again" : "Scan the drive") + "</button>" +
    (plan && plan.report ? '<button class="btn" data-open="' + esc(plan.report) + '">Open report (spreadsheet)</button>' : "") + "</div>";
  if (st.job) h += progressHtml();
  if (res) {
    h += '<div class="card result"><b style="font-size:16px">Moved ' + plural(res.moved, "file") + " (" + fmtSize(res.freed) + ") to the review folder.</b>" +
      (res.skipped ? '<div class="muted">' + plural(res.skipped, "file") + " skipped because they changed since the scan; they were left in place.</div>" : "") +
      '<div class="row" style="margin-top:12px"><button class="btn" data-folder="' + esc(res.review_dir) + '">' + ICON.folder + "Open review folder</button>" +
      '<button class="btn" data-open="' + esc(res.manifest) + '">Open move record</button>' +
      '<button class="btn danger" data-undo="' + esc(res.manifest) + '">Undo this run</button></div>' +
      '<div class="muted" style="margin-top:10px;font-size:12.5px">Listen to anything you\'re unsure about. When you\'re happy, delete that run\'s folder in Finder to free the space.</div></div>';
  }
  if (!plan) {
    if (!st.job && !res) h += '<div class="card empty" style="margin-top:18px"><b>No scan yet</b>Click <i>Scan the drive</i>. Nothing is changed until you review the results and confirm.</div>';
    return h;
  }
  const t = totals(kind);
  h += '<div class="stats">' +
    '<div class="card stat"><div class="n">' + plan.files_scanned.toLocaleString() + '</div><div class="l">music files checked</div></div>' +
    (isD ? "" : '<div class="card stat"><div class="n">' + plan.files_with_id.toLocaleString() + '</div><div class="l">have a MusicBrainz ID</div></div>') +
    '<div class="card stat"><div class="n">' + plan.groups.length.toLocaleString() + '</div><div class="l">songs with duplicates</div></div>' +
    '<div class="card stat"><div class="n">' + t.n.toLocaleString() + '</div><div class="l">copies to move</div></div>' +
    '<div class="card stat"><div class="n">' + fmtSize(t.b) + '</div><div class="l">space to free</div></div></div>';
  if (!isD && plan.files_with_id < plan.files_scanned) h += '<div class="banner note">' + (plan.files_scanned - plan.files_with_id).toLocaleString() +
    " files have no MusicBrainz ID yet, so they aren't checked here. Tag them with Picard (step 2) first.</div>";
  if (plan.errors && plan.errors.length) h += '<div class="banner warn">' + plural(plan.errors.length, "file") + " couldn't be read and were left alone.</div>";
  if (!plan.groups.length) return h + '<div class="card empty"><b>No duplicates found</b>Every song on the drive is unique by this check.</div>';
  const all = plan.groups;
  const counts = {
    all: all.length,
    identical: all.filter((g) => g.members.some((m) => m.match === "identical file")).length,
    tags: all.filter((g) => g.members.some((m) => m.match === "same audio, different tags")).length,
    album: all.filter(albumDiffers).length,
  };
  const chips = isD ? [["all", "All"], ["identical", "Identical files"], ["tags", "Same audio, different tags"], ["album", "Album tags differ"], ["skipped", "Changed by you"]]
    : [["all", "All"], ["album", "Album tags differ"], ["skipped", "Changed by you"]];
  h += '<div class="toolbar">' + chips.map(([k, l]) => '<button class="chip' + (st.filter[kind] === k ? " on" : "") + '" data-filter="' + k + '">' + l +
    (counts[k] !== undefined ? '<span class="c">' + counts[k] + "</span>" : "") + "</button>").join("") +
    '<input class="search" id="q" placeholder="Search title, artist, album or folder" value="' + esc(st.query[kind]) + '"></div>';
  const list = filteredGroups(kind);
  h += '<div id="groups">' + list.slice(0, st.shown[kind]).map((g) => groupCard(kind, g)).join("") + "</div>";
  if (!list.length) h += '<div class="card empty"><b>Nothing matches</b>Try another filter or search.</div>';
  if (list.length > st.shown[kind]) h += '<div class="more"><button class="btn" id="moreBtn">Show more (' + (list.length - st.shown[kind]).toLocaleString() + " left)</button></div>";
  return h;
}
function actionBar() {
  const bar = $("#actionbar");
  const kind = st.page;
  if ((kind !== "dupes" && kind !== "recordings") || !st.plan[kind] || st.job) { bar.classList.add("hidden"); return; }
  const t = totals(kind);
  bar.classList.remove("hidden");
  bar.innerHTML = '<div class="sum"><b>' + plural(t.n, "copy").replace("copys", "copies") + "</b> (" + fmtSize(t.b) + ") will be moved to the review folder. " +
    'Use <b>Keep</b>, <b>Move</b> or <b>Leave</b> on any song to change this.</div><button class="btn primary" id="applyBtn"' + (t.n ? "" : " disabled") + ">Move to review…</button>";
}
async function applyPlan(kind) {
  const plan = st.plan[kind], t = totals(kind);
  const ok = await confirmBox("Move " + plural(t.n, "copy").replace("copys", "copies") + " to review?",
    "<p>" + fmtSize(t.b) + " will be moved into <span class=mono>MP3_Project/_Duplicates_Review/" + esc(plan.name) + "</span>, keeping their folder structure.</p>" +
    "<p>Each file is checked again just before it moves. Nothing is deleted, and you can put everything back from <i>History &amp; undo</i>.</p>", "Move to review");
  if (!ok) return;
  const decisions = {};
  for (const g of plan.groups) {
    const d = st.dec[kind][g.id];
    if (!d) continue;
    decisions[g.id] = { keep: d.keep, skip: Object.keys(d.skip), exclude_group: d.exclude };
  }
  await runJob("/api/apply", { plan: plan.name, decisions }, (r) => {
    st.result[kind] = r; st.plan[kind] = null; st.dec[kind] = {}; st.runs = null;
    toast("Moved " + plural(r.moved, "file") + " to review.");
  });
}

// ---------- Picard ----------
function picardPage() {
  const s = st.status || {};
  const lib = "MP3_Project/Library";
  let h = "<h1>Tag with Picard</h1><p class=\"lede\">MusicBrainz Picard is a free app that recognises each song by its sound, then adds the correct title, artist, album, track number, year and cover art, and files it into <span class=mono>" + lib + "/Artist/Album/</span>.</p>";
  h += setupBanner();
  h += '<div class="row" style="margin-bottom:18px">' + (s.picard ? '<button class="btn primary" id="openPicard">Open Picard</button>' :
    '<a class="btn primary" href="https://picard.musicbrainz.org/" target="_blank" rel="noopener">Get Picard (free)</a>') +
    '<button class="btn" data-folder="' + lib + '">' + ICON.folder + "Open Library folder</button></div>";
  if (!s.picard) h += '<div class="banner note">Or install it from Terminal: <code class="cmd">brew install --cask musicbrainz-picard</code></div>';
  h += '<div class="card pad"><ol class="steps">' +
    "<li><b>One-time settings</b>Open Picard → Settings and set:<ul class=check>" +
    "<li><i>Cover Art</i>: turn on embedding cover images into tags</li>" +
    "<li><i>File Naming</i>: turn on <i>Move files when saving</i> and <i>Rename files when saving</i></li>" +
    "<li>Destination folder: <span class=mono>" + esc((s.root || "/Volumes/MUSIC-DK") + "/" + lib) + "</span></li>" +
    "<li>Turn on deleting empty folders</li>" +
    "<li><i>Tags → ID3</i>: choose version 2.3 (best for car stereos and older players)</li></ul></li>" +
    "<li><b>Work in batches of a few hundred songs</b>Drag a folder from <span class=mono>Music</span> or <span class=mono>Music_1</span> into Picard. Very large batches make it slow.</li>" +
    "<li><b>Click Scan</b>Picard listens to each song and finds its match, even with bad file names or no tags.</li>" +
    "<li><b>Check, then Save</b>Matched songs move into the Library with full tags and cover art. Unmatched songs stay where they are.</li>" +
    "<li><b>Repeat, then go to step 3</b>Once everything is tagged, <i>Same recording</i> finds remaining duplicates such as a 128 kbps and a 320 kbps copy.</li></ol></div>";
  return h;
}

// ---------- catalog ----------
async function loadCatalog() {
  try { st.catalog = await api("/api/catalog"); } catch (e) { toast(e.message, true); st.catalog = { rows: null }; }
  render();
}
function catalogPage() {
  let h = '<h1>Catalog</h1><p class="lede">Every song on the drive with its tags and cover art, plus what still needs attention. Also saved as a spreadsheet in <span class=mono>MP3_Project/reports</span>.</p>';
  h += setupBanner();
  const ready = st.status && st.status.drive_ok && st.status.mutagen_ok && st.status.project_ok;
  const c = st.catalog;
  h += '<div class="row"><button class="btn primary" id="catBtn"' + (ready && !st.job ? "" : " disabled") + ">" + (c && c.rows ? "Rebuild catalog" : "Build catalog") + "</button>" +
    (c && c.csv ? '<button class="btn" data-open="' + esc(c.csv) + '">Open spreadsheet</button>' : "") + "</div>";
  if (st.job) h += progressHtml();
  if (!c) { setTimeout(loadCatalog, 0); return h + '<div class="card empty" style="margin-top:18px">Loading…</div>'; }
  if (!c.rows) return h + (st.job ? "" : '<div class="card empty" style="margin-top:18px"><b>No catalog yet</b>Click <i>Build catalog</i> to read every song\'s tags.</div>');
  const s = c.stats;
  h += '<div class="stats">' + [[s.songs, "songs"], [s.albums, "albums"], [s.artists, "artists"], [s.no_cover, "missing cover art"], [s.attention, "need attention"]]
    .map(([n, l]) => '<div class="card stat"><div class="n">' + n.toLocaleString() + '</div><div class="l">' + l + "</div></div>").join("") + "</div>";
  h += '<div class="toolbar"><button class="chip' + (st.catView === "albums" ? " on" : "") + '" data-catview="albums">Albums</button>' +
    '<button class="chip' + (st.catView === "songs" ? " on" : "") + '" data-catview="songs">Songs</button>' +
    '<label class="toggle" style="margin-left:6px"><input type="checkbox" id="catAttn"' + (st.catAttn ? " checked" : "") + "> Only needs attention</label>" +
    '<input class="search" id="cq" placeholder="Search title, artist, album or folder" value="' + esc(st.catQuery) + '"></div>';
  const q = st.catQuery.trim().toLowerCase();
  let rows = c.rows.filter((r) => (!st.catAttn || r.needs_attention) &&
    (!q || (r.title + " " + r.artist + " " + r.album + " " + r.path).toLowerCase().includes(q)));
  if (st.catView === "albums") {
    const map = new Map();
    for (const r of rows) {
      const art = r.albumartist || r.artist || "Unknown artist", alb = r.album || "No album tag";
      const k = art + "\u0000" + alb;
      if (!map.has(k)) map.set(k, { art, alb, n: 0, cover: null, attn: 0 });
      const a = map.get(k);
      a.n++; if (!a.cover && r.has_cover === "yes") a.cover = r.path; if (r.needs_attention) a.attn++;
    }
    const albums = [...map.values()].sort((a, b) => a.art.localeCompare(b.art) || a.alb.localeCompare(b.alb));
    h += '<div class="albums">' + albums.slice(0, st.catShown).map((a) =>
      '<div class="album" title="' + esc(a.art + " — " + a.alb) + '">' + (a.cover ? '<img class="cov" loading="lazy" src="' + media("cover", a.cover) + '" alt="">' : '<div class="cov none">No cover art</div>') +
      '<div class="at">' + esc(a.alb) + '</div><div class="aa">' + esc(a.art) + " · " + plural(a.n, "song") + "</div>" + (a.attn ? '<div class="aa" style="color:var(--move)">' + a.attn + " need attention</div>" : "") + "</div>").join("") + "</div>";
    if (albums.length > st.catShown) h += '<div class="more"><button class="btn" id="catMore">Show more (' + (albums.length - st.catShown).toLocaleString() + " left)</button></div>";
    if (!albums.length) h += '<div class="card empty"><b>Nothing matches</b></div>';
    return h;
  }
  const [key, dir] = st.catSort;
  const numeric = key === "seconds" || key === "bitrate_kbps" || key === "tracknumber";
  rows = rows.slice().sort((a, b) => {
    const x = a[key] || "", y = b[key] || "";
    const v = numeric ? (parseInt(x) || 0) - (parseInt(y) || 0) : x.localeCompare(y);
    return v * dir || a.path.localeCompare(b.path);
  });
  const cols = [["", ""], ["title", "Title"], ["artist", "Artist"], ["album", "Album"], ["tracknumber", "#"], ["seconds", "Time"], ["bitrate_kbps", "kbps"], ["needs_attention", "Needs"]];
  h += '<div class="card" style="overflow:auto"><table><thead><tr>' + cols.map(([k, l]) => "<th" + (k ? ' data-sort="' + k + '"' : "") + ">" + l + (k === key ? (dir > 0 ? " ↑" : " ↓") : "") + "</th>").join("") + "</tr></thead><tbody>" +
    rows.slice(0, st.catShown).map((r) => '<tr class="' + (r.needs_attention ? "attn" : "") + '"><td style="width:46px">' +
      '<button class="play' + (st.playing === r.path ? " on" : "") + '" data-play="' + esc(r.path) + '"' + (canPlay(r.path) ? "" : " disabled") + ">" + (st.playing === r.path ? ICON.pause : ICON.play) + "</button></td>" +
      '<td><div class="row" style="flex-wrap:nowrap">' + (r.has_cover === "yes" ? '<img class="thumb" loading="lazy" src="' + media("cover", r.path) + '" alt="">' : "") +
      '<div class="minfo"><div class="mt">' + esc(r.title || r.path.split("/").pop()) + '</div><div class="mp" title="' + esc(r.path) + '">&lrm;' + esc(r.path) + "&lrm;</div></div></div></td>" +
      "<td>" + esc(r.artist) + "</td><td>" + esc(r.album) + '</td><td class="num">' + esc(r.tracknumber) + '</td><td class="num">' + fmtTime(r.seconds) +
      '</td><td class="num">' + esc(r.bitrate_kbps) + '</td><td style="color:var(--move);font-size:12.5px">' + esc(r.needs_attention.replace(/^missing /, "")) + "</td></tr>").join("") +
    "</tbody></table></div>";
  if (rows.length > st.catShown) h += '<div class="more"><button class="btn" id="catMore">Show more (' + (rows.length - st.catShown).toLocaleString() + " left)</button></div>";
  return h;
}

// ---------- history ----------
async function loadRuns() {
  try { st.runs = (await api("/api/runs")).runs; } catch (e) { toast(e.message, true); st.runs = []; }
  render();
}
function historyPage() {
  let h = '<h1>History &amp; undo</h1><p class="lede">Every run that moved files. <b>Undo</b> puts every file from that run back where it was. To free the space for good, delete a run\'s folder in Finder once you\'ve checked it.</p>';
  h += setupBanner();
  if (st.job) h += progressHtml();
  if (st.runs === null) { setTimeout(loadRuns, 0); return h + '<div class="card empty">Loading…</div>'; }
  if (!st.runs.length) return h + '<div class="card empty"><b>Nothing moved yet</b>Runs from steps 1 and 3 will be listed here.</div>';
  h += '<div class="row" style="margin-bottom:12px"><button class="btn" data-folder="MP3_Project/_Duplicates_Review">' + ICON.folder + "Open review folder</button></div>";
  h += '<div class="card runs">' + st.runs.map((r) =>
    '<div class="run"><div><b>' + (r.kind === "dupes" ? "Find duplicates" : "Same recording") + "</b> · " + esc(r.when) +
    '<div class="muted" style="font-size:12.5px">' + plural(r.moved, "file") + " moved" + (r.skipped ? ", " + r.skipped + " skipped" : "") +
    (r.undone ? " · <b>undone</b> (files put back)" : " · " + fmtSize(r.bytes_in_review) + " still in review") + "</div></div>" +
    '<div class="row">' + (r.undone ? "" : '<button class="btn small" data-folder="' + esc(r.review_dir) + '">' + ICON.folder + "Review folder</button>") +
    '<button class="btn small" data-open="' + esc(r.manifest) + '">Move record</button>' +
    (r.undone ? "" : '<button class="btn small danger" data-undo="' + esc(r.manifest) + '">Undo</button>') + "</div></div>").join("") + "</div>";
  return h;
}
async function undo(manifest) {
  const ok = await confirmBox("Put these files back?", "<p>Every file moved by this run goes back to its original folder. Files that were removed from the review folder can't be restored.</p>", "Put files back");
  if (!ok) return;
  await runJob("/api/undo", { manifest }, (r) => {
    st.runs = null; st.result.dupes = null; st.result.recordings = null;
    if (!r.problems.length) { toast("Put back " + plural(r.restored, "file") + "."); return; }
    confirmBox("Put back " + plural(r.restored, "file") + ", but " + plural(r.problems.length, "file") + " couldn't be",
      "<p>These were left where they are:</p><ul style=\"max-height:240px;overflow:auto;font-size:12.5px\">" +
      r.problems.slice(0, 100).map((x) => "<li>" + esc(x) + "</li>").join("") + "</ul>", "OK");
  });
}

// ---------- player engine ----------
// Two audio elements: while one fades out, the other fades in (equal-power crossfade).
function pref(k, d) { try { const v = localStorage.getItem("mp3m." + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
function savePref(k, v) { try { localStorage.setItem("mp3m." + k, JSON.stringify(v)); } catch (e) {} }
const MP = {
  els: [new Audio(), new Audio()], cur: 0, queue: [], pos: -1, byId: {}, timer: null, fading: false, seeking: false,
  vol: pref("vol", 0.8), xfade: pref("xfade", 4), shuffle: pref("shuffle", false), repeat: pref("repeat", "off"),
};
MP.els.forEach((el) => { el.preload = "auto"; });
const mpActive = () => MP.els[MP.cur];
const mpCurrent = () => (MP.pos >= 0 ? MP.byId[MP.queue[MP.pos]] : null);
const mpPlaying = () => !mpActive().paused;
const trackUrl = (id) => "/media/track?t=" + encodeURIComponent(TOKEN) + "&id=" + encodeURIComponent(id);
const trackCover = (id) => "/media/trackcover?t=" + encodeURIComponent(TOKEN) + "&id=" + encodeURIComponent(id);
const tTitle = (t) => t.title || t.where.split("/").pop().replace(/\.[^.]+$/, "");

function mpStopFade() {
  if (MP.timer) { clearInterval(MP.timer); MP.timer = null; }
  if (MP.fading) { const old = MP.els[1 - MP.cur]; old.pause(); MP.fading = false; }
  mpActive().volume = MP.vol;
}
function mpGo(pos, fadeSecs) {
  if (pos < 0 || pos >= MP.queue.length) return;
  if (!player.paused) { player.pause(); st.playing = null; }
  const wasPlaying = mpPlaying();
  mpStopFade();
  const old = mpActive(), ni = 1 - MP.cur, nw = MP.els[ni];
  MP.pos = pos;
  nw.src = trackUrl(MP.queue[pos]);
  const fade = wasPlaying && fadeSecs > 0.05;
  nw.volume = fade ? 0 : MP.vol;
  MP.cur = ni;
  nw.play().catch(() => {});
  if (fade) {
    MP.fading = true;
    const t0 = performance.now();
    MP.timer = setInterval(() => {
      const k = Math.min(1, (performance.now() - t0) / (fadeSecs * 1000));
      nw.volume = MP.vol * Math.sin((k * Math.PI) / 2);
      old.volume = MP.vol * Math.cos((k * Math.PI) / 2);
      if (k >= 1) { clearInterval(MP.timer); MP.timer = null; old.pause(); MP.fading = false; nw.volume = MP.vol; }
    }, 40);
  } else {
    old.pause();
  }
  mpMediaSession();
  mpRefresh(true);
}
function mpNextPos(auto) {
  if (!MP.queue.length) return -1;
  let p = MP.pos + 1;
  if (p >= MP.queue.length) p = MP.repeat === "all" ? 0 : -1;
  return p;
}
function mpNext(auto) {
  const p = mpNextPos(auto);
  if (p < 0) { if (auto) { mpRefresh(true); } return; }
  mpGo(p, auto ? 0 : Math.min(MP.xfade, 1));
}
function mpPrev() {
  const a = mpActive();
  if (a.currentTime > 3 || MP.pos <= 0 && MP.repeat !== "all") { a.currentTime = 0; return; }
  mpGo(MP.pos > 0 ? MP.pos - 1 : MP.queue.length - 1, Math.min(MP.xfade, 1));
}
function shuffled(arr) { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function mpPlayFrom(id, ids) {
  ids = ids || plList().map((t) => t.id);
  if (!ids.length) return;
  if (!id) id = MP.shuffle ? ids[Math.floor(Math.random() * ids.length)] : ids[0];
  let q = ids;
  if (MP.shuffle) q = [id].concat(shuffled(ids.filter((x) => x !== id)));
  MP.queue = q;
  mpGo(q.indexOf(id), Math.min(MP.xfade, 1));
}
function mpPause() { if (mpPlaying()) { mpStopFade(); mpActive().pause(); } }
function mpAction(a) {
  if (a === "toggle") {
    if (MP.pos < 0) return mpPlayFrom(null);
    if (mpPlaying()) mpPause(); else { if (!player.paused) { player.pause(); st.playing = null; render(); } mpActive().play().catch(() => {}); }
  } else if (a === "next") mpNext(false);
  else if (a === "prev") mpPrev();
  else if (a === "shuffle") {
    MP.shuffle = !MP.shuffle; savePref("shuffle", MP.shuffle);
    const cur = MP.queue[MP.pos];
    if (MP.pos >= 0) {
      const ids = plList().map((t) => t.id);
      MP.queue = MP.shuffle ? [cur].concat(shuffled(ids.filter((x) => x !== cur))) : ids;
      MP.pos = Math.max(0, MP.queue.indexOf(cur));
    }
    mpRefresh(true);
  } else if (a === "repeat") {
    MP.repeat = MP.repeat === "off" ? "all" : MP.repeat === "all" ? "one" : "off"; savePref("repeat", MP.repeat); mpRefresh(true);
  } else if (a === "playall") { MP.shuffle = false; savePref("shuffle", false); mpPlayFrom(null); }
  else if (a === "shuffleall") { MP.shuffle = true; savePref("shuffle", true); mpPlayFrom(null); }
  else if (a === "open") { st.page = "player"; render(); }
  else if (a === "popout") { popOut(); }
}
MP.els.forEach((el, i) => {
  el.addEventListener("timeupdate", () => {
    if (i !== MP.cur) return;
    mpTick();
    if (MP.xfade > 0 && !MP.fading && MP.repeat !== "one" && el.duration && isFinite(el.duration) && el.duration > MP.xfade * 2) {
      const left = el.duration - el.currentTime;
      if (left <= MP.xfade && !el.paused) { const p = mpNextPos(true); if (p >= 0) mpGo(p, left); }
    }
  });
  el.addEventListener("ended", () => {
    if (i !== MP.cur) return;
    if (MP.repeat === "one") { el.currentTime = 0; el.play().catch(() => {}); return; }
    const p = mpNextPos(true);
    if (p >= 0) mpGo(p, 0); else mpRefresh(true);
  });
  el.addEventListener("error", () => {
    if (i !== MP.cur || !el.getAttribute("src")) return;
    const t = mpCurrent();
    toast("Can't play " + (t ? tTitle(t) : "this song") + ". Skipping it.", true);
    const p = MP.pos + 1 < MP.queue.length ? MP.pos + 1 : -1;
    if (p >= 0) setTimeout(() => { MP.pos = p; const nw = MP.els[MP.cur]; nw.src = trackUrl(MP.queue[p]); nw.volume = MP.vol; nw.play().catch(() => {}); mpRefresh(true); }, 300);
  });
  el.addEventListener("play", () => mpRefresh(false));
  el.addEventListener("pause", () => mpRefresh(false));
  el.addEventListener("loadedmetadata", () => { if (i === MP.cur) mpTick(); });
});
function mpMediaSession() {
  const t = mpCurrent();
  if (!t || !("mediaSession" in navigator)) return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({ title: tTitle(t), artist: t.artist || "", album: t.album || "",
      artwork: t.cover ? [{ src: location.origin + trackCover(t.id), sizes: "512x512" }] : [] });
    navigator.mediaSession.setActionHandler("play", () => mpAction("toggle"));
    navigator.mediaSession.setActionHandler("pause", () => mpAction("toggle"));
    navigator.mediaSession.setActionHandler("previoustrack", () => mpAction("prev"));
    navigator.mediaSession.setActionHandler("nexttrack", () => mpAction("next"));
  } catch (e) {}
}
function mpTick() {
  const a = mpActive(), d = isFinite(a.duration) ? a.duration : 0, c = a.currentTime || 0;
  const pos = $("#npPos"), dur = $("#npDur"), seek = $("#seek"), mb = $("#miniBar");
  if (pos && !MP.seeking) pos.textContent = fmtTime(Math.floor(c));
  if (dur) dur.textContent = fmtTime(Math.round(d));
  if (seek && !MP.seeking) seek.value = d ? Math.round((c / d) * 1000) : 0;
  if (mb) mb.style.width = (d ? (c / d) * 100 : 0) + "%";
  if (popOpen()) {
    const pd = POP.win.document, ps = pd.getElementById("ppSeek"), pp = pd.getElementById("ppPos"), pdur = pd.getElementById("ppDur");
    if (pp && !MP.seeking) pp.textContent = fmtTime(Math.floor(c));
    if (pdur) pdur.textContent = fmtTime(Math.round(d));
    if (ps && !MP.seeking) ps.value = d ? Math.round((c / d) * 1000) : 0;
  }
}
let lastNow = null;
function mpRefresh(trackChanged) {
  renderMini();
  if (st.page !== "player") return;
  const t = mpCurrent();
  if (trackChanged || (t && t.id) !== lastNow) { lastNow = t && t.id; render(); return; }
  const pb = $("#npPlay");
  if (pb) pb.innerHTML = mpPlaying() ? ICON.pause : ICON.play;
  document.querySelectorAll(".eq").forEach((e) => e.classList.toggle("paused", !mpPlaying()));
}
function renderMini() {
  const box = $("#mini"), t = mpCurrent();
  if (!t) { box.classList.add("hidden"); return; }
  box.classList.remove("hidden");
  box.innerHTML = '<button class="mini-title" data-mp="open" title="Open the Player"><span class="mt">' + esc(tTitle(t)) + '</span><span class="ms">' + esc(t.artist || t.album || "") + "</span></button>" +
    '<div class="mbar"><i id="miniBar"></i></div><div class="ctrls">' +
    '<button class="cbtn" data-mp="prev" title="Previous">' + ICON.prev + "</button>" +
    '<button class="cbtn big" data-mp="toggle" title="Play / pause">' + (mpPlaying() ? ICON.pause : ICON.play) + "</button>" +
    '<button class="cbtn" data-mp="next" title="Next">' + ICON.next + "</button>" +
    '<button class="cbtn' + (popOpen() ? " on" : "") + '" data-mp="popout" title="Pop out the player" style="margin-left:auto">' + ICON.popout + "</button></div>";
  mpTick();
  renderPop();
}

// ---------- pop-out player ----------
// Chrome/Edge: a floating window that stays on top of every app (Document Picture-in-Picture).
// Other browsers: a small separate window. Either way the music keeps playing from this tab.
const POP = { win: null, pip: false };
const popOpen = () => !!(POP.win && !POP.win.closed);
const POP_CSS = `
:root { --bg:#f4f3ef; --panel:#fff; --line:#e4e1d9; --line-2:#d4d0c6; --ink:#1d1c19; --ink-2:#57544d; --ink-3:#8a867c;
  --accent:#1f6f5c; --accent-ink:#fff; --accent-soft:#e2f0eb; color-scheme: light; }
@media (prefers-color-scheme: dark) { :root { --bg:#161614; --panel:#1f1f1c; --line:#33322d; --line-2:#45433c; --ink:#f0eee8;
  --ink-2:#b9b5aa; --ink-3:#8a867c; --accent:#5cc0a2; --accent-ink:#0d1f19; --accent-soft:#1d3029; color-scheme: dark; } }
* { box-sizing: border-box; }
html, body { margin: 0; height: 100%; background: var(--bg); color: var(--ink);
  font: 14px/1.4 -apple-system, BlinkMacSystemFont, "SF Pro Text", "Helvetica Neue", Arial, sans-serif; }
#pp { display: flex; flex-direction: column; height: 100%; padding: 16px; gap: 12px; max-width: 460px; margin: 0 auto; }
.top { display: flex; align-items: center; gap: 8px; color: var(--ink-3); font-size: 11.5px; }
.top img { width: 18px; height: 18px; border-radius: 4px; }
.top b { color: var(--ink-2); font-weight: 600; }
.cov { width: min(100%, 52vh); aspect-ratio: 1; height: auto; object-fit: cover; border-radius: 12px; background: var(--line); display: block;
  box-shadow: 0 6px 20px rgba(0,0,0,.18); margin: 0 auto; flex: none; }
.cov.none { display: grid; place-items: center; }
.cov.none svg { width: 30%; height: 30%; fill: var(--line-2); }
.t { font-size: 16px; font-weight: 650; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; letter-spacing: -.01em; }
.s { color: var(--ink-2); font-size: 12.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.seek { display: flex; align-items: center; gap: 8px; font-size: 11px; color: var(--ink-3); font-variant-numeric: tabular-nums; }
.seek input { flex: 1; min-width: 0; }
input[type=range] { accent-color: var(--accent); }
.ctrls { display: flex; align-items: center; justify-content: center; gap: 10px; }
.cb { position: relative; width: 36px; height: 36px; border-radius: 50%; border: 1px solid var(--line-2); background: var(--panel); color: var(--ink);
  display: grid; place-items: center; cursor: pointer; padding: 0; }
.cb svg { width: 14px; height: 14px; fill: currentColor; }
.cb.big { width: 50px; height: 50px; background: var(--accent); border-color: var(--accent); color: var(--accent-ink); }
.cb.big svg { width: 19px; height: 19px; }
.cb.on { color: var(--accent); border-color: var(--accent); background: var(--accent-soft); }
.cb .one { position: absolute; right: 3px; top: 1px; font-size: 9px; font-weight: 800; }
.vol { display: flex; align-items: center; gap: 8px; font-size: 11.5px; color: var(--ink-3); }
.vol input { flex: 1; }
.empty { margin: auto; text-align: center; color: var(--ink-2); }
.empty button { margin-top: 12px; border: 0; background: var(--accent); color: var(--accent-ink); padding: 8px 16px; border-radius: 9px; font: inherit; cursor: pointer; }
`;
async function popOut() {
  if (popOpen()) { try { POP.win.focus(); } catch (e) {} return; }
  let win = null, pip = false;
  if ("documentPictureInPicture" in window) {
    try { win = await documentPictureInPicture.requestWindow({ width: 320, height: 500 }); pip = true; } catch (e) { win = null; }
  }
  if (!win) {
    win = window.open("", "kalyaMusicBoxPlayer", "popup=yes,width=340,height=540,resizable=yes");
    if (!win) { toast("Your browser blocked the pop-out window. Allow pop-ups for this page, then try again.", true); return; }
  }
  POP.win = win; POP.pip = pip;
  const d = win.document;
  d.head.innerHTML = '<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Kalya MusicBox</title>' +
    '<link rel="icon" href="' + $('link[rel="icon"]').href + '"><style>' + POP_CSS + "</style>";
  d.body.innerHTML = '<div id="pp"></div>';
  d.addEventListener("click", (e) => {
    const b = e.target.closest("[data-mp]");
    if (b) mpAction(b.dataset.mp);
  });
  d.addEventListener("input", (e) => {
    const t = e.target;
    if (t.id === "ppVol") {
      MP.vol = t.value / 100; savePref("vol", MP.vol); if (!MP.fading) mpActive().volume = MP.vol;
      const v = $("#vol"); if (v) v.value = t.value;
    } else if (t.id === "ppSeek") {
      MP.seeking = true; const a = mpActive();
      if (isFinite(a.duration)) d.getElementById("ppPos").textContent = fmtTime(Math.floor((t.value / 1000) * a.duration));
    }
  });
  d.addEventListener("change", (e) => {
    if (e.target.id !== "ppSeek") return;
    const a = mpActive();
    if (isFinite(a.duration)) { if (MP.fading) mpStopFade(); a.currentTime = (e.target.value / 1000) * a.duration; }
    MP.seeking = false;
  });
  d.addEventListener("keydown", (e) => {
    if (e.code === "Space" && e.target.tagName !== "INPUT") { e.preventDefault(); mpAction("toggle"); }
    if (e.code === "ArrowRight" && e.metaKey) mpAction("next");
    if (e.code === "ArrowLeft" && e.metaKey) mpAction("prev");
  });
  win.addEventListener("pagehide", () => { POP.win = null; renderMini(); });
  renderPop();
  renderMini();
}
function renderPop() {
  if (!popOpen()) return;
  const el = POP.win.document.getElementById("pp");
  if (!el) return;
  const t = mpCurrent();
  const top = '<div class="top"><img src="' + $('link[rel="icon"]').href + '" alt=""><b>Kalya MusicBox</b><span style="margin-left:auto">' +
    (MP.xfade ? "Crossfade " + MP.xfade + " s" : "") + "</span></div>";
  if (!t) {
    el.innerHTML = top + '<div class="empty"><div style="font-weight:600;color:var(--ink)">Nothing playing</div>' +
      ((st.pl.tracks || []).length ? '<button data-mp="toggle">Play my music</button>' : "<div>Add music folders in the Player first.</div>") + "</div>";
    return;
  }
  const playing = mpPlaying();
  el.innerHTML = top +
    (t.cover ? '<img class="cov" src="' + trackCover(t.id) + '" alt="">' : '<div class="cov none">' + ICON.note + "</div>") +
    '<div><div class="t" title="' + esc(tTitle(t)) + '">' + esc(tTitle(t)) + '</div><div class="s">' + esc([t.artist, t.album].filter(Boolean).join(" · ") || t.where) + "</div></div>" +
    '<div class="seek"><span id="ppPos">0:00</span><input type="range" id="ppSeek" min="0" max="1000" value="0"><span id="ppDur">' + fmtTime(t.seconds) + "</span></div>" +
    '<div class="ctrls">' +
    '<button class="cb' + (MP.shuffle ? " on" : "") + '" data-mp="shuffle" title="Shuffle">' + ICON.shuffle + "</button>" +
    '<button class="cb" data-mp="prev" title="Previous">' + ICON.prev + "</button>" +
    '<button class="cb big" data-mp="toggle" title="Play / pause (space bar)">' + (playing ? ICON.pause : ICON.play) + "</button>" +
    '<button class="cb" data-mp="next" title="Next">' + ICON.next + "</button>" +
    '<button class="cb' + (MP.repeat !== "off" ? " on" : "") + '" data-mp="repeat" title="Repeat: ' + MP.repeat + '">' + ICON.repeat + (MP.repeat === "one" ? '<span class="one">1</span>' : "") + "</button></div>" +
    '<div class="vol"><span>Volume</span><input type="range" id="ppVol" min="0" max="100" value="' + Math.round(MP.vol * 100) + '"></div>';
  try { POP.win.document.title = (playing ? "▶ " : "") + tTitle(t) + " – Kalya MusicBox"; } catch (e) {}
  mpTick();
}
window.addEventListener("pagehide", () => { if (popOpen() && !POP.pip) POP.win.close(); });

// ---------- player page ----------
async function loadPlayer() {
  try {
    const d = await api("/api/player");
    st.pl.tracks = d.tracks; st.pl.sources = d.sources; st.pl.scanned_at = d.scanned_at;
    MP.byId = {}; d.tracks.forEach((t) => { MP.byId[t.id] = t; });
    MP.queue = MP.queue.filter((id) => MP.byId[id]);
  } catch (e) { toast(e.message, true); st.pl.tracks = []; }
  render();
}
function plList() {
  const tr = st.pl.tracks || [], q = st.pl.query.trim().toLowerCase();
  let rows = q ? tr.filter((t) => (tTitle(t) + " " + t.artist + " " + t.album + " " + t.where).toLowerCase().includes(q)) : tr.slice();
  const [key, dir] = st.pl.sort;
  if (key !== "artist" || dir !== 1) {
    rows.sort((a, b) => {
      let v;
      if (key === "seconds" || key === "track") v = (a[key] || 0) - (b[key] || 0);
      else if (key === "title") v = tTitle(a).localeCompare(tTitle(b));
      else v = (a[key] || "").localeCompare(b[key] || "");
      return v * dir || (a.album || "").localeCompare(b.album || "") || (a.track || 0) - (b.track || 0);
    });
  }
  return rows;
}
function nowPlayingHtml() {
  const t = mpCurrent();
  const cover = t && t.cover ? '<img class="np-cover" src="' + trackCover(t.id) + '" alt="">' : '<div class="np-cover none">' + ICON.note + "</div>";
  const xf = MP.xfade ? MP.xfade + " s" : "Off";
  return '<div class="card player-top">' + cover + '<div style="min-width:0">' +
    '<div class="np-title">' + esc(t ? tTitle(t) : "Nothing playing") + "</div>" +
    '<div class="np-sub">' + esc(t ? [t.artist, t.album].filter(Boolean).join(" · ") || t.where : "Double-click a song, or press Play to start.") + "</div>" +
    '<div class="seekrow"><span id="npPos">0:00</span><input type="range" id="seek" min="0" max="1000" value="0"' + (t ? "" : " disabled") + '><span id="npDur">' + (t ? fmtTime(t.seconds) : "0:00") + "</span></div>" +
    '<div class="ctrls">' +
    '<button class="cbtn' + (MP.shuffle ? " on" : "") + '" data-mp="shuffle" title="Shuffle ' + (MP.shuffle ? "on" : "off") + '">' + ICON.shuffle + "</button>" +
    '<button class="cbtn" data-mp="prev" title="Previous">' + ICON.prev + "</button>" +
    '<button class="cbtn big" id="npPlay" data-mp="toggle" title="Play / pause (space bar)">' + (mpPlaying() ? ICON.pause : ICON.play) + "</button>" +
    '<button class="cbtn" data-mp="next" title="Next">' + ICON.next + "</button>" +
    '<button class="cbtn' + (MP.repeat !== "off" ? " on" : "") + '" data-mp="repeat" title="Repeat: ' + MP.repeat + '">' + ICON.repeat + (MP.repeat === "one" ? '<span class="one">1</span>' : "") + "</button>" +
    '<div class="sliders"><label>Volume <input type="range" id="vol" min="0" max="100" value="' + Math.round(MP.vol * 100) + '"></label>' +
    '<label title="Blend the end of each song into the next">Crossfade <input type="range" id="xf" min="0" max="12" step="1" value="' + MP.xfade + '"><b id="xfv">' + xf + "</b></label></div>" +
    "</div></div></div>";
}
function sourcesHtml() {
  const s = st.pl.sources;
  let h = '<div class="card pad" style="margin-bottom:16px"><div class="row" style="justify-content:space-between;margin-bottom:6px"><b>Music folders</b><div class="row">' +
    '<button class="btn small" id="addSrc">' + ICON.plus + "Add folder</button>" +
    '<button class="btn small" id="rescan"' + (s.length && !st.job ? "" : " disabled") + ">Rescan</button></div></div>";
  if (!s.length) h += '<div class="muted">No folders yet. Add one or more folders, for example your MUSIC-DK Library or a folder on another drive.</div>';
  else h += '<div class="srcs">' + s.map((x, i) => '<div class="src"><span class="dot ' + (x.ok ? "ok" : "bad") + '"></span><span class="mono" title="' + esc(x.path) + '">' + esc(x.path) +
    "</span>" + (x.ok ? "" : '<span class="muted" style="font-size:12px">not connected</span>') + '<button class="linkish" data-rmsrc="' + i + '">Remove</button></div>').join("") + "</div>";
  if (st.pl.scanned_at) h += '<div class="muted" style="font-size:12px;margin-top:6px">' + plural((st.pl.tracks || []).length, "song") + " · last scanned " + esc(st.pl.scanned_at) + "</div>";
  return h + "</div>";
}
function playerPage() {
  let h = '<div class="row" style="justify-content:space-between;align-items:flex-start"><h1>Player</h1><button class="btn small" data-mp="popout" title="Open a small player window that stays on the side">' +
    ICON.popout + (popOpen() ? "Player window is open" : "Pop out player") + "</button></div>" +
    '<p class="lede">Plays music from any folders on your Mac or drives. Songs in the duplicate review folder are left out. Your Mac\'s play, next and previous keys work too. ' +
    "Pop out the player to keep a small player on the side while you minimize the browser.</p>";
  if (st.pl.tracks === null) { setTimeout(loadPlayer, 0); return h + '<div class="card empty">Loading…</div>'; }
  h += nowPlayingHtml() + sourcesHtml();
  if (st.job) h += progressHtml();
  const tracks = st.pl.tracks;
  if (!tracks.length) return h + (st.job ? "" : '<div class="card empty"><b>No songs yet</b>' + (st.pl.sources.length ? "Click <i>Rescan</i> to find the songs in your folders." : "Add a music folder to get started.") + "</div>");
  const rows = plList(), cur = mpCurrent(), [key, dir] = st.pl.sort;
  h += '<div class="toolbar"><button class="btn small primary" data-mp="playall">' + ICON.play + 'Play all</button><button class="btn small" data-mp="shuffleall">' + ICON.shuffle + "Shuffle all</button>" +
    '<input class="search" id="pq" placeholder="Search ' + tracks.length.toLocaleString() + ' songs" value="' + esc(st.pl.query) + '"></div>';
  const cols = [["", ""], ["title", "Title"], ["artist", "Artist"], ["album", "Album"], ["seconds", "Time"]];
  h += '<div class="card" style="overflow:auto"><table><thead><tr>' + cols.map(([k, l]) => "<th" + (k ? ' data-psort="' + k + '"' : "") + (k === "album" ? ' class="hide-sm"' : "") + ">" + l +
    (k === key ? (dir > 0 ? " ↑" : " ↓") : "") + "</th>").join("") + "</tr></thead><tbody>" +
    rows.slice(0, st.pl.shown).map((t) => {
      const now = cur && cur.id === t.id;
      return '<tr data-row="' + t.id + '" class="' + (now ? "now" : "") + '"><td style="width:46px">' +
        (now ? '<button class="play on" data-mp="toggle"><span class="eq' + (mpPlaying() ? "" : " paused") + '"><i></i><i></i><i></i></span></button>' :
          '<button class="play" data-track="' + t.id + '" title="Play">' + ICON.play + "</button>") + "</td>" +
        '<td><div class="minfo"><div class="mt">' + esc(tTitle(t)) + '</div><div class="mp" title="' + esc(t.where) + '">&lrm;' + esc(t.where) + "&lrm;</div></div></td>" +
        "<td>" + esc(t.artist) + '</td><td class="hide-sm">' + esc(t.album) + '</td><td class="num">' + fmtTime(t.seconds) + "</td></tr>";
    }).join("") + "</tbody></table></div>";
  if (!rows.length) h += '<div class="card empty"><b>Nothing matches</b></div>';
  if (rows.length > st.pl.shown) h += '<div class="more"><button class="btn" id="plMore">Show more (' + (rows.length - st.pl.shown).toLocaleString() + " left)</button></div>";
  return h;
}
function pickFolder(opt) {
  opt = opt || {};
  return new Promise((resolve) => {
    const bg = document.createElement("div");
    bg.className = "modal-bg";
    bg.innerHTML = '<div class="modal wide card"><h2>' + esc(opt.title || "Add a music folder") + "</h2><p>" +
      (opt.help || "Open the folder you want, then click <i>Add this folder</i>. All folders inside it are included.") + "</p>" +
      '<input class="search" id="fType" style="width:100%;margin-bottom:10px" placeholder="Or paste a folder path and press Return, e.g. /Volumes/MUSIC-DK">' +
      '<div class="row" id="fShort"></div><div class="mono" id="fPath" style="margin-top:10px;word-break:break-all"></div><div class="dirlist" id="fList"></div>' +
      '<div class="row"><button class="btn" data-f="cancel">Cancel</button><button class="btn primary" data-f="add">' + esc(opt.button || "Add this folder") + "</button></div></div>";
    document.body.appendChild(bg);
    let cur = null;
    const folderIcon = '<svg viewBox="0 0 16 16"><path d="M1 3.5A1.5 1.5 0 0 1 2.5 2h3.6l1.5 1.5h5.9A1.5 1.5 0 0 1 15 5v7.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 1 12.5z"/></svg>';
    async function go(path) {
      let d;
      try { d = await api("/api/dirs?path=" + encodeURIComponent(path || "")); } catch (e) { toast(e.message, true); return; }
      cur = d.path;
      $("#fShort", bg).innerHTML = d.shortcuts.map((x) => '<button class="chip" data-go="' + esc(x.path) + '">' + esc(x.label) + "</button>").join("");
      $("#fPath", bg).textContent = d.path;
      $("#fList", bg).innerHTML = (d.parent ? '<button data-go="' + esc(d.parent) + '"><span class="muted">↑</span> Up one level</button>' : "") +
        d.dirs.map((n) => '<button data-go="' + esc(d.path.replace(/\/$/, "") + "/" + n) + '">' + folderIcon + esc(n) + "</button>").join("") +
        (d.dirs.length ? "" : '<div class="muted" style="padding:10px 12px">No folders inside.</div>');
    }
    bg.addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (e.target === bg) { bg.remove(); resolve(null); return; }
      if (!b) return;
      if (b.dataset.go) go(b.dataset.go);
      if (b.dataset.f === "cancel") { bg.remove(); resolve(null); }
      if (b.dataset.f === "add") { bg.remove(); resolve(cur); }
    });
    $("#fType", bg).addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); go(e.target.value.trim()); } });
    go(opt.start || "");
  });
}
async function saveSources(list) {
  try {
    const d = await api("/api/player_sources", { sources: list });
    st.pl.sources = d.sources;
    return true;
  } catch (e) { toast(e.message, true); return false; }
}
async function rescanPlayer() {
  await runJob("/api/player_scan", {}, async (r) => {
    await loadPlayer();
    toast("Found " + plural(r.count, "song") + "." + (r.missing.length ? " " + plural(r.missing.length, "folder") + " not connected." : ""));
  });
}

// ---------- convert to MP3 ----------
function cvState() {
  if (!st.cv) st.cv = {
    info: null, src: pref("cv.src", ""), dst: pref("cv.dst", ""), same: pref("cv.same", false),
    formats: pref("cv.formats", null), quality: pref("cv.quality", "320"), art: pref("cv.art", true),
    recurse: pref("cv.recurse", true), overwrite: false, plan: null, result: null,
  };
  return st.cv;
}
function cvSave() {
  const c = st.cv;
  savePref("cv.src", c.src); savePref("cv.dst", c.dst); savePref("cv.same", c.same); savePref("cv.formats", c.formats);
  savePref("cv.quality", c.quality); savePref("cv.art", c.art); savePref("cv.recurse", c.recurse);
}
function cvChanged() { st.cv.plan = null; st.cv.result = null; cvSave(); render(); }
async function loadConvertInfo() {
  const c = cvState();
  try { c.info = await api("/api/convert_info"); if (!c.formats) c.formats = c.info.defaults.slice(); } catch (e) { toast(e.message, true); }
  render();
}
function convertPage() {
  const c = cvState();
  let h = '<h1>Convert to MP3</h1><p class="lede">Turns WMA, WAV, AAC/M4A, FLAC, OGG/Opus, AIFF, APE and WavPack files into MP3s, keeping song tags and cover art. Your original files are never changed or deleted.</p>';
  if (!c.info) { setTimeout(loadConvertInfo, 0); return h + '<div class="card empty">Loading…</div>'; }
  if (!c.info.ffmpeg) h += '<div class="banner warn"><b>ffmpeg is needed to convert.</b> Install it once in Terminal:<code class="cmd">brew install ffmpeg</code>then quit and reopen Kalya MusicBox.</div>';
  const path = (p) => p ? '<div class="cv-path" title="' + esc(p) + '">&lrm;' + esc(p) + "&lrm;</div>" : '<div class="cv-path none">Not chosen yet</div>';
  h += '<div class="card pad cv-card"><h3><span class="n">1</span>Folders</h3>' +
    '<div class="cv-row"><span class="lbl">Files to convert</span>' + path(c.src) + '<button class="btn small" id="cvSrc">Choose…</button></div>' +
    '<div class="cv-row"><span class="lbl">Save the MP3s</span><div>' +
    '<label class="radio"><input type="radio" name="cvdst" value="other"' + (c.same ? "" : " checked") + '> In another folder (same subfolders)</label>' +
    '<label class="radio" style="margin-top:4px"><input type="radio" name="cvdst" value="same"' + (c.same ? " checked" : "") + "> Next to the originals</label></div><span></span></div>" +
    (c.same ? "" : '<div class="cv-row"><span class="lbl">Destination</span>' + path(c.dst) + '<button class="btn small" id="cvDst">Choose…</button></div>') + "</div>";
  h += '<div class="card pad cv-card"><h3><span class="n">2</span>Formats to convert</h3><div class="fmt-grid">' +
    c.info.formats.map((f) => '<label class="fmt' + (c.formats.includes(f.key) ? " on" : "") + '"><input type="checkbox" data-fmt="' + f.key + '"' +
      (c.formats.includes(f.key) ? " checked" : "") + "> " + esc(f.label) + " <small>" + f.exts.join(" ") + (f.lossless ? " · lossless" : "") + "</small></label>").join("") +
    '</div><div class="muted" style="font-size:12.5px;margin-top:10px">Lossless files (WAV, FLAC, AIFF, APE, WavPack) make the best MP3s. Converting from WMA, AAC or OGG loses a little more quality, which is rarely audible at 256–320 kbps. Copy-protected (DRM) files can\'t be converted by any tool.</div></div>';
  h += '<div class="card pad cv-card"><h3><span class="n">3</span>Quality and options</h3><div class="row"><span class="lbl muted">MP3 quality</span><select class="sel" id="cvQ">' +
    c.info.qualities.map((q) => '<option value="' + q.key + '"' + (q.key === c.quality ? " selected" : "") + ">" + esc(q.label) + "</option>").join("") + "</select></div>" +
    '<div class="opts"><label class="toggle"><input type="checkbox" id="cvArt"' + (c.art ? " checked" : "") + "> Keep cover art</label>" +
    '<label class="toggle"><input type="checkbox" id="cvRec"' + (c.recurse ? " checked" : "") + "> Include subfolders</label>" +
    '<label class="toggle"><input type="checkbox" id="cvOver"' + (c.overwrite ? " checked" : "") + "> Convert again if the MP3 already exists</label></div></div>";
  const ready = c.info.ffmpeg && c.src && (c.same || c.dst) && c.formats.length && !st.job;
  h += '<div class="row"><button class="btn' + (c.plan ? "" : " primary") + '" id="cvCheck"' + (ready ? "" : " disabled") + ">Check files</button>";
  if (c.plan && c.plan.todo) h += '<button class="btn primary" id="cvGo"' + (st.job ? " disabled" : "") + ">Convert " + plural(c.plan.todo, "file") + "</button>";
  h += "</div>";
  if (st.job) h += progressHtml();
  if (c.plan) {
    const p = c.plan, labels = {};
    c.info.formats.forEach((f) => { labels[f.key] = f.label; });
    h += '<div class="card" style="margin-top:16px;overflow:auto"><table class="cv-table"><thead><tr><th>Format</th><th>Files found</th><th>To convert</th><th>Size</th></tr></thead><tbody>' +
      Object.keys(p.by_format).map((k) => "<tr><td>" + esc(labels[k] || k) + '</td><td class="num">' + p.by_format[k].files + '</td><td class="num">' + p.by_format[k].todo +
        '</td><td class="num">' + fmtSize(p.by_format[k].bytes) + "</td></tr>").join("") + "</tbody></table></div>";
    h += '<div class="muted" style="margin-top:10px;font-size:13px">' + (p.todo ? plural(p.todo, "file") + " (" + fmtSize(p.todo_bytes) + ") will be converted" : "Nothing new to convert") +
      (p.exists ? "; " + plural(p.exists, "file") + " already have an MP3 and will be skipped" : "") + ". MP3s go " + (p.dst ? "to <span class=mono>" + esc(p.dst) + "</span>" : "next to each original") + ".</div>";
    if (!Object.keys(p.by_format).length) h += '<div class="card empty" style="margin-top:12px"><b>No matching files</b>Check the folder and the formats you ticked.</div>';
  }
  if (c.result) {
    const r = c.result;
    h += '<div class="card result"><b style="font-size:16px">Converted ' + plural(r.converted, "file") + " (" + fmtSize(r.out_bytes) + ").</b>" +
      (r.skipped ? '<div class="muted">' + plural(r.skipped, "file") + " skipped because the MP3 already existed.</div>" : "") +
      (r.failed.length ? '<div style="color:var(--warn);margin-top:6px">' + plural(r.failed.length, "file") + " couldn't be converted:</div><ul style=\"margin:6px 0 0;font-size:12.5px;max-height:180px;overflow:auto\">" +
        r.failed.map((x) => "<li><span class=mono>" + esc(x.file.split("/").slice(-2).join("/")) + "</span>: " + esc(x.reason.slice(0, 160)) + "</li>").join("") + "</ul>" : "") +
      '<div class="row" style="margin-top:12px">' + (st.status && st.status.is_mac ? '<button class="btn" id="cvOpen">' + ICON.folder + "Open the MP3 folder</button>" +
        (r.log ? '<button class="btn" id="cvLog">Open failure list</button>' : "") : "") +
      '<button class="btn" id="cvToPlayer">' + ICON.plus + "Add to Player</button></div>" +
      '<div class="muted" style="margin-top:10px;font-size:12.5px">Your original files were not changed. Delete them yourself once you\'re happy with the MP3s.</div></div>';
  }
  return h;
}

// ---------- about ----------
function aboutPage() {
  return '<div class="about">' +
    '<div class="badge"><img class="logo" src="__ICON__" alt="Kalya MusicBox logo">' +
    '<div><b>Kalya <span class="mb">MusicBox</span></b><div class="muted">MP3 Manager &amp; Music Player · Ver 1.0</div>' +
    '<div class="muted">Developed by Durgesh Kalya</div></div></div>' +
    '<div class="card pad" style="padding:22px 24px">' +
    '<h2>About FindingPlace.org</h2><p class="by">Developed by FindingPlace.org</p>' +
    '<p>We believe useful software should be accessible to everyone. Inspired by the early spirit of the internet, we create and share practical tools that solve real problems without unnecessary subscriptions, paywalls, or restrictions.</p>' +
    '<p>Technology should make life easier, give people more freedom, and leave us with more time for the things that matter. Not everything needs to be monetized, complicated, or locked behind a subscription.</p>' +
    '<p class="motto">Made for humans to be humans again.</p>' +
    '<p class="motto" style="margin-bottom:14px">Made in the USA by an immigrant.</p>' +
    '<p>Built with the belief that good ideas should be shared, useful tools should be accessible, and technology should serve people.</p>' +
    '<p style="margin:0">Find out more at <a href="https://findingplace.org" target="_blank" rel="noopener">https://findingplace.org</a></p>' +
    "</div></div>";
}

// ---------- render & events ----------
function render() {
  document.querySelectorAll(".nav-btn").forEach((b) => b.classList.toggle("on", b.dataset.page === st.page));
  const p = st.page;
  const html = p === "dupes" || p === "recordings" ? reviewPage(p) : p === "picard" ? picardPage() : p === "catalog" ? catalogPage() : p === "about" ? aboutPage() : p === "player" ? playerPage() : p === "convert" ? convertPage() : historyPage();
  const main = $("#main");
  const focus = document.activeElement && document.activeElement.id;
  const caret = focus && document.activeElement.selectionStart;
  main.innerHTML = html;
  if (focus && $("#" + focus)) { const el = $("#" + focus); el.focus(); if (caret != null && el.setSelectionRange) el.setSelectionRange(caret, caret); }
  actionBar();
}
let searchTimer = null;
document.addEventListener("input", (e) => {
  const id = e.target.id;
  if (id === "vol") { MP.vol = e.target.value / 100; savePref("vol", MP.vol); if (!MP.fading) mpActive().volume = MP.vol;
    if (popOpen()) { const pv = POP.win.document.getElementById("ppVol"); if (pv) pv.value = e.target.value; } return; }
  if (id === "xf") { MP.xfade = +e.target.value; savePref("xfade", MP.xfade); $("#xfv").textContent = MP.xfade ? MP.xfade + " s" : "Off"; renderPop(); return; }
  if (id === "seek") {
    MP.seeking = true;
    const a = mpActive();
    if (isFinite(a.duration)) $("#npPos").textContent = fmtTime(Math.floor((e.target.value / 1000) * a.duration));
    return;
  }
  if (id === "pq") {
    clearTimeout(searchTimer);
    const v = e.target.value;
    searchTimer = setTimeout(() => { st.pl.query = v; st.pl.shown = 300; render(); }, 200);
    return;
  }
  if (id === "q" || id === "cq") {
    clearTimeout(searchTimer);
    const v = e.target.value;
    searchTimer = setTimeout(() => {
      if (id === "q") { st.query[st.page] = v; st.shown[st.page] = 40; } else { st.catQuery = v; st.catShown = 200; }
      render();
    }, 200);
  }
});
document.addEventListener("change", (e) => {
  const t = e.target;
  if (t.dataset.exclude) {
    const kind = st.page, g = st.plan[kind].groups.find((x) => x.id == t.dataset.exclude);
    decisionFor(kind, g).exclude = t.checked; render();
  } else if (t.id === "across") { st.across = t.checked; }
  else if (t.id === "catAttn") { st.catAttn = t.checked; st.catShown = 200; render(); }
  else if (t.dataset.fmt) {
    const c = st.cv, k = t.dataset.fmt;
    c.formats = t.checked ? c.formats.concat([k]) : c.formats.filter((x) => x !== k); cvChanged();
  }
  else if (t.name === "cvdst") { st.cv.same = t.value === "same"; cvChanged(); }
  else if (t.id === "cvQ") { st.cv.quality = t.value; cvSave(); }
  else if (t.id === "cvArt") { st.cv.art = t.checked; cvSave(); }
  else if (t.id === "cvRec") { st.cv.recurse = t.checked; cvChanged(); }
  else if (t.id === "cvOver") { st.cv.overwrite = t.checked; cvChanged(); }
  else if (t.id === "seek") {
    const a = mpActive();
    if (isFinite(a.duration)) { if (MP.fading) mpStopFade(); a.currentTime = (t.value / 1000) * a.duration; }
    MP.seeking = false;
  }
});
document.addEventListener("click", async (e) => {
  const b = e.target.closest("button, a");
  if (!b) return;
  const ds = b.dataset, kind = st.page;
  if (b.id === "cvSrc" || b.id === "cvDst") {
    const c = st.cv, isSrc = b.id === "cvSrc";
    const path = await pickFolder({ title: isSrc ? "Folder with the files to convert" : "Where to save the MP3s",
      help: isSrc ? "Open the folder that holds your WMA, WAV, FLAC or other files, then click <i>Use this folder</i>. Subfolders are included."
        : "Open the folder for the converted MP3s, then click <i>Use this folder</i>. The original subfolders are recreated inside it.",
      button: "Use this folder", start: (isSrc ? c.src : c.dst) || "" });
    if (!path) return;
    if (isSrc) c.src = path; else c.dst = path;
    return cvChanged();
  }
  if (b.id === "cvCheck") {
    const c = st.cv; c.plan = null; c.result = null;
    return runJob("/api/convert_plan", { src: c.src, dst: c.dst, same_folder: c.same, formats: c.formats, recurse: c.recurse, overwrite: c.overwrite },
      (r) => { st.cv.plan = r; });
  }
  if (b.id === "cvGo") {
    const c = st.cv;
    const ok = await confirmBox("Convert " + plural(c.plan.todo, "file") + " to MP3?",
      "<p>MP3s will be saved " + (c.plan.dst ? "in <span class=mono>" + esc(c.plan.dst) + "</span>" : "next to each original") +
      ". Your original files stay exactly as they are.</p><p>Large folders can take a while; you can keep using the Player meanwhile.</p>", "Convert");
    if (!ok) return;
    return runJob("/api/convert_run", { quality: c.quality, keep_art: c.art }, (r) => {
      st.cv.result = r; st.cv.plan = null;
      toast("Converted " + plural(r.converted, "file") + "." + (r.failed.length ? " " + r.failed.length + " couldn't be converted." : ""), !!r.failed.length);
    });
  }
  if (b.id === "cvOpen") return api("/api/open", { what: "folder", abs: true, path: st.cv.result.dst }).catch((e) => toast(e.message, true));
  if (b.id === "cvLog") return api("/api/open", { what: "open", abs: true, path: st.cv.result.log }).catch((e) => toast(e.message, true));
  if (b.id === "cvToPlayer") {
    const d = st.cv.result.dst, list = st.pl.sources.map((x) => x.path);
    if (list.includes(d)) { toast("That folder is already in the Player."); return; }
    if (await saveSources(list.concat([d]))) { st.page = "player"; st.pl.tracks = null; render(); rescanPlayer(); }
    return;
  }
  if (ds.mp) return mpAction(ds.mp);
  if (ds.track) return mpPlayFrom(ds.track);
  if (ds.psort) { st.pl.sort = st.pl.sort[0] === ds.psort ? [ds.psort, -st.pl.sort[1]] : [ds.psort, 1]; return render(); }
  if (b.id === "plMore") { st.pl.shown += 300; return render(); }
  if (b.id === "rescan") return rescanPlayer();
  if (b.id === "addSrc") {
    const path = await pickFolder();
    if (!path) return;
    const list = st.pl.sources.map((x) => x.path);
    if (list.includes(path)) { toast("That folder is already in the list."); return; }
    if (await saveSources(list.concat([path]))) { render(); rescanPlayer(); }
    return;
  }
  if (ds.rmsrc !== undefined) {
    const x = st.pl.sources[+ds.rmsrc];
    if (!(await confirmBox("Remove this folder from the Player?", "<p class=mono>" + esc(x.path) + "</p><p>Only the Player's list changes. No music files are touched.</p>", "Remove"))) return;
    if (await saveSources(st.pl.sources.filter((_, i) => i !== +ds.rmsrc).map((y) => y.path))) rescanPlayer();
    return;
  }
  if (ds.page) { st.page = ds.page; if (ds.page === "history") st.runs = null; window.scrollTo(0, 0); render(); return; }
  if (b.id === "scanBtn") {
    st.result[kind] = null; st.plan[kind] = null; st.dec[kind] = {}; st.shown[kind] = 40;
    return runJob("/api/scan", { kind, across_albums: st.across }, (plan) => { st.plan[kind] = plan; });
  }
  if (b.id === "applyBtn") return applyPlan(kind);
  if (b.id === "moreBtn") { st.shown[kind] += 40; return render(); }
  if (b.id === "catBtn") return runJob("/api/catalog", {}, (r) => { st.catalog = r; });
  if (b.id === "catMore") { st.catShown += 200; return render(); }
  if (b.id === "setupBtn") return doSetup();
  if (b.id === "openPicard") return openThing("picard", "");
  if (b.id === "quitBtn") {
    if (await confirmBox("Quit Kalya MusicBox?", "<p>" + (st.status && st.status.installed ? "Open it again any time from Applications or Launchpad." :
      "You can open it again from the launcher on your Desktop or from Terminal.") + "</p>", "Quit")) {
      try { await api("/api/quit", {}); } catch (err) {}
      document.body.innerHTML = '<div class="empty" style="padding-top:20vh"><b>Kalya MusicBox has stopped.</b>You can close this tab.</div>';
    }
    return;
  }
  if (b.id === "changeDrive") {
    const v = await pickFolder({ title: "Choose your music drive or folder", button: "Use this folder", start: "/Volumes",
      help: "Pick the drive (or folder) that holds your music collection. Kalya MusicBox keeps its project folder, reports and review folder there." });
    if (!v) return;
    try { st.status = await api("/api/root", { root: v }); st.plan = { dupes: null, recordings: null }; st.dec = { dupes: {}, recordings: {} };
      st.catalog = null; st.runs = null; st.result = { dupes: null, recordings: null }; await refreshStatus(); render(); } catch (err) { toast(err.message, true); }
    return;
  }
  if (ds.filter) { st.filter[kind] = ds.filter; st.shown[kind] = 40; return render(); }
  if (ds.catview) { st.catView = ds.catview; st.catShown = 200; return render(); }
  if (ds.sort) { st.catSort = st.catSort[0] === ds.sort ? [ds.sort, -st.catSort[1]] : [ds.sort, 1]; return render(); }
  if (ds.keep || ds.move || ds.leave) {
    const g = st.plan[kind].groups.find((x) => x.id == ds.g), d = decisionFor(kind, g);
    if (ds.keep) { d.keep = ds.keep; delete d.skip[ds.keep]; }
    if (ds.move) delete d.skip[ds.move];
    if (ds.leave) d.skip[ds.leave] = true;
    return render();
  }
  if (ds.play) return togglePlay(ds.play);
  if (ds.reveal) return openThing("reveal", ds.reveal);
  if (ds.open) return openThing("open", ds.open);
  if (ds.folder) return openThing("folder", ds.folder);
  if (ds.undo) return undo(ds.undo);
});
document.addEventListener("dblclick", (e) => {
  const tr = e.target.closest("tr[data-row]");
  if (tr && !e.target.closest("button")) mpPlayFrom(tr.dataset.row);
});
document.addEventListener("keydown", (e) => {
  if (e.code === "Space" && st.page === "player" && !/INPUT|TEXTAREA|BUTTON/.test(e.target.tagName)) { e.preventDefault(); mpAction("toggle"); }
});
const player = $("#player");
function togglePlay(path) {
  if (st.playing === path) { player.pause(); st.playing = null; render(); return; }
  mpPause();
  player.src = media("audio", path);
  player.play().catch((err) => toast("Can't play this file in the browser: " + err.message, true));
  st.playing = path;
  render();
}
player.addEventListener("ended", () => { st.playing = null; render(); });

(async () => {
  await refreshStatus();
  render();
  try { const d = await api("/api/player"); st.pl.tracks = d.tracks; st.pl.sources = d.sources; st.pl.scanned_at = d.scanned_at;
    d.tracks.forEach((t) => { MP.byId[t.id] = t; }); } catch (e) {}
  setInterval(refreshStatus, 8000);
})();
</script>
</body>
</html>
"""


def main():
    ap = argparse.ArgumentParser(description="Kalya MusicBox Ver %s: MP3 Manager & Music Player. Developed by Durgesh Kalya." % APP_VERSION)
    ap.add_argument("--version", action="version", version="Kalya MusicBox Ver %s, MP3 Manager & Music Player, developed by Durgesh Kalya (FindingPlace.org)" % APP_VERSION)
    ap.add_argument("--root", default=None, help="music drive or folder (default: the last one you chose)")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true", help="don't open the browser automatically")
    ap.add_argument("--background", action="store_true",
                    help="run without a Terminal window (used by the app icon); quits after %d idle minutes" % IDLE_MINUTES)
    a = ap.parse_args()
    run(a.root, a.port, not a.no_browser, a.background)


if __name__ == "__main__":
    main()
