﻿<#
  Install Kalya MusicBox for Windows - MP3 Manager & Music Player (Ver 1.0)
  Developed by Durgesh Kalya - FindingPlace.org - https://findingplace.org

  Started by double-clicking "Install Kalya MusicBox". It checks for everything Kalya MusicBox
  needs, installs what's missing (asking first), and adds Kalya MusicBox to the Start menu.

    Python 3 ......... from python.org (installed for your Windows account only)
    mutagen .......... song-tag library, installed privately for Kalya MusicBox
    ffmpeg ........... audio converter, only needed for "Convert to MP3"

  Options:  -Yes        answer "yes" to every question
            -Uninstall  remove Kalya MusicBox (your music is never touched)

  Safe to run again: it repairs or updates and keeps your settings and playlists.
  Written for Windows PowerShell 5.1 (built into Windows 10 and 11).
#>
param([switch]$Uninstall, [switch]$Yes)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'          # makes downloads much faster in Windows PowerShell
$AppName = 'Kalya MusicBox'
$AppVersion = '1.0'
$TestMode = ($env:KMB_TEST -eq '1')               # lets the installer be tested on non-Windows systems
$OnWindows = ($env:OS -eq 'Windows_NT')
if ($OnWindows) {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
}

$Here = Split-Path -Parent $PSScriptRoot          # the unzipped KalyaMusicBox folder
$Src = Join-Path $Here 'app'
$LocalAppData = $env:LOCALAPPDATA
if (-not $LocalAppData) { $LocalAppData = Join-Path $HOME '.local/share' }
$Base = Join-Path $LocalAppData 'KalyaMusicBox'
$AppDir = Join-Path $Base 'app'
$Venv = Join-Path $Base 'venv'
$SettingsDir = Join-Path $HOME '.mp3manager'
if ($OnWindows) {
    $VPy = Join-Path $Venv 'Scripts\python.exe'
    $VPyW = Join-Path $Venv 'Scripts\pythonw.exe'  # runs without a black console window
} else {
    $VPy = Join-Path $Venv 'bin/python'
    $VPyW = $VPy
}
$StartMenuDir = [Environment]::GetFolderPath('Programs')
$DesktopDir = [Environment]::GetFolderPath('Desktop')
if (-not $StartMenuDir) { $StartMenuDir = Join-Path $Base 'test-startmenu' }
if (-not $DesktopDir) { $DesktopDir = Join-Path $Base 'test-desktop' }
$StartLnk = Join-Path $StartMenuDir "$AppName.lnk"
$DesktopLnk = Join-Path $DesktopDir "$AppName.lnk"
$UninstKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\KalyaMusicBox'

# ------------------------------------------------------------------------------------------
function Say($m) { Write-Host $m }
function Step($m) { Write-Host ''; Write-Host $m -ForegroundColor Cyan }
function Ok($m) { Write-Host "  [OK] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  [!]  $m" -ForegroundColor Yellow }
function Fail($m, $hint) {
    Write-Host ''
    Write-Host "  [X]  $m" -ForegroundColor Red
    if ($hint) { Write-Host "       $hint" }
    Write-Host ''
    Write-Host 'Nothing else was changed. Fix the problem above and run the installer again.'
    exit 1
}
function Ask($q, $def) {
    if ($Yes) { return $true }
    $hint = '[y/N]'
    if ($def) { $hint = '[Y/n]' }
    $a = Read-Host "  $q $hint"
    if ([string]::IsNullOrWhiteSpace($a)) { return [bool]$def }
    return (@('y', 'yes') -contains $a.Trim().ToLower())
}
function Banner {
    Write-Host ''
    Write-Host "  $AppName  Ver $AppVersion" -ForegroundColor White
    Write-Host '  MP3 Manager & Music Player'
    Write-Host '  Developed by Durgesh Kalya - FindingPlace.org' -ForegroundColor DarkGray
}
function Has-Command($n) { return [bool](Get-Command $n -ErrorAction SilentlyContinue) }

# Stop a running Kalya MusicBox, using the process id it records (nothing else is touched)
function Stop-App {
    $rf = Join-Path $SettingsDir 'running.json'
    if (-not (Test-Path $rf)) { return $false }
    try { $info = Get-Content $rf -Raw | ConvertFrom-Json } catch { return $false }
    $procId = 0
    try { $procId = [int]$info.pid } catch { return $false }
    if (-not (Get-Process -Id $procId -ErrorAction SilentlyContinue)) { return $false }
    $cmd = ''
    if ($OnWindows) {
        try { $cmd = (Get-CimInstance Win32_Process -Filter "ProcessId=$procId").CommandLine } catch {}
    } else {
        try { $cmd = (Get-Content "/proc/$procId/cmdline" -Raw) } catch {}
    }
    if ($cmd -notmatch 'mp3gui') { return $false }
    Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
    return $true
}

# ------------------------------------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------------------------------------
if ($Uninstall) {
    Banner
    Step "Uninstall $AppName"
    Say '  This removes the app, its shortcuts and its private Python copy.'
    Say '  Your music, your MP3_Project folders and Python are not touched.'
    if (-not (Ask "Remove $AppName?" $false)) { Say '  Cancelled.'; exit 0 }
    Set-Location $HOME
    if (Stop-App) { Ok 'Stopped the running app' }
    foreach ($l in @($StartLnk, $DesktopLnk)) {
        if (Test-Path $l) { Remove-Item $l -Force; Ok "Removed shortcut: $l" }
    }
    if ($OnWindows -and (Test-Path $UninstKey)) { Remove-Item $UninstKey -Recurse -Force; Ok 'Removed from Settings > Apps' }
    if (Test-Path $Base) {
        Remove-Item $Base -Recurse -Force -ErrorAction SilentlyContinue
        if (Test-Path $Base) { Warn "Some files in $Base are in use; delete that folder after restarting." }
        else { Ok "Removed $Base" }
    }
    if (Test-Path $SettingsDir) {
        if (Ask 'Also remove your settings and playlists?' $false) { Remove-Item $SettingsDir -Recurse -Force; Ok 'Removed settings and playlists' }
        else { Ok "Kept your settings and playlists in $SettingsDir" }
    }
    Write-Host ''
    Write-Host "$AppName has been removed." -ForegroundColor Green
    exit 0
}

# ------------------------------------------------------------------------------------------
# Install
# ------------------------------------------------------------------------------------------
Banner
if (-not $OnWindows -and -not $TestMode) { Fail 'This installer is for Windows.' 'For a Mac, use the Mac version of Kalya MusicBox.' }
foreach ($f in @('mp3tool.py', 'mp3gui.py', 'requirements.txt', 'kalya-musicbox.ico', 'kalya-musicbox-icon.png')) {
    if (-not (Test-Path (Join-Path $Src $f))) { Fail "The file app\$f is missing." 'Unzip the whole KalyaMusicBox folder first (right-click the zip > Extract All), then run the installer from inside it.' }
}
if ($OnWindows) { Get-ChildItem $Here -Recurse -File | Unblock-File -ErrorAction SilentlyContinue }   # files from the internet

# ---------------------------------------------------------------- 1. Python
Step '1/5  Checking for Python 3'
function Test-Python($exe) {
    try {
        & $exe -c 'import sys, venv, ensurepip; sys.exit(0 if sys.version_info >= (3, 8) else 1)' 2>$null | Out-Null
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}
function Find-Python {
    $cands = New-Object System.Collections.ArrayList
    if ($OnWindows) {
        if (Has-Command 'py') {
            try { $p = & py -3 -c 'import sys; print(sys.executable)' 2>$null; if ($LASTEXITCODE -eq 0 -and $p) { [void]$cands.Add(([string]$p).Trim()) } } catch {}
        }
        foreach ($root in @((Join-Path $LocalAppData 'Programs\Python'), $env:ProgramFiles)) {
            if ($root -and (Test-Path $root)) {
                Get-ChildItem $root -Directory -Filter 'Python3*' -ErrorAction SilentlyContinue |
                    Sort-Object { [int](($_.Name -replace '\D', '') + '0') } -Descending |
                    ForEach-Object { [void]$cands.Add((Join-Path $_.FullName 'python.exe')) }
            }
        }
        $c = Get-Command python -ErrorAction SilentlyContinue
        # skip the Microsoft Store "python" shortcut, which only opens the Store
        if ($c -and $c.Source -notmatch 'WindowsApps') { [void]$cands.Add($c.Source) }
    } else {
        foreach ($n in @('python3', 'python')) { $c = Get-Command $n -ErrorAction SilentlyContinue; if ($c) { [void]$cands.Add($c.Source) } }
    }
    foreach ($x in $cands) { if ($x -and (Test-Path $x) -and (Test-Python $x)) { return $x } }
    return $null
}
$Py = Find-Python
if (-not $Py) {
    Warn "Python 3 isn't installed yet."
    Say '  Kalya MusicBox runs on Python, a free program from python.org. It is installed for your'
    Say '  Windows account only and does not need administrator rights.'
    if (-not (Ask 'Install Python now?' $true)) {
        Fail 'Python 3 is required.' 'Install it from https://www.python.org/downloads/windows/ (tick "Add python.exe to PATH"), then run this installer again.'
    }
    if (Has-Command 'winget') {
        Say '  Installing Python 3.12 with winget (a few minutes)...'
        & winget install --id Python.Python.3.12 -e --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Host
        $Py = Find-Python
    }
    if (-not $Py) {
        $arch = 'amd64'
        if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $arch = 'arm64' }
        $ver = '3.12.7'
        $url = "https://www.python.org/ftp/python/$ver/python-$ver-$arch.exe"
        $tmp = Join-Path $env:TEMP "python-$ver-$arch.exe"
        Say "  Downloading Python $ver from python.org..."
        try { Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing -ErrorAction Stop }
        catch { Fail "Couldn't download Python." 'Check your internet connection, or install Python from https://www.python.org/downloads/windows/ and run this installer again.' }
        Say '  Installing Python (a minute or two)...'
        Start-Process -FilePath $tmp -ArgumentList '/quiet', 'InstallAllUsers=0', 'PrependPath=1', 'Include_launcher=1', 'Include_test=0' -Wait | Out-Null
        Remove-Item $tmp -ErrorAction SilentlyContinue
        $Py = Find-Python
    }
    if (-not $Py) { Fail "Python didn't install correctly." 'Install it from https://www.python.org/downloads/windows/ (tick "Add python.exe to PATH"), then run this installer again.' }
}
$pyver = & $Py -c 'import sys; print("Python %d.%d.%d" % sys.version_info[:3])'
Ok "Using $pyver ($Py)"

# ---------------------------------------------------------------- 2. App + private Python environment
Step "2/5  Installing $AppName and its Python library"
if (Stop-App) { Ok 'Stopped the running copy so it can be updated' }
New-Item -ItemType Directory -Force -Path $AppDir | Out-Null
foreach ($f in @('mp3tool.py', 'mp3gui.py', 'requirements.txt', 'kalya-musicbox.ico', 'kalya-musicbox-icon.png')) {
    Copy-Item (Join-Path $Src $f) (Join-Path $AppDir $f) -Force
}
New-Item -ItemType Directory -Force -Path (Join-Path $Base 'installer') | Out-Null
Copy-Item $PSCommandPath (Join-Path $Base 'installer\install.ps1') -Force    # used by Settings > Apps > Uninstall
if (Test-Path (Join-Path $Here 'README.txt')) { Copy-Item (Join-Path $Here 'README.txt') (Join-Path $Base 'README.txt') -Force }
Ok "App files copied to $Base"

$venvOk = $false
if (Test-Path $VPy) { & $VPy -c 'import sys' 2>$null | Out-Null; $venvOk = ($LASTEXITCODE -eq 0) }
if ($venvOk) { Ok 'Private Python environment already exists' }
else {
    if (Test-Path $Venv) { Remove-Item $Venv -Recurse -Force }
    & $Py -m venv $Venv | Out-Host
    if (-not (Test-Path $VPy)) { Fail "Couldn't create the private Python environment." }
    Ok "Created a private Python environment (doesn't affect anything else on your PC)"
}
Say '  Downloading the song-tag library (mutagen)...'
& $VPy -m pip install --quiet --disable-pip-version-check --upgrade pip 2>$null | Out-Null
& $VPy -m pip install --quiet --disable-pip-version-check --upgrade -r (Join-Path $AppDir 'requirements.txt') | Out-Host
& $VPy -c 'import mutagen' 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) { Fail "Couldn't install the mutagen library." 'Check your internet connection, then run the installer again.' }
$mv = & $VPy -c 'import mutagen; print(mutagen.version_string)'
Ok "mutagen $mv installed"

# Terminal version: mp3tool.cmd dupes / convert / catalog ...
$toolCmd = Join-Path $Base 'mp3tool.cmd'
Set-Content -Path $toolCmd -Encoding ASCII -Value "@echo off`r`n`"%~dp0venv\Scripts\python.exe`" `"%~dp0app\mp3tool.py`" %*"

# ---------------------------------------------------------------- 3. ffmpeg
Step '3/5  Checking for ffmpeg (used by Convert to MP3)'
function Find-FFmpeg {
    $c = Get-Command ffmpeg -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    if ($OnWindows) {
        $list = @((Join-Path $Base 'ffmpeg\bin\ffmpeg.exe'), (Join-Path $LocalAppData 'Microsoft\WinGet\Links\ffmpeg.exe'))
        $pk = Join-Path $LocalAppData 'Microsoft\WinGet\Packages'
        if (Test-Path $pk) {
            $list += @(Get-ChildItem $pk -Directory -Filter 'Gyan.FFmpeg*' -ErrorAction SilentlyContinue |
                       Get-ChildItem -Recurse -Filter 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
        }
        foreach ($x in $list) { if ($x -and (Test-Path $x)) { return $x } }
    }
    return $null
}
$ff = Find-FFmpeg
if ($ff) { Ok "ffmpeg found ($ff)" }
else {
    Warn "ffmpeg isn't installed. Everything works without it except Convert to MP3."
    if (Ask 'Install ffmpeg now? (about 100 MB download)' $true) {
        if (Has-Command 'winget') {
            Say '  Installing ffmpeg with winget (a few minutes)...'
            & winget install --id Gyan.FFmpeg -e --silent --accept-package-agreements --accept-source-agreements | Out-Host
            $ff = Find-FFmpeg
        }
        if (-not $ff -and $OnWindows) {
            Say '  Downloading ffmpeg from gyan.dev (the build recommended by ffmpeg.org)...'
            $zip = Join-Path $env:TEMP 'ffmpeg-release-essentials.zip'
            $tmpDir = Join-Path $Base 'ffmpeg-download'
            try {
                Invoke-WebRequest -Uri 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' -OutFile $zip -UseBasicParsing -ErrorAction Stop
                if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force }
                Expand-Archive -Path $zip -DestinationPath $tmpDir -Force
                $inner = Get-ChildItem $tmpDir -Directory | Select-Object -First 1
                $dest = Join-Path $Base 'ffmpeg'
                if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
                Move-Item $inner.FullName $dest
                Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
                Remove-Item $zip -ErrorAction SilentlyContinue
            } catch { Warn "Couldn't download ffmpeg: $($_.Exception.Message)" }
            $ff = Find-FFmpeg
        }
    }
    if ($ff) { Ok "ffmpeg installed ($ff)" }
    else { Warn 'Skipped ffmpeg. You can run this installer again any time to add it.' }
}

# ---------------------------------------------------------------- 4. Shortcuts + Settings > Apps
Step "4/5  Adding $AppName to the Start menu"
$gui = Join-Path $AppDir 'mp3gui.py'
$ico = Join-Path $AppDir 'kalya-musicbox.ico'
function New-AppShortcut($lnk) {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $lnk) | Out-Null
    if ($OnWindows) {
        $ws = New-Object -ComObject WScript.Shell
        $s = $ws.CreateShortcut($lnk)
        $s.TargetPath = $VPyW
        $s.Arguments = '"' + $gui + '" --background'
        $s.WorkingDirectory = $AppDir
        $s.IconLocation = "$ico,0"
        $s.Description = 'Kalya MusicBox - MP3 Manager & Music Player'
        $s.Save()
    } else {
        Set-Content -Path $lnk -Value "$VPyW `"$gui`" --background"     # test mode stand-in
    }
}
New-AppShortcut $StartLnk
Ok 'Start menu shortcut created'
if (Ask 'Add a Kalya MusicBox icon to your Desktop?' $true) { New-AppShortcut $DesktopLnk; Ok 'Desktop shortcut created' }

if ($OnWindows) {
    New-Item -Path $UninstKey -Force | Out-Null
    $sizeKb = 0
    try { $sizeKb = [int]((Get-ChildItem $Base -Recurse -File | Measure-Object -Property Length -Sum).Sum / 1KB) } catch {}
    $vals = @{
        DisplayName = $AppName; DisplayVersion = $AppVersion; Publisher = 'FindingPlace.org'
        DisplayIcon = $ico; InstallLocation = $Base; URLInfoAbout = 'https://findingplace.org'
        Comments = 'MP3 Manager & Music Player - Developed by Durgesh Kalya'
        UninstallString = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $Base 'installer\install.ps1') + '" -Uninstall'
    }
    foreach ($k in $vals.Keys) { Set-ItemProperty -Path $UninstKey -Name $k -Value $vals[$k] }
    Set-ItemProperty -Path $UninstKey -Name NoModify -Value 1 -Type DWord
    Set-ItemProperty -Path $UninstKey -Name NoRepair -Value 1 -Type DWord
    Set-ItemProperty -Path $UninstKey -Name EstimatedSize -Value $sizeKb -Type DWord
    Ok 'Listed in Settings > Apps (so it can be uninstalled from there too)'
}

# ---------------------------------------------------------------- 5. Check
Step '5/5  Checking the installation'
& $VPy (Join-Path $AppDir 'mp3tool.py') --version 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) { Fail "The app doesn't start." 'Please send the messages above to the developer.' }
$env:KMB_APPDIR = $AppDir
& $VPy -c 'import os, sys; sys.path.insert(0, os.environ["KMB_APPDIR"]); import mp3gui' 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) { Fail "The app window doesn't load." 'Please send the messages above to the developer.' }
Ok 'Everything is in place'

Write-Host ''
Write-Host "$AppName is installed." -ForegroundColor Green
Say '  Open it from the Start menu (or the Desktop icon). It opens in your web browser.'
Say "  Terminal version:  `"$toolCmd`" --help"
Say '  To remove it later: Settings > Apps > Kalya MusicBox > Uninstall,'
Say '  or double-click "Uninstall Kalya MusicBox" in this folder.'
if (-not $TestMode -and (Ask "Open $AppName now?" $true)) {
    Start-Process -FilePath $VPyW -ArgumentList @('"' + $gui + '"', '--background') -WorkingDirectory $AppDir
}
exit 0
