KALYA MUSICBOX  ·  Ver 1.0
MP3 Manager & Music Player for Mac
Developed by Durgesh Kalya · FindingPlace.org · https://findingplace.org

Free. No subscription, no account, no ads. Everything runs on your own Mac.


WHAT IT DOES
  PLAYER
  • Plays music from any folders on your Mac or drives, with shuffle, repeat and crossfade.
  • Pop-out player: a small player window you can keep on the side. In Chrome or Edge it floats
    on top of all your apps, even when the browser is minimized.

  UTILITIES
  • Convert to MP3: turns WMA, WAV, AAC/M4A, FLAC, OGG/Opus, AIFF, APE and WavPack into MP3s.
    Your original files are never changed.
  • Find duplicates: finds copies of the same song by comparing the actual audio, not file
    names. Duplicates are MOVED to a review folder, never deleted, and every move can be undone.
  • Tag with Picard: step-by-step help for adding song titles, albums and cover art with the
    free MusicBrainz Picard app.
  • Same recording: after tagging, finds remaining copies (e.g. a 128 kbps and a 320 kbps copy).
  • Build catalog: every song with its tags and cover art, and which songs still need attention.
  • History & undo: put back anything the duplicate tools moved.


INSTALL (about 5 minutes)
  1. Unzip KalyaMusicBox.zip if it isn't already (double-click it).
  2. Open the KalyaMusicBox folder and double-click  "Install Kalya MusicBox".
  3. Answer the questions in the window that opens. The installer checks for everything
     Kalya MusicBox needs and offers to install what's missing:
       – Python 3 (Apple's free Command Line Tools, if your Mac doesn't have Python yet)
       – mutagen, a small library for reading song tags (installed privately for this app only)
       – ffmpeg, only needed for "Convert to MP3" (installed with Homebrew, which asks for your
         Mac password). You can skip it and add it later by running the installer again.
  4. When it's done, open Kalya MusicBox from Applications or Launchpad.
     It opens in your web browser. It runs only on your Mac; nothing is sent anywhere.

  IF YOUR MAC SAYS THE INSTALLER "CAN'T BE OPENED"
  macOS is careful with files downloaded from the internet. Either:
    • Open System Settings → Privacy & Security, scroll down, and click "Open Anyway"
      next to the message about "Install Kalya MusicBox", then double-click it again; or
    • (older macOS) right-click "Install Kalya MusicBox", choose Open, then click Open; or
    • Open Terminal and type  bash  followed by a space, drag "Install Kalya MusicBox" into the
      Terminal window, and press Return.


FIRST STEPS
  • For the Utilities, click "Change" under MUSIC DRIVE FOR UTILITIES and choose the drive or
    folder that holds your music. Then click "Set up" to create the MP3_Project folder there.
  • Kalya MusicBox opens on the Player: click "Add folder" and choose any music folders.
  • Click "Pop out player" (or the small window icon under the song in the sidebar) for a mini
    player you can keep on the side. Keep the main Kalya MusicBox tab open: that's where the
    music plays from.
  • macOS may ask whether Kalya MusicBox may access files on a removable volume: click Allow.
  • To stop the app, click "Quit Kalya MusicBox" in the sidebar. If you just close the browser
    tab, it stops by itself after 20 minutes.


UPDATE
  Download the new version and run "Install Kalya MusicBox" again. Your settings are kept.


UNINSTALL
  Double-click "Uninstall Kalya MusicBox". It removes the app and its private Python copy.
  Your music and your MP3_Project folders are never touched. (Python, Homebrew and ffmpeg are
  left in place because other apps may use them.)


TERMINAL VERSION (optional, for advanced users)
  "~/Library/Application Support/KalyaMusicBox/bin/mp3tool" --help
  e.g.  mp3tool dupes, mp3tool convert FOLDER -o FOLDER, mp3tool catalog


WHERE THINGS ARE KEPT
  App:        /Applications/Kalya MusicBox.app
  Program:    ~/Library/Application Support/KalyaMusicBox
  Settings:   ~/.mp3manager   (Player folders, last music drive, a log file)
  Per drive:  MP3_Project folder on your music drive (Library, review folder, reports)


REQUIREMENTS
  macOS 10.15 (Catalina) or newer, Apple Silicon or Intel. An internet connection during
  installation. Safari, Chrome, Firefox or Edge.


ABOUT FINDINGPLACE.ORG
  We believe useful software should be accessible to everyone. Inspired by the early spirit of
  the internet, we create and share practical tools that solve real problems without unnecessary
  subscriptions, paywalls, or restrictions.
  Made for humans to be humans again. Made in the USA by an immigrant.
  Find out more at https://findingplace.org
