#!/bin/bash
#
# Install Kalya MusicBox — MP3 Manager & Music Player (Ver 1.0)
# Developed by Durgesh Kalya · FindingPlace.org · https://findingplace.org
#
# Double-click this file to install. It checks for everything Kalya MusicBox needs and installs
# what's missing (asking first), then puts "Kalya MusicBox" in your Applications folder.
#
#   Python 3 ............ Apple's free Command Line Tools (or an existing Python 3.8+)
#   mutagen ............. song-tag library, installed privately for Kalya MusicBox only
#   ffmpeg .............. audio converter, via Homebrew (only needed for "Convert to MP3")
#
# Options:  --yes        answer "yes" to every question
#           --uninstall  remove Kalya MusicBox (your music is never touched)
#
# Works with the bash that ships with macOS. Safe to run again: it repairs or updates.

set -u
APP_NAME="Kalya MusicBox"
APP_VERSION="1.0"
BUNDLE_ID="org.findingplace.kalyamusicbox"
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/app"
SUPPORT="$HOME/Library/Application Support/KalyaMusicBox"
SETTINGS_DIR="$HOME/.mp3manager"
TEST_MODE="${KMB_TEST:-0}"          # lets the installer be tested on non-Mac systems

YES=0; UNINSTALL=0
for arg in "$@"; do
    case "$arg" in
        -y|--yes) YES=1 ;;
        --uninstall) UNINSTALL=1 ;;
        -h|--help) sed -n '2,19p' "$0"; exit 0 ;;
    esac
done

if [ -t 1 ]; then
    B=$'\033[1m'; G=$'\033[32m'; Y=$'\033[33m'; R=$'\033[31m'; C=$'\033[36m'; D=$'\033[2m'; N=$'\033[0m'
else
    B=""; G=""; Y=""; R=""; C=""; D=""; N=""
fi
say()  { echo "$@"; }
step() { echo; echo "${B}${C}$1${N}"; }
ok()   { echo "  ${G}✓${N} $1"; }
warn() { echo "  ${Y}!${N} $1"; }
fail() {
    echo; echo "  ${R}✗ $1${N}"
    [ $# -gt 1 ] && echo "    $2"
    echo; echo "Nothing else was changed. Fix the problem above and run the installer again."
    exit 1
}
# ask "question" Y|N  -> returns 0 for yes
ask() {
    local q="$1" def="$2" ans hint
    if [ "$YES" = 1 ]; then return 0; fi
    if [ "$def" = Y ]; then hint="[Y/n]"; else hint="[y/N]"; fi
    read -r -p "  $q $hint " ans || ans=""
    ans="$(echo "$ans" | tr '[:upper:]' '[:lower:]')"
    if [ -z "$ans" ]; then [ "$def" = Y ]; return; fi
    [ "$ans" = y ] || [ "$ans" = yes ]
}

banner() {
    echo
    echo "${B}  ♫  ${APP_NAME}${N}  ${D}Ver ${APP_VERSION}${N}"
    echo "     MP3 Manager & Music Player"
    echo "     ${D}Developed by Durgesh Kalya · FindingPlace.org${N}"
}

stop_app() {   # stop a running Kalya MusicBox, using the process id it records (nothing else is touched)
    local pid
    pid="$(sed -n 's/.*"pid": *\([0-9][0-9]*\).*/\1/p' "$SETTINGS_DIR/running.json" 2>/dev/null)"
    if [ -n "$pid" ] && ps -p "$pid" -o command= 2>/dev/null | grep -q "mp3gui.py"; then
        kill "$pid" 2>/dev/null && sleep 1 && return 0
    fi
    return 1
}

app_bundles() {   # every place the app may have been installed
    echo "/Applications/${APP_NAME}.app"
    echo "$HOME/Applications/${APP_NAME}.app"
}

# ------------------------------------------------------------------------------------------
# Uninstall
# ------------------------------------------------------------------------------------------
if [ "$UNINSTALL" = 1 ]; then
    banner
    step "Uninstall ${APP_NAME}"
    say "  This removes the app and its private Python copy."
    say "  Your music, your MP3_Project folders, Python, Homebrew and ffmpeg are not touched."
    ask "Remove ${APP_NAME}?" N || { say "  Cancelled."; exit 0; }
    # stop it if it's running
    stop_app && ok "Stopped the running app"
    while IFS= read -r b; do
        if [ -d "$b" ]; then rm -rf "$b" && ok "Removed $b"; fi
    done < <(app_bundles)
    if [ -d "$SUPPORT" ]; then rm -rf "$SUPPORT" && ok "Removed $SUPPORT"; fi
    if [ -d "$SETTINGS_DIR" ]; then
        if ask "Also remove your settings (Player folder list, last music drive)?" N; then
            rm -rf "$SETTINGS_DIR" && ok "Removed settings"
        else
            ok "Kept your settings in $SETTINGS_DIR"
        fi
    fi
    echo; echo "${G}${B}${APP_NAME} has been removed.${N}"
    exit 0
fi

# ------------------------------------------------------------------------------------------
# Install
# ------------------------------------------------------------------------------------------
banner
if [ "$(uname)" != "Darwin" ] && [ "$TEST_MODE" != 1 ]; then
    fail "This installer is for macOS." "Kalya MusicBox for Windows isn't available yet."
fi
for f in mp3tool.py mp3gui.py requirements.txt kalya-musicbox-icon.png; do
    [ -f "$SRC/$f" ] || fail "The file app/$f is missing." "Unzip the whole KalyaMusicBox folder and run the installer from inside it."
done
# files downloaded from the internet are marked "quarantined"; we created/verified these ourselves
xattr -dr com.apple.quarantine "$HERE" 2>/dev/null || true

# ---------------------------------------------------------------- 1. Python
step "1/5  Checking for Python 3"

python_ok() {   # usable Python 3.8+ with venv support
    [ -x "$1" ] && "$1" -c 'import sys, venv, ensurepip; sys.exit(0 if sys.version_info >= (3, 8) else 1)' >/dev/null 2>&1
}
clt_installed() { xcode-select -p >/dev/null 2>&1; }

find_python() {
    local c
    for c in /opt/homebrew/bin/python3 /usr/local/bin/python3 \
             /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
             $(ls -d /Library/Frameworks/Python.framework/Versions/3.*/bin/python3 2>/dev/null | sort -r); do
        if python_ok "$c"; then echo "$c"; return 0; fi
    done
    # /usr/bin/python3 is only real once Apple's Command Line Tools are installed;
    # before that, running it pops up an install dialog, so don't touch it.
    if clt_installed || [ "$TEST_MODE" = 1 ]; then
        c="$(command -v python3 2>/dev/null)"
        if [ -n "$c" ] && python_ok "$c"; then echo "$c"; return 0; fi
        if python_ok /usr/bin/python3; then echo /usr/bin/python3; return 0; fi
    fi
    return 1
}

PY="$(find_python)"
if [ -z "$PY" ]; then
    warn "Python 3 isn't installed yet."
    say "  Apple provides it free as part of the \"Command Line Tools\" (about 1 GB download)."
    if ask "Install Apple's Command Line Tools now?" Y; then
        xcode-select --install >/dev/null 2>&1
        say "  A window should appear: click ${B}Install${N}, then ${B}Agree${N}."
        say "  This usually takes 5–20 minutes. Waiting for it to finish (you can leave this window open)…"
        waited=0
        until clt_installed && python_ok /usr/bin/python3; do
            sleep 15; waited=$((waited + 15)); printf "."
            if [ "$waited" -ge 5400 ]; then echo; fail "The Command Line Tools didn't finish installing within 90 minutes." \
                "Install them from the window that appeared (or run: xcode-select --install), then run this installer again."; fi
        done
        echo
        PY=/usr/bin/python3
    else
        fail "Python 3 is required." "Either run the installer again and choose Yes, or install Python from https://www.python.org/downloads/macos/"
    fi
fi
ok "Using $("$PY" -c 'import sys; print("Python %d.%d.%d" % sys.version_info[:3])') ($PY)"

# ---------------------------------------------------------------- 2. App files + private Python environment
step "2/5  Installing ${APP_NAME} and its Python library"
mkdir -p "$SUPPORT/app" "$SUPPORT/bin" || fail "Couldn't create $SUPPORT"
stop_app && ok "Stopped the running copy so it can be updated"
cp "$SRC/mp3tool.py" "$SRC/mp3gui.py" "$SRC/requirements.txt" "$SRC/kalya-musicbox-icon.png" "$SUPPORT/app/" \
    || fail "Couldn't copy the app files."
ok "App files copied to ~/Library/Application Support/KalyaMusicBox"

VENV="$SUPPORT/venv"
VPY="$VENV/bin/python"
if [ -x "$VPY" ] && "$VPY" -c 'import sys' >/dev/null 2>&1; then
    ok "Private Python environment already exists"
else
    rm -rf "$VENV"
    "$PY" -m venv "$VENV" >/dev/null 2>&1 || fail "Couldn't create the private Python environment." "Python said: $("$PY" -m venv "$VENV" 2>&1 | tail -1)"
    ok "Created a private Python environment (doesn't affect anything else on your Mac)"
fi
say "  Downloading the song-tag library (mutagen)…"
"$VPY" -m pip install --quiet --disable-pip-version-check --upgrade pip >/dev/null 2>&1 || true
if ! "$VPY" -m pip install --quiet --disable-pip-version-check --upgrade -r "$SUPPORT/app/requirements.txt"; then
    fail "Couldn't download the mutagen library." "Check your internet connection, then run the installer again."
fi
"$VPY" -c 'import mutagen' 2>/dev/null || fail "The mutagen library didn't install correctly."
ok "mutagen $("$VPY" -c 'import mutagen; print(mutagen.version_string)') installed"

cat > "$SUPPORT/bin/mp3tool" <<EOF
#!/bin/bash
# Terminal version of Kalya MusicBox (mp3tool dupes, convert, catalog, ...)
exec "$VPY" "$SUPPORT/app/mp3tool.py" "\$@"
EOF
chmod +x "$SUPPORT/bin/mp3tool"

# ---------------------------------------------------------------- 3. ffmpeg
step "3/5  Checking for ffmpeg (used by Convert to MP3)"
find_ffmpeg() {
    local c
    for c in "$(command -v ffmpeg 2>/dev/null)" /opt/homebrew/bin/ffmpeg /usr/local/bin/ffmpeg; do
        if [ -n "$c" ] && [ -x "$c" ]; then echo "$c"; return 0; fi
    done
    return 1
}
find_brew() {
    local c
    for c in "$(command -v brew 2>/dev/null)" /opt/homebrew/bin/brew /usr/local/bin/brew; do
        if [ -n "$c" ] && [ -x "$c" ]; then echo "$c"; return 0; fi
    done
    return 1
}
FFMPEG="$(find_ffmpeg)"
if [ -n "$FFMPEG" ]; then
    ok "ffmpeg found ($FFMPEG)"
else
    warn "ffmpeg isn't installed. Everything works without it except Convert to MP3."
    BREW="$(find_brew)"
    if [ -z "$BREW" ]; then
        say "  ffmpeg is installed with Homebrew, the standard free installer for Mac tools (https://brew.sh)."
        if ask "Install Homebrew now? It will ask for your Mac password." N; then
            /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" </dev/tty
            BREW="$(find_brew)"
            [ -n "$BREW" ] && ok "Homebrew installed" || warn "Homebrew didn't install; skipping ffmpeg."
        fi
    fi
    if [ -n "${BREW:-}" ]; then
        if ask "Install ffmpeg with Homebrew now? (takes a few minutes)" Y; then
            "$BREW" install ffmpeg && FFMPEG="$(find_ffmpeg)"
        fi
    fi
    if [ -n "$FFMPEG" ]; then ok "ffmpeg installed ($FFMPEG)"
    else warn "Skipped ffmpeg. You can run this installer again any time to add it."; fi
fi

# ---------------------------------------------------------------- 4. The app
step "4/5  Adding ${APP_NAME} to Applications"
if [ -w /Applications ]; then APPDIR=/Applications; else APPDIR="$HOME/Applications"; mkdir -p "$APPDIR"; fi
while IFS= read -r b; do [ -d "$b" ] && rm -rf "$b"; done < <(app_bundles)
BUNDLE="$APPDIR/${APP_NAME}.app"
mkdir -p "$BUNDLE/Contents/MacOS" "$BUNDLE/Contents/Resources" || fail "Couldn't create $BUNDLE"

cat > "$BUNDLE/Contents/MacOS/KalyaMusicBox" <<'EOF'
#!/bin/bash
# Kalya MusicBox launcher: starts the app (or opens the window if it's already running).
SUPPORT="$HOME/Library/Application Support/KalyaMusicBox"
if [ ! -x "$SUPPORT/venv/bin/python" ] || [ ! -f "$SUPPORT/app/mp3gui.py" ]; then
    osascript -e 'display alert "Kalya MusicBox needs repairing" message "Please run Install Kalya MusicBox again."' >/dev/null 2>&1
    exit 1
fi
# Starts the music server in the background (or reopens its window) and returns at once.
export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES
exec "$SUPPORT/venv/bin/python" "$SUPPORT/app/mp3gui.py" --background
EOF
chmod +x "$BUNDLE/Contents/MacOS/KalyaMusicBox"

cat > "$BUNDLE/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>${APP_NAME}</string>
  <key>CFBundleDisplayName</key><string>${APP_NAME}</string>
  <key>CFBundleIdentifier</key><string>${BUNDLE_ID}</string>
  <key>CFBundleVersion</key><string>${APP_VERSION}</string>
  <key>CFBundleShortVersionString</key><string>${APP_VERSION}</string>
  <key>CFBundleExecutable</key><string>KalyaMusicBox</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSUIElement</key><true/>
  <key>LSMinimumSystemVersion</key><string>10.15</string>
  <key>NSHumanReadableCopyright</key><string>MP3 Manager &amp; Music Player · Developed by Durgesh Kalya · FindingPlace.org</string>
</dict>
</plist>
EOF

# App icon (.icns) made from the logo with macOS's own tools
if command -v sips >/dev/null 2>&1 && command -v iconutil >/dev/null 2>&1; then
    ICONSET="$(mktemp -d)/AppIcon.iconset"; mkdir -p "$ICONSET"
    for sz in 16 32 128 256 512; do
        sips -z $sz $sz "$SRC/kalya-musicbox-icon.png" --out "$ICONSET/icon_${sz}x${sz}.png" >/dev/null 2>&1
        sips -z $((sz * 2)) $((sz * 2)) "$SRC/kalya-musicbox-icon.png" --out "$ICONSET/icon_${sz}x${sz}@2x.png" >/dev/null 2>&1
    done
    if iconutil -c icns "$ICONSET" -o "$BUNDLE/Contents/Resources/AppIcon.icns" >/dev/null 2>&1; then ok "App icon created"
    else warn "Couldn't create the app icon (the app still works)."; fi
    rm -rf "$(dirname "$ICONSET")"
else
    cp "$SRC/kalya-musicbox-icon.png" "$BUNDLE/Contents/Resources/AppIcon.png"
fi
touch "$BUNDLE"
LSREG=/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister
[ -x "$LSREG" ] && "$LSREG" -f "$BUNDLE" >/dev/null 2>&1
ok "Installed $BUNDLE"

# remove the old Desktop launchers from earlier, hand-run versions (only ones we made)
for old in "$HOME/Desktop/Kalya MusicBox.command" "$HOME/Desktop/MP3 Manager.command"; do
    if [ -f "$old" ] && grep -q "mp3gui.py" "$old" 2>/dev/null; then rm -f "$old" && ok "Removed old Desktop launcher: $(basename "$old")"; fi
done

# ---------------------------------------------------------------- 5. Check
step "5/5  Checking the installation"
"$VPY" "$SUPPORT/app/mp3tool.py" --version >/dev/null 2>&1 || fail "The app doesn't start." "Please send the messages above to the developer."
"$VPY" -c "import sys; sys.path.insert(0, '$SUPPORT/app'); import mp3gui" >/dev/null 2>&1 || fail "The app window doesn't load."
ok "Everything is in place"

echo
echo "${G}${B}${APP_NAME} is installed.${N}"
echo "  Open it from ${B}Applications${N} or ${B}Launchpad${N}; it opens in your web browser."
echo "  Terminal version:  ${D}\"$SUPPORT/bin/mp3tool\" --help${N}"
echo "  To remove it later, double-click ${B}Uninstall Kalya MusicBox${N}."
if [ "$TEST_MODE" != 1 ] && ask "Open ${APP_NAME} now?" Y; then
    open "$BUNDLE"
fi
