#!/bin/bash
# Uninstall Kalya MusicBox. Your music and MP3_Project folders are never touched.
exec /bin/bash "$(cd "$(dirname "$0")" && pwd)/Install Kalya MusicBox.command" --uninstall "$@"
