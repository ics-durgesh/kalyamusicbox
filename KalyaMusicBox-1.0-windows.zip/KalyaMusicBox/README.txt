KALYA MUSICBOX  -  Ver 1.0 for Windows
MP3 Manager & Music Player
Developed by Durgesh Kalya - FindingPlace.org - https://findingplace.org

Free. No subscription, no account, no ads. Everything runs on your own PC.


WHAT IT DOES
  PLAYER
  - Player: plays music from any folders on your PC or drives. Browse by Albums (cover tiles;
    click one to see and play its songs) or Songs, with shuffle, repeat and crossfade.
    Songs without album tags are grouped by their folder.
  - Playlists: press + next to any song (or "Add album to playlist") to add it to your current
    playlist. Create, open, rename, reorder, play or shuffle playlists.
  - MP3 Catalog: your whole music drive organised into albums, with what still needs cover art
    or tags. Click an album to see and play its songs.
  - Sleep timer: stop the music after 15-90 minutes, at the end of the song, or after a time
    you type (hh:mm, e.g. 00:10). It fades out gently, then pauses.
  - Pop-out player: a small player window you can keep on the side. In Chrome or Edge it floats
    on top of all your apps, even when the browser is minimized.

  UTILITIES
  - Convert to MP3: WMA, WAV, AAC/M4A, FLAC, OGG/Opus, AIFF, APE and WavPack to MP3, keeping
    tags and cover art. Your original files are never changed.
  - Find duplicates: finds copies of the same song by their sound, not file names. Duplicates
    are MOVED to a review folder, never deleted, and every move can be undone.
  - Tag with Picard / Same recording: add correct titles, albums and cover art with the free
    MusicBrainz Picard app, then find lower-quality copies of the same recording.
  - History & undo: put back anything the duplicate tools moved.


INSTALL (about 5 minutes)
  1. Right-click KalyaMusicBox-1.0-windows.zip and choose "Extract All...", then open the
     extracted KalyaMusicBox folder.
  2. Double-click "Install Kalya MusicBox".
  3. Answer the questions in the window that opens. The installer checks for everything
     Kalya MusicBox needs and offers to install what's missing:
       - Python 3 (free, from python.org; installed for your Windows account only)
       - mutagen, a small library for reading song tags (installed privately for this app)
       - ffmpeg, only needed for "Convert to MP3" (about 100 MB). You can skip it and add it
         later by running the installer again.
     No administrator password is needed.
  4. Open Kalya MusicBox from the Start menu or the Desktop icon. It opens in your web browser.
     It runs only on your PC; nothing is sent anywhere.

  IF WINDOWS SHOWS A WARNING
  - "Windows protected your PC": click "More info", then "Run anyway". (This appears because
    the installer isn't signed with a paid certificate.)
  - "Open File - Security Warning": click "Run".
  - Tip: before extracting, you can right-click the zip > Properties > tick "Unblock" > OK.


FIRST STEPS
  - Kalya MusicBox opens on the Player: click "Add folder" and choose your music folders
    (use "This PC" to pick a drive such as D: or E:).
  - For the Utilities, click "Change" under MUSIC DRIVE FOR UTILITIES and choose the drive or
    folder that holds your music. Then click "Set up" to create the MP3_Project folder there.
  - Light or dark: the app follows Windows (Auto). Use the Theme switch (Auto / Light / Dark)
    at the bottom of the sidebar to choose.
  - Keep the Kalya MusicBox browser tab open while music plays (minimizing is fine).
  - To stop the app, click "Quit Kalya MusicBox" in the sidebar. If you just close the browser
    tab, it stops by itself after 20 minutes.


UPDATE
  Download the new version and run "Install Kalya MusicBox" again. Settings and playlists are kept.


UNINSTALL
  Settings > Apps > Installed apps > Kalya MusicBox > Uninstall,
  or double-click "Uninstall Kalya MusicBox" in this folder.
  Your music and your MP3_Project folders are never touched. (Python is left in place because
  other programs may use it.)


TERMINAL VERSION (optional, for advanced users)
  "%LOCALAPPDATA%\KalyaMusicBox\mp3tool.cmd" --help
  e.g.  mp3tool dupes, mp3tool convert FOLDER -o FOLDER, mp3tool catalog


WHERE THINGS ARE KEPT
  Program:    %LOCALAPPDATA%\KalyaMusicBox   (app, private Python, ffmpeg if installed by us)
  Shortcuts:  Start menu and Desktop
  Settings:   %USERPROFILE%\.mp3manager      (Player folders, playlists, last music drive, log)
  Per drive:  MP3_Project folder on your music drive (Library, review folder, reports)


REQUIREMENTS
  Windows 10 or 11 (64-bit, including ARM). An internet connection during installation.
  Microsoft Edge, Chrome or Firefox.


ABOUT FINDINGPLACE.ORG
  We believe useful software should be accessible to everyone. Inspired by the early spirit of
  the internet, we create and share practical tools that solve real problems without unnecessary
  subscriptions, paywalls, or restrictions.
  Made for humans to be humans again. Made in the USA by an immigrant.
  Find out more at https://findingplace.org
