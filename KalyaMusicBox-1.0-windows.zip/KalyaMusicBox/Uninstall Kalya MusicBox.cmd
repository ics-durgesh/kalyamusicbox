@echo off
rem Uninstall Kalya MusicBox. Your music and MP3_Project folders are never touched.
title Uninstall Kalya MusicBox
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\install.ps1" -Uninstall %*
echo.
pause
