@echo off
rem Install Kalya MusicBox - MP3 Manager & Music Player. Developed by Durgesh Kalya, FindingPlace.org
title Install Kalya MusicBox
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\install.ps1" %*
echo.
pause
