#!/usr/bin/env python3
"""
mp3tool.py — Safe duplicate cleanup and cataloging for a music library.
Part of Kalya MusicBox Ver 1.0 (MP3 Manager & Music Player) · Developed by Durgesh Kalya · FindingPlace.org · https://findingplace.org
(The engine behind both the Terminal commands and the Kalya MusicBox window, mp3gui.py.)

Everything lives in MP3_Project on the music drive:

    MUSIC-DK/
      Music/, Music_1/ ...           your music (scanned)
      MP3_Project/
        tools/                       mp3tool.py and mp3gui.py
        Library/                     where Picard puts tagged, organized music (scanned)
        _Duplicates_Review/<run>/    duplicates are MOVED here, never deleted
        reports/                     previews, move records, catalogs

SAFETY RULES
  * Nothing is ever deleted. Duplicates are moved to _Duplicates_Review, keeping their
    original folder structure, and every move is recorded so `undo` can put it back.
  * Commands only PREVIEW unless you add --apply.
  * Files are never matched by name. Two files only count as duplicates when their
    content proves it (identical audio data, or the same MusicBrainz recording ID).
  * Before each move, both files are re-checked from disk.

COMMANDS
  setup                    Create the MP3_Project folders (and a desktop launcher for the window)
  dupes      [--apply]     Step 1: identical files and same audio with different tags
  recordings [--apply]     Step 3 (after tagging with Picard): same MusicBrainz recording
             [--across-albums]   also flag the same recording on different albums
  undo       [MANIFEST]    Put back everything moved by a run (default: the latest run)
  catalog                  Write a spreadsheet (CSV) of every song with its tags
  convert    SRC [-o DST]  Convert WMA, WAV, AAC/M4A, FLAC, OGG/Opus, AIFF, APE, WavPack to MP3
  gui                      Open the Kalya MusicBox window

Run `mp3tool COMMAND -h` for details.
"""

import argparse
import csv
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys

APP_VERSION = "1.0"
DEFAULT_ROOT = "/Volumes/MUSIC-DK"
PROJECT = "MP3_Project"
REVIEW = "_Duplicates_Review"
AUDIO_EXT = {".mp3", ".m4a", ".aac", ".wma", ".flac", ".ogg", ".opus", ".wav", ".aiff", ".aif", ".alac"}
SKIP_DIRS = {".Spotlight-V100", ".Trashes", ".fseventsd", ".TemporaryItems",
             ".DocumentRevisions-V100", "System Volume Information", "$RECYCLE.BIN"}
TAG_FIELDS = ["title", "artist", "album", "albumartist", "tracknumber", "date", "genre"]

try:
    import mutagen
except ImportError:
    mutagen = None


class ToolError(Exception):
    """A problem to show to the person (drive missing, module missing...)."""


def no_progress(label, i, total):
    pass


# --------------------------------------------------------------------------------------------
# Paths and scanning
# --------------------------------------------------------------------------------------------
class Paths:
    def __init__(self, root):
        self.root = os.path.abspath(root)
        self.project = os.path.join(self.root, PROJECT)
        self.library = os.path.join(self.project, "Library")
        self.review = os.path.join(self.project, REVIEW)
        self.reports = os.path.join(self.project, "reports")
        self.tools = os.path.join(self.project, "tools")
        self.cache = os.path.join(self.reports, ".hashcache.json")

    def rel(self, path):
        return os.path.relpath(path, self.root)

    def abs(self, rel):
        """Absolute path for a drive-relative path, refusing anything outside the drive."""
        full = os.path.realpath(os.path.join(self.root, rel))
        root = os.path.realpath(self.root)
        if full != root and not full.startswith(root + os.sep):
            raise ToolError("Path is outside the music drive: %s" % rel)
        return full


def scan_audio(p):
    """All audio files on the drive, except inside MP3_Project (apart from MP3_Project/Library)."""
    found = []
    for dirpath, dirnames, filenames in os.walk(p.root):
        keep = []
        for d in dirnames:
            if d in SKIP_DIRS or d.startswith("._"):
                continue
            if dirpath == p.root and d == PROJECT:
                if os.path.isdir(p.library):
                    found.extend(_walk_simple(p.library))
                continue
            keep.append(d)
        dirnames[:] = sorted(keep)
        for f in sorted(filenames):
            if f.startswith("."):
                continue
            if os.path.splitext(f)[1].lower() in AUDIO_EXT:
                found.append(os.path.join(dirpath, f))
    return found


def _walk_simple(top):
    out = []
    for dirpath, dirnames, filenames in os.walk(top):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith("._"))
        for f in sorted(filenames):
            if not f.startswith(".") and os.path.splitext(f)[1].lower() in AUDIO_EXT:
                out.append(os.path.join(dirpath, f))
    return out


# --------------------------------------------------------------------------------------------
# Hashing. For MP3s the "audio hash" covers only the audio frames, skipping ID3v2 (start/end),
# ID3v1, APE and Lyrics3 tags, so a retagged copy of the same rip still matches.
# --------------------------------------------------------------------------------------------
def _syncsafe(b):
    return (b[0] << 21) | (b[1] << 14) | (b[2] << 7) | b[3]


def mp3_audio_range(fh, size):
    start = 0
    while True:
        fh.seek(start)
        head = fh.read(10)
        if len(head) == 10 and head[:3] == b"ID3" and all(x < 0x80 for x in head[6:10]):
            start += 10 + _syncsafe(head[6:10]) + (10 if head[5] & 0x10 else 0)
        else:
            break
    end = size
    changed = True
    while changed and end > start:
        changed = False
        if end - start >= 128:
            fh.seek(end - 128)
            if fh.read(3) == b"TAG":
                end -= 128
                changed = True
                if end - start >= 227:
                    fh.seek(end - 227)
                    if fh.read(4) == b"TAG+":
                        end -= 227
                continue
        if end - start >= 32:
            fh.seek(end - 32)
            foot = fh.read(32)
            if foot[:8] == b"APETAGEX":
                tsize = int.from_bytes(foot[12:16], "little")
                flags = int.from_bytes(foot[20:24], "little")
                end -= tsize + (32 if flags & 0x80000000 else 0)
                changed = True
                continue
        if end - start >= 15:
            fh.seek(end - 15)
            d = fh.read(15)
            if d[6:] == b"LYRICS200" and d[:6].isdigit():
                end -= int(d[:6]) + 15
                changed = True
                continue
        if end - start >= 10:
            fh.seek(end - 10)
            d = fh.read(10)
            if d[:3] == b"3DI" and all(x < 0x80 for x in d[6:10]):
                end -= _syncsafe(d[6:10]) + 20
                changed = True
                continue
    if end <= start:
        return 0, size
    return start, end


def hash_file(path):
    """Returns (whole-file hash, audio-only hash)."""
    size = os.path.getsize(path)
    whole = hashlib.md5()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            whole.update(chunk)
        if not path.lower().endswith(".mp3"):
            return whole.hexdigest(), whole.hexdigest()
        start, end = mp3_audio_range(fh, size)
        audio = hashlib.md5()
        fh.seek(start)
        left = end - start
        while left > 0:
            chunk = fh.read(min(1 << 20, left))
            if not chunk:
                break
            audio.update(chunk)
            left -= len(chunk)
    return whole.hexdigest(), "mp3:" + audio.hexdigest()


class HashCache:
    """Remembers hashes by path + size + modified time, so re-runs are fast."""
    def __init__(self, path):
        self.path = path
        self.data = {}
        try:
            with open(path) as f:
                self.data = json.load(f)
        except Exception:
            self.data = {}
        self.dirty = 0

    def get(self, p, fullpath):
        st = os.stat(fullpath)
        key = p.rel(fullpath)
        rec = self.data.get(key)
        if rec and rec[0] == st.st_size and rec[1] == int(st.st_mtime):
            return rec[2], rec[3]
        fh, ah = hash_file(fullpath)
        self.data[key] = [st.st_size, int(st.st_mtime), fh, ah]
        self.dirty += 1
        if self.dirty >= 300:
            self.save()
        return fh, ah

    def save(self):
        if not self.dirty:
            return
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(self.data, f)
        os.replace(tmp, self.path)
        self.dirty = 0


# --------------------------------------------------------------------------------------------
# Tags and cover art
# --------------------------------------------------------------------------------------------
def read_info(path):
    info = {k: "" for k in TAG_FIELDS}
    info.update({"bitrate_kbps": 0, "seconds": 0, "has_cover": False,
                 "mb_recording": "", "mb_album": "", "tag_count": 0, "error": ""})
    if mutagen is None:
        return info
    try:
        easy = mutagen.File(path, easy=True)
    except Exception as e:
        info["error"] = "unreadable: %s" % e
        return info
    if easy is None:
        info["error"] = "not recognised as audio"
        return info
    tags = easy.tags or {}

    def first(key):
        try:
            v = tags.get(key)
        except Exception:
            return ""
        if isinstance(v, list):
            v = v[0] if v else ""
        return str(v or "").strip()

    for k in TAG_FIELDS:
        info[k] = first(k)
    info["mb_recording"] = first("musicbrainz_trackid")
    info["mb_album"] = first("musicbrainz_albumid")
    info["tag_count"] = sum(1 for k in TAG_FIELDS if info[k])
    i = getattr(easy, "info", None)
    if i is not None:
        info["bitrate_kbps"] = int(round((getattr(i, "bitrate", 0) or 0) / 1000.0))
        info["seconds"] = int(round(getattr(i, "length", 0) or 0))
    info["has_cover"] = read_cover(path, check_only=True)
    return info


def read_cover(path, check_only=False):
    """Embedded cover art: (bytes, mime type), or True/False with check_only."""
    if mutagen is None:
        return False if check_only else None
    try:
        raw = mutagen.File(path)
    except Exception:
        return False if check_only else None
    if raw is None:
        return False if check_only else None
    found = None
    t = raw.tags
    try:
        if t is not None:
            for k in list(t.keys()):
                ks = str(k)
                if ks.startswith("APIC"):
                    fr = t[k]
                    found = (fr.data, fr.mime or "image/jpeg")
                    break
                if ks == "covr":
                    c = t[k][0]
                    fmt = getattr(c, "imageformat", 13)
                    found = (bytes(c), "image/png" if fmt == 14 else "image/jpeg")
                    break
                if ks == "WM/Picture":
                    found = (b"", "image/jpeg")  # WMA pictures: presence only
                    break
        if found is None and getattr(raw, "pictures", None):
            pic = raw.pictures[0]
            found = (pic.data, pic.mime or "image/jpeg")
    except Exception:
        found = None
    if check_only:
        return found is not None
    return found


# --------------------------------------------------------------------------------------------
# Choosing which copy to keep
# --------------------------------------------------------------------------------------------
def keeper_key(p, path, info, prefer_bitrate):
    in_library = path.startswith(p.library + os.sep)
    rel = p.rel(path)
    return (
        -(info["bitrate_kbps"] if prefer_bitrate else 0),  # higher bitrate first
        0 if info["has_cover"] else 1,                     # has cover art
        -info["tag_count"],                                # more complete tags
        0 if in_library else 1,                            # already organized by Picard
        len(rel),                                          # shorter path
        rel.lower(),                                       # stable tie-break
    )


def describe_reason(p, keep, info_keep, other, info_other, prefer_bitrate):
    if prefer_bitrate and info_keep["bitrate_kbps"] != info_other["bitrate_kbps"]:
        why = "kept higher bitrate (%d vs %d kbps)" % (info_keep["bitrate_kbps"], info_other["bitrate_kbps"])
    elif info_keep["has_cover"] != info_other["has_cover"]:
        why = "kept the copy with cover art"
    elif info_keep["tag_count"] != info_other["tag_count"]:
        why = "kept the copy with more complete tags"
    elif keep.startswith(p.library + os.sep) and not other.startswith(p.library + os.sep):
        why = "kept the copy in Library"
    else:
        why = "copies equal; kept shorter path"
    if info_other["album"].lower() != info_keep["album"].lower():
        why += "  NOTE: album tags differ (%s / %s)" % (info_other["album"] or "none", info_keep["album"] or "none")
    return why


# --------------------------------------------------------------------------------------------
# Plans. A plan is a list of duplicate groups, each with a suggested copy to keep.
# --------------------------------------------------------------------------------------------
def stamp():
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")


def require_root(p):
    if not os.path.isdir(p.root):
        raise ToolError("Drive not found: %s  (check the name with: ls /Volumes)" % p.root)


def require_mutagen():
    if mutagen is None:
        raise ToolError("The 'mutagen' module is missing. Set it up once with:\n"
                        "    python3 -m venv ~/mp3venv && ~/mp3venv/bin/pip install mutagen\n"
                        "then run this tool with ~/mp3venv/bin/python (or the 'mp3tool' shortcut).")


def _make_plan(p, kind, groups_raw, infos, sizes, prefer_bitrate, whole=None, extra=None):
    """groups_raw: list of (label, [abs paths]). Builds the plan dict used by CLI and window."""
    groups = []
    for gi, (label, members) in enumerate(groups_raw, 1):
        ordered = sorted(members, key=lambda x: keeper_key(p, x, infos[x], prefer_bitrate))
        keep = ordered[0]
        mem = []
        for m in ordered:
            inf = infos[m]
            is_keep = m == keep
            match = label
            if whole is not None and not is_keep:
                match = "identical file" if whole[m] == whole[keep] else "same audio, different tags"
            mem.append({
                "path": p.rel(m), "size": sizes[m], "bitrate_kbps": inf["bitrate_kbps"],
                "seconds": inf["seconds"], "has_cover": inf["has_cover"], "title": inf["title"],
                "artist": inf["artist"], "album": inf["album"], "tag_count": inf["tag_count"],
                "mb_recording": inf["mb_recording"], "mb_album": inf["mb_album"],
                "fh": whole[m] if whole is not None else "",
                "suggested_keep": is_keep, "match": "" if is_keep else match,
                "why": "" if is_keep else describe_reason(p, keep, infos[keep], m, inf, prefer_bitrate),
            })
        groups.append({"id": gi, "label": label, "keep": p.rel(keep), "members": mem})
    plan = {"kind": kind, "name": "%s_%s" % (kind, stamp()), "root": p.root, "groups": groups}
    plan.update(extra or {})
    moves = [(m["path"], g["keep"]) for g in groups for m in g["members"] if not m["suggested_keep"]]
    plan["move_count"] = len(moves)
    plan["move_bytes"] = sum(m["size"] for g in groups for m in g["members"] if not m["suggested_keep"])
    plan["identical_count"] = sum(1 for g in groups for m in g["members"] if m["match"] == "identical file")
    return plan


def find_dupes(p, prog=no_progress):
    """Step 1: identical files and same audio with different tags."""
    require_root(p)
    require_mutagen()
    os.makedirs(p.reports, exist_ok=True)
    prog("Looking for music files", 0, 0)
    files = scan_audio(p)
    cache = HashCache(p.cache)
    hashes, errors = {}, []
    for i, f in enumerate(files, 1):
        prog("Checking files", i, len(files))
        try:
            hashes[f] = cache.get(p, f)
        except OSError as e:
            errors.append({"path": p.rel(f), "error": str(e)})
    cache.save()

    by_audio = {}
    for f, (fh, ah) in hashes.items():
        by_audio.setdefault(ah, []).append(f)
    raw = [m for m in by_audio.values() if len(m) > 1]
    members_all = [m for g in raw for m in g]
    infos, sizes = {}, {}
    for i, m in enumerate(members_all, 1):
        prog("Reading tags of duplicates", i, len(members_all))
        infos[m] = read_info(m)
        sizes[m] = os.path.getsize(m)
    groups_raw = [("duplicate", g) for g in sorted(raw, key=lambda g: p.rel(sorted(g)[0]).lower())]
    whole = dict((m, hashes[m][0]) for m in members_all)
    return _make_plan(p, "dupes", groups_raw, infos, sizes, prefer_bitrate=False, whole=whole,
                      extra={"files_scanned": len(files), "errors": errors})


def find_recordings(p, across_albums=False, prog=no_progress):
    """Step 3: same MusicBrainz recording (after tagging with Picard)."""
    require_root(p)
    require_mutagen()
    os.makedirs(p.reports, exist_ok=True)
    prog("Looking for music files", 0, 0)
    files = scan_audio(p)
    infos, sizes = {}, {}
    for i, f in enumerate(files, 1):
        prog("Reading tags", i, len(files))
        infos[f] = read_info(f)
        sizes[f] = os.path.getsize(f)
    tagged = [f for f in files if infos[f]["mb_recording"]]
    buckets = {}
    for f in tagged:
        inf = infos[f]
        key = inf["mb_recording"] if across_albums else (inf["mb_recording"], inf["mb_album"] or inf["album"].lower())
        buckets.setdefault(key, []).append(f)
    label = "same recording" if across_albums else "same recording, same album"
    groups_raw = [(label, g) for k, g in sorted(buckets.items(), key=lambda kv: str(kv[0])) if len(g) > 1]
    return _make_plan(p, "recordings", groups_raw, infos, sizes, prefer_bitrate=True,
                      extra={"files_scanned": len(files), "files_with_id": len(tagged),
                             "across_albums": across_albums, "errors": []})


REPORT_COLS = ["group", "match", "action", "path", "kept_copy", "why", "size_mb", "bitrate_kbps",
               "seconds", "has_cover", "title", "artist", "album"]


def write_csv(path, cols, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # utf-8-sig so Excel/Numbers show accented names correctly
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)


def write_plan_report(p, plan, suffix="preview"):
    rows = []
    for g in plan["groups"]:
        for m in g["members"]:
            rows.append({
                "group": g["id"], "match": m["match"] or g["label"],
                "action": "KEEP" if m["suggested_keep"] else "MOVE TO REVIEW",
                "path": m["path"], "kept_copy": "" if m["suggested_keep"] else g["keep"], "why": m["why"],
                "size_mb": "%.2f" % (m["size"] / 1048576.0), "bitrate_kbps": m["bitrate_kbps"],
                "seconds": m["seconds"], "has_cover": "yes" if m["has_cover"] else "no",
                "title": m["title"], "artist": m["artist"], "album": m["album"],
            })
    out = os.path.join(p.reports, "%s_%s.csv" % (plan["name"], suffix))
    write_csv(out, REPORT_COLS, rows)
    return out


def plan_moves(plan, decisions=None):
    """Turn a plan (plus optional choices) into a list of moves.

    decisions: {group_id: {"keep": relpath, "skip": [relpaths to leave in place]}}
    Every path must belong to its group, so nothing outside the plan can be moved.
    Returns list of (dup_rel, keep_rel, group_id, match_label).
    """
    decisions = decisions or {}
    moves = []
    for g in plan["groups"]:
        d = decisions.get(g["id"]) or decisions.get(str(g["id"])) or {}
        paths = [m["path"] for m in g["members"]]
        keep = d.get("keep") or g["keep"]
        if keep not in paths:
            raise ToolError("Chosen copy is not part of group %s" % g["id"])
        skip = set(d.get("skip") or [])
        if d.get("exclude_group"):
            continue
        keep_fh = next(m["fh"] for m in g["members"] if m["path"] == keep)
        for m in g["members"]:
            if m["path"] == keep or m["path"] in skip:
                continue
            if plan["kind"] == "dupes":
                label = "identical file" if m["fh"] and m["fh"] == keep_fh else "same audio, different tags"
            else:
                label = g["label"]
            moves.append((m["path"], keep, g["id"], label))
    return moves


def apply_moves(p, plan, moves, prog=no_progress):
    """Move duplicates into the review folder, re-checking each pair from disk first."""
    require_root(p)
    kind = plan["kind"]
    run_name = plan["name"]
    run_dir = os.path.join(p.review, run_name)
    manifest = os.path.join(p.reports, "%s_moves.csv" % run_name)
    if os.path.exists(manifest):
        raise ToolError("This scan was already applied. Scan again to make a new plan.")
    cols = ["moved_from", "moved_to", "kept_copy", "group", "match", "status"]
    rows = []
    moved = skipped = freed = 0
    keep_cache = {}

    def verify(dup, keep):
        if kind == "dupes":
            if keep not in keep_cache:
                keep_cache[keep] = hash_file(keep)[1]
            return hash_file(dup)[1] == keep_cache[keep]
        a, b = read_info(dup), read_info(keep)
        return bool(a["mb_recording"]) and a["mb_recording"] == b["mb_recording"]

    total = len(moves)
    for i, (dup_rel, keep_rel, gi, label) in enumerate(moves, 1):
        prog("Moving duplicates to review", i, total)
        dup, keep = p.abs(dup_rel), p.abs(keep_rel)
        dest = os.path.join(run_dir, dup_rel)
        if not os.path.exists(dup):
            status = "skipped: file no longer there"
        elif not os.path.exists(keep):
            status = "skipped: kept copy no longer there"
        elif not verify(dup, keep):
            status = "skipped: files no longer match"
        else:
            base, ext = os.path.splitext(dest)
            n = 1
            while os.path.exists(dest):
                dest = "%s_%d%s" % (base, n, ext)
                n += 1
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            size = os.path.getsize(dup)
            shutil.move(dup, dest)
            status = "moved"
            moved += 1
            freed += size
        if status != "moved":
            skipped += 1
        rows.append({"moved_from": dup_rel, "moved_to": p.rel(dest) if status == "moved" else "",
                     "kept_copy": keep_rel, "group": gi, "match": label, "status": status})
        if i % 100 == 0 or i == total:   # write as we go: an interruption still leaves an undo record
            write_csv(manifest, cols, rows)
    if not moves:
        write_csv(manifest, cols, rows)
    return {"manifest": manifest, "moved": moved, "skipped": skipped, "freed": freed,
            "review_dir": run_dir, "rows": rows}


# --------------------------------------------------------------------------------------------
# History and undo
# --------------------------------------------------------------------------------------------
def list_runs(p):
    runs = []
    if not os.path.isdir(p.reports):
        return runs
    for f in sorted(os.listdir(p.reports), reverse=True):
        if not (f.endswith("_moves.csv") or f.endswith("_moves_UNDONE.csv")):
            continue
        undone = f.endswith("_UNDONE.csv")
        name = f.replace("_moves_UNDONE.csv", "").replace("_moves.csv", "")
        path = os.path.join(p.reports, f)
        try:
            with open(path, newline="", encoding="utf-8-sig") as fh:
                rows = list(csv.DictReader(fh))
        except Exception:
            rows = []
        moved = [r for r in rows if r.get("status") == "moved"]
        still = 0
        if not undone:
            for r in moved:
                try:
                    full = p.abs(r["moved_to"])
                    if os.path.exists(full):
                        still += os.path.getsize(full)
                except (ToolError, OSError):
                    pass
        kind, _, st = name.partition("_")
        try:
            when = datetime.datetime.strptime(st, "%Y%m%d_%H%M%S").strftime("%a %d %b %Y, %H:%M")
        except ValueError:
            when = st
        runs.append({"name": name, "kind": kind, "when": when, "manifest": p.rel(path),
                     "moved": len(moved), "skipped": len(rows) - len(moved), "undone": undone,
                     "review_dir": p.rel(os.path.join(p.review, name)), "bytes_in_review": still})
    return runs


def undo_run(p, manifest=None, prog=no_progress):
    require_root(p)
    if not manifest:
        cands = sorted(f for f in os.listdir(p.reports) if f.endswith("_moves.csv")) if os.path.isdir(p.reports) else []
        if not cands:
            raise ToolError("No move records found in %s" % p.reports)
        manifest = os.path.join(p.reports, cands[-1])
    if not os.path.isabs(manifest):
        manifest = p.abs(manifest)
    if not manifest.endswith("_moves.csv") or not os.path.exists(manifest):
        raise ToolError("Not an undoable move record: %s" % manifest)
    with open(manifest, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    restored = 0
    problems = []
    todo = [r for r in rows if r["status"] == "moved"]
    for i, r in enumerate(todo, 1):
        prog("Putting files back", i, len(todo))
        src, dst = p.abs(r["moved_to"]), p.abs(r["moved_from"])
        if not os.path.exists(src):
            problems.append("not in the review folder any more: %s" % r["moved_to"])
            continue
        if os.path.exists(dst):
            problems.append("something is already at the original place, left in review: %s" % r["moved_from"])
            continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(src, dst)
        restored += 1
    run_dir = os.path.join(p.review, os.path.basename(manifest).replace("_moves.csv", ""))
    if os.path.isdir(run_dir):
        for dirpath, _, _ in os.walk(run_dir, topdown=False):
            left = [x for x in os.listdir(dirpath) if x != ".DS_Store" and not x.startswith("._")]
            if not left:   # empty apart from macOS clutter
                shutil.rmtree(dirpath, ignore_errors=True)
    if not problems:
        os.replace(manifest, manifest.replace("_moves.csv", "_moves_UNDONE.csv"))
    return {"restored": restored, "problems": problems, "manifest": manifest}


# --------------------------------------------------------------------------------------------
# Catalog
# --------------------------------------------------------------------------------------------
CATALOG_COLS = ["artist", "album", "tracknumber", "title", "albumartist", "date", "genre", "seconds",
                "bitrate_kbps", "has_cover", "has_musicbrainz_id", "needs_attention", "path"]


def build_catalog(p, prog=no_progress):
    require_root(p)
    require_mutagen()
    prog("Looking for music files", 0, 0)
    files = scan_audio(p)
    rows = []
    for i, f in enumerate(files, 1):
        prog("Reading tags", i, len(files))
        inf = read_info(f)
        missing = [k for k in ("title", "artist", "album") if not inf[k]]
        if not inf["has_cover"]:
            missing.append("cover")
        if inf["error"]:
            missing.append(inf["error"])
        rows.append({
            "artist": inf["artist"], "album": inf["album"], "tracknumber": inf["tracknumber"],
            "title": inf["title"], "albumartist": inf["albumartist"], "date": inf["date"],
            "genre": inf["genre"], "seconds": inf["seconds"], "bitrate_kbps": inf["bitrate_kbps"],
            "has_cover": "yes" if inf["has_cover"] else "no",
            "has_musicbrainz_id": "yes" if inf["mb_recording"] else "no",
            "needs_attention": ("missing " + ", ".join(missing)) if missing else "",
            "path": p.rel(f),
        })
    rows.sort(key=lambda r: (r["artist"].lower(), r["album"].lower(), r["tracknumber"].zfill(6), r["path"].lower()))
    out = os.path.join(p.reports, "catalog_%s.csv" % stamp())
    write_csv(out, CATALOG_COLS, rows)
    stats = {
        "songs": len(rows),
        "albums": len(set((r["artist"], r["album"]) for r in rows if r["album"])),
        "artists": len(set(r["artist"] for r in rows if r["artist"])),
        "no_cover": sum(1 for r in rows if r["has_cover"] == "no"),
        "attention": sum(1 for r in rows if r["needs_attention"]),
        "with_id": sum(1 for r in rows if r["has_musicbrainz_id"] == "yes"),
    }
    return {"csv": out, "rows": rows, "stats": stats}


# --------------------------------------------------------------------------------------------
# Convert to MP3 (uses ffmpeg). Originals are never changed or deleted.
# --------------------------------------------------------------------------------------------
CONVERT_FORMATS = [  # (key, label, extensions, lossless?)
    ("wma", "WMA", [".wma"], False),
    ("wav", "WAV", [".wav"], True),
    ("aac", "AAC / M4A", [".aac", ".m4a"], False),
    ("flac", "FLAC", [".flac"], True),
    ("ogg", "OGG / Opus", [".ogg", ".oga", ".opus"], False),
    ("aiff", "AIFF", [".aiff", ".aif"], True),
    ("ape", "APE", [".ape"], True),
    ("wv", "WavPack", [".wv"], True),
]
DEFAULT_CONVERT = ["wma", "wav", "aac", "flac", "ogg"]
QUALITY_PRESETS = {
    "best": ("vbr", 0, "Best (VBR, about 245 kbps)"),
    "320": ("cbr", 320, "High (320 kbps)"),
    "256": ("cbr", 256, "Very good (256 kbps)"),
    "192": ("cbr", 192, "Standard (192 kbps)"),
    "128": ("cbr", 128, "Small files (128 kbps)"),
}


def find_ffmpeg():
    found = shutil.which("ffmpeg")
    if found:
        return found
    for c in ("/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg", "/usr/bin/ffmpeg"):
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return None


def _convert_exts(formats):
    keys = set(formats or DEFAULT_CONVERT)
    exts = {}
    for key, label, ext_list, _ in CONVERT_FORMATS:
        if key in keys:
            for e in ext_list:
                exts[e] = key
    return exts


def plan_convert(src, dst=None, formats=None, recurse=True, overwrite=False, prog=no_progress):
    """Which files would be converted, and to where. dst=None puts each MP3 next to its original."""
    src = os.path.abspath(os.path.expanduser(src))
    if not os.path.isdir(src):
        raise ToolError("Source folder not found: %s" % src)
    if dst:
        dst = os.path.abspath(os.path.expanduser(dst))
    exts = _convert_exts(formats)
    if not exts:
        raise ToolError("Choose at least one format to convert.")
    prog("Looking for files to convert", 0, 0)
    found = []
    for dirpath, dirnames, filenames in os.walk(src):
        dirnames[:] = sorted((d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".") and d != REVIEW
                              and not (dst and os.path.join(dirpath, d) == dst)), key=str.lower)
        for f in sorted(filenames, key=str.lower):
            if f.startswith("."):
                continue
            ext = os.path.splitext(f)[1].lower()
            if ext in exts:
                found.append((os.path.join(dirpath, f), exts[ext]))
        if not recurse:
            break
    items, claimed = [], set()
    for path, fmt in found:
        rel_dir = os.path.relpath(os.path.dirname(path), src)
        out_dir = os.path.normpath(os.path.join(dst, rel_dir)) if dst else os.path.dirname(path)
        base = os.path.splitext(os.path.basename(path))[0]
        out = os.path.join(out_dir, base + ".mp3")
        if out.lower() in claimed:                      # song.wma and song.flac in one folder
            out = os.path.join(out_dir, "%s (%s).mp3" % (base, fmt))
        claimed.add(out.lower())
        status = "exists" if os.path.exists(out) and not overwrite else "todo"
        items.append({"src": path, "out": out, "format": fmt, "size": os.path.getsize(path), "status": status})
    by_format = {}
    for it in items:
        b = by_format.setdefault(it["format"], {"files": 0, "bytes": 0, "todo": 0})
        b["files"] += 1
        b["bytes"] += it["size"]
        b["todo"] += it["status"] == "todo"
    return {"src": src, "dst": dst, "items": items, "by_format": by_format,
            "todo": sum(1 for i in items if i["status"] == "todo"),
            "exists": sum(1 for i in items if i["status"] == "exists")}


def _ffmpeg_args(ffmpeg, src, out, quality, keep_art, fmt=""):
    mode, val, _ = QUALITY_PRESETS.get(quality, QUALITY_PRESETS["320"])
    # OGG/Opus keep their tags on the audio stream, everything else on the file
    tags_from = "0:s:a:0" if fmt == "ogg" else "0"
    args = [ffmpeg, "-hide_banner", "-nostdin", "-loglevel", "error", "-y", "-i", src,
            "-map", "0:a:0", "-map_metadata", tags_from, "-c:a", "libmp3lame"]
    args += ["-q:a", str(val)] if mode == "vbr" else ["-b:a", "%dk" % val]
    if keep_art:
        args += ["-map", "0:v?", "-c:v", "copy", "-disposition:v", "attached_pic"]
    return args + ["-id3v2_version", "3", "-f", "mp3", out]


def _friendly_reason(detail, fmt):
    d = detail.lower()
    if "drm" in d or "protected" in d:
        return "Copy-protected (DRM). No tool can convert it."
    if "no playable audio" in d:
        return "Contains no playable audio."
    if "no space left" in d:
        return "The destination drive is full."
    if "permission denied" in d or "operation not permitted" in d:
        return "No permission to read this file or write the MP3."
    if "invalid data" in d or "could not find codec" in d or "moov atom not found" in d or "header" in d:
        return "Damaged, incomplete, or not really a %s file." % fmt.upper()
    if "took longer" in d:
        return "Conversion took too long and was stopped."
    return "ffmpeg couldn't convert it (see the failure list for details)."


def _has_audio(path):
    """True if the converted MP3 really contains sound (ffmpeg can 'succeed' on an empty input)."""
    if not os.path.isfile(path) or os.path.getsize(path) == 0:
        return False
    if mutagen is not None:
        try:
            from mutagen.mp3 import MP3
            return (MP3(path).info.length or 0) > 0.2
        except Exception:
            return False
    return os.path.getsize(path) > 8192


def run_convert(plan, quality="320", keep_art=True, prog=no_progress):
    """Convert the files in a plan. Writes to a temporary .part file first, so an interrupted
    run never leaves a half-written MP3. Returns a summary and writes a log of any failures."""
    ffmpeg = find_ffmpeg()
    if not ffmpeg:
        raise ToolError("ffmpeg is needed to convert. Install it in Terminal with:  brew install ffmpeg")
    todo = [i for i in plan["items"] if i["status"] == "todo"]
    done, failed = 0, []
    out_bytes = 0
    for n, it in enumerate(todo, 1):
        prog("Converting %s" % os.path.basename(it["src"]), n, len(todo))
        os.makedirs(os.path.dirname(it["out"]), exist_ok=True)
        tmp = it["out"] + ".part"
        err = ""
        ok = False
        for art in ([True, False] if keep_art else [False]):      # retry without art if the art is the problem
            try:
                r = subprocess.run(_ffmpeg_args(ffmpeg, it["src"], tmp, quality, art, it["format"]),
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=1800)
                err = r.stderr.decode("utf-8", "replace").strip()
                ok = r.returncode == 0 and _has_audio(tmp)
                if r.returncode == 0 and not ok:
                    err = "the file contains no playable audio"
            except subprocess.TimeoutExpired:
                err, ok = "took longer than 30 minutes", False
            if ok:
                break
        if ok:
            os.replace(tmp, it["out"])
            done += 1
            out_bytes += os.path.getsize(it["out"])
        else:
            try:
                os.remove(tmp)
            except OSError:
                pass
            detail = " | ".join([x for x in err.splitlines() if x.strip()][-3:]) or "ffmpeg could not read this file"
            failed.append({"file": it["src"], "reason": _friendly_reason(detail, it["format"]), "detail": detail})
    log = None
    if failed:
        log_dir = plan["dst"] or plan["src"]
        log = os.path.join(log_dir, "convert-failures_%s.txt" % stamp())
        try:
            os.makedirs(log_dir, exist_ok=True)
            with open(log, "w") as f:
                for x in failed:
                    f.write("%s\n    %s\n    (details: %s)\n" % (x["file"], x["reason"], x["detail"]))
        except OSError:
            log = None
    return {"converted": done, "failed": failed, "skipped": plan["exists"], "out_bytes": out_bytes,
            "log": log, "dst": plan["dst"] or plan["src"]}


# --------------------------------------------------------------------------------------------
# Setup
# --------------------------------------------------------------------------------------------
APP_NAME = "Kalya MusicBox"
APP_TAGLINE = "MP3 Manager & Music Player"
LAUNCHER = os.path.expanduser("~/Desktop/Kalya MusicBox.command")
OLD_LAUNCHER = os.path.expanduser("~/Desktop/MP3 Manager.command")   # name used before the rename


def setup_project(p, make_launcher=True):
    require_root(p)
    for d in (p.project, p.library, p.review, p.reports, p.tools):
        os.makedirs(d, exist_ok=True)
    here = os.path.dirname(os.path.abspath(__file__))
    copied = []
    for name in ("mp3tool.py", "mp3gui.py"):
        src = os.path.join(here, name)
        dst = os.path.join(p.tools, name)
        if os.path.exists(src) and os.path.abspath(src) != os.path.abspath(dst):
            shutil.copyfile(src, dst)
            copied.append(dst)
    launcher = None
    if sys.platform == "darwin" and make_launcher:
        launcher = LAUNCHER
        with open(launcher, "w") as f:
            f.write('#!/bin/bash\n'
                    '# Double-click to open Kalya MusicBox Ver %s, MP3 Manager & Music Player\n'
                    '# (developed by Durgesh Kalya, FindingPlace.org).\n'
                    '# Close this Terminal window to stop it.\n' % APP_VERSION +
                    'clear\n"%s" "%s" --root "%s"\n'
                    % (sys.executable, os.path.join(p.tools, "mp3gui.py"), p.root))
        os.chmod(launcher, 0o755)
        # remove the launcher this tool made under the app's old name (only if it's ours)
        try:
            with open(OLD_LAUNCHER) as f:
                if "mp3gui.py" in f.read():
                    os.remove(OLD_LAUNCHER)
        except OSError:
            pass
    return {"folders": [p.library, p.review, p.reports, p.tools], "copied": copied, "launcher": launcher}


# --------------------------------------------------------------------------------------------
# Terminal commands
# --------------------------------------------------------------------------------------------
def console_progress(label, i, total):
    if total and (i % 50 == 0 or i == total):
        sys.stdout.write("\r  %s %d/%d (%d%%)   " % (label, i, total, i * 100 // total))
        sys.stdout.flush()
        if i == total:
            sys.stdout.write("\n")


def _gb(b):
    return b / 1073741824.0


def _print_apply(p, res):
    print("\nMoved %d file(s) (%.1f GB) to %s" % (res["moved"], _gb(res["freed"]), res["review_dir"]))
    if res["skipped"]:
        print("Skipped %d (see the move record)." % res["skipped"])
    print("Move record: %s" % res["manifest"])
    print("To put everything back:  mp3tool undo \"%s\"" % res["manifest"])


def cmd_setup(p, args):
    res = setup_project(p)
    print("Created:")
    for d in res["folders"]:
        print("  " + d)
    for c in res["copied"]:
        print("Copied tool: " + c)
    if res["launcher"]:
        print("\nDesktop launcher: %s  (double-click to open Kalya MusicBox)" % res["launcher"])
    if mutagen is None:
        print("\nNext, install the tag reader:  python3 -m venv ~/mp3venv && ~/mp3venv/bin/pip install mutagen")


def cmd_dupes(p, args):
    print("Scanning %s ..." % p.root)
    plan = find_dupes(p, console_progress)
    report = write_plan_report(p, plan, "APPLIED" if args.apply else "preview")
    print("  %d audio files checked" % plan["files_scanned"])
    print("\nDuplicate groups: %d" % len(plan["groups"]))
    print("  copies that are identical files:          %d" % plan["identical_count"])
    print("  copies with same audio but different tags: %d" % (plan["move_count"] - plan["identical_count"]))
    print("Files that would move to review: %d  (%.1f GB)" % (plan["move_count"], _gb(plan["move_bytes"])))
    print("Report: %s" % report)
    if plan["errors"]:
        print("Could not read %d file(s); they were left alone." % len(plan["errors"]))
    if not args.apply:
        print("\nThis was a PREVIEW. Nothing was moved.")
        print("Open the report to check it, then run again with --apply.")
        return
    _print_apply(p, apply_moves(p, plan, plan_moves(plan), console_progress))


def cmd_recordings(p, args):
    print("Scanning %s ..." % p.root)
    plan = find_recordings(p, args.across_albums, console_progress)
    report = write_plan_report(p, plan, "APPLIED" if args.apply else "preview")
    print("\nFiles with a MusicBrainz recording ID: %d of %d" % (plan["files_with_id"], plan["files_scanned"]))
    if plan["files_with_id"] < plan["files_scanned"]:
        print("  (files without one are ignored; tag them with Picard first)")
    print("Duplicate groups: %d" % len(plan["groups"]))
    print("Files that would move to review: %d  (%.1f GB)" % (plan["move_count"], _gb(plan["move_bytes"])))
    print("Report: %s" % report)
    if not args.apply:
        print("\nThis was a PREVIEW. Nothing was moved.")
        print("Listen to a few groups before applying, then run again with --apply.")
        return
    _print_apply(p, apply_moves(p, plan, plan_moves(plan), console_progress))


def cmd_undo(p, args):
    res = undo_run(p, args.manifest, console_progress)
    for prob in res["problems"]:
        print("  " + prob)
    print("Restored %d file(s)%s." % (res["restored"],
                                     (", %d problem(s) listed above" % len(res["problems"])) if res["problems"] else ""))


def cmd_catalog(p, args):
    res = build_catalog(p, console_progress)
    s = res["stats"]
    print("\nCatalog: %s" % res["csv"])
    print("Songs: %d   Albums: %d   Artists: %d" % (s["songs"], s["albums"], s["artists"]))
    print("Missing cover art: %d   Needing tags or attention: %d" % (s["no_cover"], s["attention"]))


def cmd_convert(p, args):
    formats = [x.strip().lower() for x in args.formats.split(",")] if args.formats else None
    plan = plan_convert(args.src, args.output, formats, not args.no_subfolders, args.overwrite)
    print("Found %d file(s) to convert, %d already converted." % (plan["todo"], plan["exists"]))
    for key, label, _, _ in CONVERT_FORMATS:
        b = plan["by_format"].get(key)
        if b:
            print("  %-10s %5d file(s)  %s" % (label, b["files"], "%.1f GB" % _gb(b["bytes"]) if b["bytes"] > 1e8 else "%.0f MB" % (b["bytes"] / 1048576.0)))
    print("MP3s go to: %s" % (plan["dst"] or "next to each original"))
    if args.preview or not plan["todo"]:
        if args.preview:
            print("\nThis was a PREVIEW. Run again without --preview to convert.")
        return
    res = run_convert(plan, args.quality, not args.no_art, console_progress)
    print("\nConverted %d file(s). Skipped %d already converted. Failed: %d" % (res["converted"], res["skipped"], len(res["failed"])))
    if res["log"]:
        print("Failure details: %s" % res["log"])
    print("Your original files were not changed.")


def cmd_gui(p, args):
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, here)
    import mp3gui
    mp3gui.run(p.root)


def main():
    ap = argparse.ArgumentParser(description="Kalya MusicBox Ver %s (MP3 Manager & Music Player): safe duplicate cleanup and cataloging. "
                                             "Developed by Durgesh Kalya (FindingPlace.org)." % APP_VERSION)
    ap.add_argument("--version", action="version",
                    version="Kalya MusicBox Ver %s, MP3 Manager & Music Player, developed by Durgesh Kalya (FindingPlace.org)" % APP_VERSION)
    ap.add_argument("--root", default=DEFAULT_ROOT, help="music drive (default: %(default)s)")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("setup", help="create the MP3_Project folders and a desktop launcher")
    d = sub.add_parser("dupes", help="identical files and same audio with different tags")
    d.add_argument("--apply", action="store_true", help="actually move duplicates to the review folder")
    r = sub.add_parser("recordings", help="same MusicBrainz recording (run after tagging with Picard)")
    r.add_argument("--apply", action="store_true", help="actually move duplicates to the review folder")
    r.add_argument("--across-albums", action="store_true",
                   help="also treat the same recording on different albums as duplicates")
    u = sub.add_parser("undo", help="put back files moved by a run")
    u.add_argument("manifest", nargs="?", help="a *_moves.csv record (default: latest run)")
    sub.add_parser("catalog", help="write a CSV of every song and its tags")
    c = sub.add_parser("convert", help="convert WMA, WAV, AAC/M4A, FLAC, OGG/Opus, AIFF, APE, WavPack to MP3")
    c.add_argument("src", help="folder with the files to convert")
    c.add_argument("-o", "--output", help="folder for the MP3s (default: next to each original)")
    c.add_argument("--formats", help="comma list from: " + ",".join(k for k, _, _, _ in CONVERT_FORMATS) +
                   " (default: " + ",".join(DEFAULT_CONVERT) + ")")
    c.add_argument("--quality", default="320", choices=list(QUALITY_PRESETS), help="best, 320, 256, 192 or 128 (default 320)")
    c.add_argument("--no-art", action="store_true", help="don't copy cover art")
    c.add_argument("--no-subfolders", action="store_true", help="only the folder itself, not subfolders")
    c.add_argument("--overwrite", action="store_true", help="convert again even if the MP3 exists")
    c.add_argument("--preview", action="store_true", help="list what would be converted, change nothing")
    sub.add_parser("gui", help="open the Kalya MusicBox window")
    args = ap.parse_args()
    if not args.cmd:
        ap.print_help()
        return
    p = Paths(args.root)
    try:
        {"setup": cmd_setup, "dupes": cmd_dupes, "recordings": cmd_recordings,
         "undo": cmd_undo, "catalog": cmd_catalog, "convert": cmd_convert, "gui": cmd_gui}[args.cmd](p, args)
    except ToolError as e:
        sys.exit(str(e))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped. Nothing is half-moved; anything already moved is listed in the move record.")
        sys.exit(130)
